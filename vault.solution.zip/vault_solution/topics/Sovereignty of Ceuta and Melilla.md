---
type: topic
aliases: []
---
# Sovereignty of Ceuta and Melilla

"Ceuta is Spain", territorial integrity.

## Positions by group

**[[PPE]].** PPE speakers repeat that Ceuta is Spain and Europe and that its territorial integrity is non-negotiable ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 234 Lena Düpont|Lena Düpont]], [[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]], [[2026-09-15 274 Alma Ezcurra Almansa|Alma Ezcurra Almansa]], [[2026-09-15 277 Juan Ignacio Zoido Álvarez|Juan Ignacio Zoido Álvarez]]).

**[[S&D]].** [[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]] also says Ceuta is Spain and Europe, while rejecting the PPE's use of the issue.

**[[PfE]].** PfE speakers call the events a territorial invasion ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]]) and insist Ceuta has been European for centuries ([[2026-09-15 245 Susanna Ceccardi (question)|Susanna Ceccardi]]).

**[[ECR]].** ECR speakers say Ceuta is Spain and must be defended ([[2026-09-15 213 Diego Solier|Diego Solier]], [[2026-09-15 241 Nora Junco García|Nora Junco García]]).

**[[The Left]].** [[2026-09-15 244 Ilaria Salis|Ilaria Salis]] and [[2026-09-15 246 Ilaria Salis (answer)|Ilaria Salis]] say Ceuta is geographically Africa and a remnant of colonialism.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 211 Iratxe García Pérez]] (S&D, mixed)
- [[2026-09-15 212 Jorge Buxadé Villalba]] (PfE, supports)
- [[2026-09-15 213 Diego Solier]] (ECR, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 234 Lena Düpont]] (PPE, supports)
- [[2026-09-15 240 Susanna Ceccardi (answer)]] (PfE, not stated)
- [[2026-09-15 241 Nora Junco García]] (ECR, supports)
- [[2026-09-15 244 Ilaria Salis]] (The Left, opposes)
- [[2026-09-15 245 Susanna Ceccardi (question)]] (PfE, not stated)
- [[2026-09-15 246 Ilaria Salis (answer)]] (The Left, opposes)
- [[2026-09-15 247 Javier Zarzalejos]] (PPE, supports)
- [[2026-09-15 260 François-Xavier Bellamy (answer)]] (PPE, not stated)
- [[2026-09-15 272 Ana Miguel Pedro]] (PPE, supports)
- [[2026-09-15 274 Alma Ezcurra Almansa]] (PPE, supports)
- [[2026-09-15 277 Juan Ignacio Zoido Álvarez]] (PPE, supports)
