---
type: topic
aliases: []
---
# EU-Morocco relations

Morocco's role, cooperation, agreements, pressure on Morocco.

## Positions by group

**Council and Commission.** The Commission credits cooperation with Morocco for the quick returns and welcomes its commitment to take everyone back ([[2026-09-15 209 Magnus Brunner|Magnus Brunner]]).

**[[PPE]].** PPE speakers say Morocco did not cooperate but controls the border ([[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]]), is responsible by action or omission ([[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]]) and will test the border again ([[2026-09-15 272 Ana Miguel Pedro|Ana Miguel Pedro]]); [[2026-09-15 274 Alma Ezcurra Almansa|Alma Ezcurra Almansa]] calls it aggression and blackmail.

**[[PfE]].** PfE speakers demand the suspension of the EU-Morocco Association Agreement, payments and visas ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]]), and that those Morocco claims be sent back ([[2026-09-15 251 Fabrice Leggeri|Fabrice Leggeri]]).

**[[ECR]].** ECR speakers say Morocco shares responsibility ([[2026-09-15 241 Nora Junco García|Nora Junco García]]) and that EU funding for its border management does not work ([[2026-09-15 286 Joachim Stanisław Brudziński (written)|Joachim Stanisław Brudziński]]).

**[[ESN]].** ESN speakers want Morocco to repay EU funds ([[2026-09-15 217 Mary Khan|Mary Khan]]) or have them cut or made conditional ([[2026-09-15 288 Tomasz Froelich (written)|Tomasz Froelich]]).

**[[Renew]].** [[2026-09-15 224 Oihane Agirregoitia Martínez|Oihane Agirregoitia Martínez]] asks Morocco to honour its readmission commitment.

**[[The Left]].** The Left speakers denounce EU funding of the Moroccan 'dictatorship' and the absence of pressure over Western Sahara ([[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]], [[2026-09-15 267 Pernando Barrena Arza|Pernando Barrena Arza]]) and accuse Morocco of creating the crisis ([[2026-09-15 216 Estrella Galán|Estrella Galán]]).

**[[Verts-ALE]].** [[2026-09-15 256 Ana Miranda Paz|Ana Miranda Paz]] says Europe is silent about the Moroccan regime's corruption and pressure.

**[[NI]].** [[2026-09-15 276 Malika Sorel|Malika Sorel]] asks the Commission to use trade agreements as leverage on Morocco.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 212 Jorge Buxadé Villalba]] (PfE, supports)
- [[2026-09-15 216 Estrella Galán]] (The Left, opposes)
- [[2026-09-15 217 Mary Khan]] (ESN, supports)
- [[2026-09-15 218 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 224 Oihane Agirregoitia Martínez]] (Renew, mixed)
- [[2026-09-15 226 Isabel Serra Sánchez]] (The Left, opposes)
- [[2026-09-15 238 Susanna Ceccardi]] (PfE, supports)
- [[2026-09-15 241 Nora Junco García]] (ECR, supports)
- [[2026-09-15 247 Javier Zarzalejos]] (PPE, supports)
- [[2026-09-15 251 Fabrice Leggeri]] (PfE, supports)
- [[2026-09-15 256 Ana Miranda Paz]] (Verts-ALE, opposes)
- [[2026-09-15 267 Pernando Barrena Arza]] (The Left, not stated)
- [[2026-09-15 272 Ana Miguel Pedro]] (PPE, supports)
- [[2026-09-15 274 Alma Ezcurra Almansa]] (PPE, supports)
- [[2026-09-15 276 Malika Sorel]] (NI, supports)
- [[2026-09-15 286 Joachim Stanisław Brudziński (written)]] (ECR, supports)
- [[2026-09-15 288 Tomasz Froelich (written)]] (ESN, mixed)
