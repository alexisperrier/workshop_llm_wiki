---
type: topic
aliases: []
---
# Regularisation of migrants

Spain's regularisation scheme, pull factors.

## Positions by group

**Council and Commission.** The Council says regularisation is a national competence and that the Spanish scheme excluded anyone who arrived in July and August ([[2026-09-15 282 Thomas Byrne|Thomas Byrne]]).

**[[PPE]].** PPE speakers link Spain's mass regularisation to the crossing ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 258 François-Xavier Bellamy|François-Xavier Bellamy]], [[2026-09-15 272 Ana Miguel Pedro|Ana Miguel Pedro]]).

**[[S&D]].** [[2026-09-15 263 Murielle Laurent (answer)|Murielle Laurent]] defends Spain's regularisations as a positive signal meeting labour and demographic needs.

**[[PfE]].** PfE speakers say the regularisations invite illegal migration ([[2026-09-15 222 Kinga Gál|Kinga Gál]], [[2026-09-15 264 Anna Bryłka|Anna Bryłka]], [[2026-09-15 279 Silvia Sardone|Silvia Sardone]]).

**[[ECR]].** ECR speakers say the regularisations created a pull factor ([[2026-09-15 252 Alessandro Ciriani|Alessandro Ciriani]], [[2026-09-15 262 Nicolas Bay (question)|Nicolas Bay]], [[2026-09-15 270 Marion Maréchal|Marion Maréchal]], [[2026-09-15 285 Nikola Bartůšek (written)|Nikola Bartůšek]]).

**[[ESN]].** ESN speakers blame Sánchez's regularisations ([[2026-09-15 217 Mary Khan|Mary Khan]], [[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]], [[2026-09-15 288 Tomasz Froelich (written)|Tomasz Froelich]]).

**[[NI]].** [[2026-09-15 259 Alvise Pérez (question)|Alvise Pérez]] calls the regularisation an 'electoral coup'.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 217 Mary Khan]] (ESN, supports)
- [[2026-09-15 222 Kinga Gál]] (PfE, supports)
- [[2026-09-15 229 Roberto Vannacci]] (ESN, supports)
- [[2026-09-15 252 Alessandro Ciriani]] (ECR, supports)
- [[2026-09-15 258 François-Xavier Bellamy]] (PPE, supports)
- [[2026-09-15 259 Alvise Pérez (question)]] (NI, not stated)
- [[2026-09-15 260 François-Xavier Bellamy (answer)]] (PPE, not stated)
- [[2026-09-15 262 Nicolas Bay (question)]] (ECR, not stated)
- [[2026-09-15 263 Murielle Laurent (answer)]] (S&D, not stated)
- [[2026-09-15 264 Anna Bryłka]] (PfE, supports)
- [[2026-09-15 265 Jadwiga Wiśniewska]] (ECR, supports)
- [[2026-09-15 270 Marion Maréchal]] (ECR, supports)
- [[2026-09-15 272 Ana Miguel Pedro]] (PPE, supports)
- [[2026-09-15 279 Silvia Sardone]] (PfE, supports)
- [[2026-09-15 282 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 285 Nikola Bartůšek (written)]] (ECR, supports)
- [[2026-09-15 288 Tomasz Froelich (written)]] (ESN, mixed)
