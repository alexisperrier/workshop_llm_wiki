---
type: topic
aliases: []
---
# External border protection

Controls, fences, surveillance, Frontex, border management.

## Positions by group

**Council and Commission.** The Commission's answer is a stronger, faster Frontex, better situational awareness and use of the new rules ([[2026-09-15 209 Magnus Brunner|Magnus Brunner]], [[2026-09-15 218 Magnus Brunner|Magnus Brunner]], [[2026-06-16 267 Magnus Brunner|Magnus Brunner]]); the Council lists stronger borders among several priorities ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 282 Thomas Byrne|Thomas Byrne]]).

**[[PPE]].** PPE speakers want Frontex strengthened and the southern border, Europe's 'weak link', defended ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]], [[2026-09-15 274 Alma Ezcurra Almansa|Alma Ezcurra Almansa]], [[2026-09-15 290 Emil Radev (written)|Emil Radev]]); [[2026-09-15 258 François-Xavier Bellamy|François-Xavier Bellamy]] says not defending borders destroys lives.

**[[S&D]].** Only [[2026-09-15 269 Eero Heinäluoma|Eero Heinäluoma]] calls for joint border surveillance; other S&D speakers reject militarisation and border closures ([[2026-09-15 261 Murielle Laurent|Murielle Laurent]]; see [[Solidarity between Member States]]).

**[[PfE]].** PfE speakers ask for the border to be restored, sealed and defended, if necessary by force ([[2026-09-15 222 Kinga Gál|Kinga Gál]], [[2026-09-15 251 Fabrice Leggeri|Fabrice Leggeri]], [[2026-09-15 264 Anna Bryłka|Anna Bryłka]]), and for illegal immigration to be fought ([[2026-09-15 279 Silvia Sardone|Silvia Sardone]]).

**[[ECR]].** ECR speakers ask for defending the southern borders, checks, walls and sealed borders ([[2026-09-15 213 Diego Solier|Diego Solier]], [[2026-09-15 265 Jadwiga Wiśniewska|Jadwiga Wiśniewska]], [[2026-09-15 278 Sebastian Tynkkynen|Sebastian Tynkkynen]]), and for a reinforced, rapidly deployable Frontex ([[2026-09-15 289 Rihards Kols (written)|Rihards Kols]]).

**[[Renew]].** Renew speakers support a more proactive Frontex and border control ([[2026-09-15 253 Malik Azmani|Malik Azmani]], [[2026-09-15 266 Jan-Christoph Oetjen|Jan-Christoph Oetjen]], [[2026-09-15 271 Abir Al-Sahlani|Abir Al-Sahlani]]), within the law and human rights ([[2026-09-15 224 Oihane Agirregoitia Martínez|Oihane Agirregoitia Martínez]]).

**[[The Left]].** The Left speakers reject the fortification of Ceuta and the outsourcing of borders to Morocco ([[2026-09-15 216 Estrella Galán|Estrella Galán]], [[2026-09-15 244 Ilaria Salis|Ilaria Salis]]).

**[[ESN]].** ESN speakers want the EU to finance physical barriers ([[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]], [[2026-09-15 231 Roberto Vannacci (answer)|Roberto Vannacci]]) and to protect borders physically ([[2026-09-15 291 Marcin Sypniewski (written)|Marcin Sypniewski]]).

**[[NI]].** [[2026-09-15 276 Malika Sorel|Malika Sorel]] asks for Frontex at the European borders.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 208 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 212 Jorge Buxadé Villalba]] (PfE, supports)
- [[2026-09-15 213 Diego Solier]] (ECR, supports)
- [[2026-09-15 216 Estrella Galán]] (The Left, opposes)
- [[2026-09-15 218 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 222 Kinga Gál]] (PfE, supports)
- [[2026-09-15 223 Assita Kanko]] (ECR, supports)
- [[2026-09-15 224 Oihane Agirregoitia Martínez]] (Renew, mixed)
- [[2026-09-15 226 Isabel Serra Sánchez]] (The Left, opposes)
- [[2026-09-15 229 Roberto Vannacci]] (ESN, supports)
- [[2026-09-15 231 Roberto Vannacci (answer)]] (ESN, supports)
- [[2026-09-15 238 Susanna Ceccardi]] (PfE, supports)
- [[2026-09-15 244 Ilaria Salis]] (The Left, opposes)
- [[2026-09-15 247 Javier Zarzalejos]] (PPE, supports)
- [[2026-09-15 251 Fabrice Leggeri]] (PfE, supports)
- [[2026-09-15 252 Alessandro Ciriani]] (ECR, supports)
- [[2026-09-15 253 Malik Azmani]] (Renew, mixed)
- [[2026-09-15 258 François-Xavier Bellamy]] (PPE, supports)
- [[2026-09-15 264 Anna Bryłka]] (PfE, supports)
- [[2026-09-15 265 Jadwiga Wiśniewska]] (ECR, supports)
- [[2026-09-15 266 Jan-Christoph Oetjen]] (Renew, mixed)
- [[2026-09-15 268 Bartłomiej Sienkiewicz]] (PPE, supports)
- [[2026-09-15 269 Eero Heinäluoma]] (S&D, supports)
- [[2026-09-15 270 Marion Maréchal]] (ECR, supports)
- [[2026-09-15 271 Abir Al-Sahlani]] (Renew, mixed)
- [[2026-09-15 272 Ana Miguel Pedro]] (PPE, supports)
- [[2026-09-15 274 Alma Ezcurra Almansa]] (PPE, supports)
- [[2026-09-15 276 Malika Sorel]] (NI, supports)
- [[2026-09-15 278 Sebastian Tynkkynen]] (ECR, supports)
- [[2026-09-15 279 Silvia Sardone]] (PfE, supports)
- [[2026-09-15 282 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 285 Nikola Bartůšek (written)]] (ECR, supports)
- [[2026-09-15 286 Joachim Stanisław Brudziński (written)]] (ECR, supports)
- [[2026-09-15 287 Loucas Fourlas (written)]] (PPE, supports)
- [[2026-09-15 289 Rihards Kols (written)]] (ECR, supports)
- [[2026-09-15 290 Emil Radev (written)]] (PPE, supports)
- [[2026-09-15 291 Marcin Sypniewski (written)]] (ESN, supports)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 267 Magnus Brunner]] (Council/Commission, supports)
- [[2026-06-16 270 Fabrice Leggeri]] (PfE, supports)
- [[2026-06-16 281 Joachim Stanisław Brudziński (written)]] (ECR, supports)
