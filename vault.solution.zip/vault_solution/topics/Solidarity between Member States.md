---
type: topic
aliases: []
---
# Solidarity between Member States

Burden sharing, help to Spain, relocation.

## Positions by group

**Council and Commission.** The Council presents emergency aid and agency support as European solidarity in action ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 282 Thomas Byrne|Thomas Byrne]]); the Commission details the EUR 114.7 million granted ([[2026-09-15 209 Magnus Brunner|Magnus Brunner]]).

**[[PPE]].** PPE speakers say solidarity was offered but not requested or accepted by Spain ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 249 Javier Zarzalejos (answer)|Javier Zarzalejos]]) and question solidarity for national negligence ([[2026-09-15 272 Ana Miguel Pedro|Ana Miguel Pedro]]).

**[[S&D]].** S&D speakers make solidarity the core of the response and say it was lacking ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]], [[2026-09-15 221 Ana Catarina Mendes|Ana Catarina Mendes]], [[2026-09-15 237 Birgit Sippel (question)|Birgit Sippel]], [[2026-09-15 250 Sandro Ruotolo (question)|Sandro Ruotolo]], [[2026-09-15 261 Murielle Laurent|Murielle Laurent]], [[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]); [[2026-09-15 269 Eero Heinäluoma|Eero Heinäluoma]] asks for support without blame.

**[[Renew]].** Renew speakers call for a united and solidary European response ([[2026-09-15 242 Fabienne Keller|Fabienne Keller]], [[2026-09-15 266 Jan-Christoph Oetjen|Jan-Christoph Oetjen]], [[2026-09-15 271 Abir Al-Sahlani|Abir Al-Sahlani]]).

**[[Verts-ALE]].** Greens speakers say the promised solidarity proved hollow as leaders closed borders instead ([[2026-09-15 243 Tineke Strik|Tineke Strik]], [[2026-09-15 248 Anna Strolenberg (question)|Anna Strolenberg]], [[2026-09-15 280 Anna Strolenberg|Anna Strolenberg]]); [[2026-09-15 215 Erik Marquardt|Erik Marquardt]] warns against mutual distrust.

**[[The Left]].** The Left speakers ask for transfers of children and vulnerable people to the mainland ([[2026-09-15 216 Estrella Galán|Estrella Galán]]) and stand with Spain's government ([[2026-09-15 257 Konstantinos Arvanitis|Konstantinos Arvanitis]]).

**[[ECR]].** ECR speakers reject forced relocations ([[2026-09-15 265 Jadwiga Wiśniewska|Jadwiga Wiśniewska]], [[2026-06-16 281 Joachim Stanisław Brudziński (written)|Joachim Stanisław Brudziński]], [[2026-06-16 282 Mariusz Kamiński (written)|Mariusz Kamiński]]) and say solidarity cannot mean some secure the borders while others debate them ([[2026-09-15 289 Rihards Kols (written)|Rihards Kols]]).

**[[ESN]].** [[2026-09-15 291 Marcin Sypniewski (written)|Marcin Sypniewski]] says solidarity should mean helping stop illegal migration, not sharing its effects.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 208 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 211 Iratxe García Pérez]] (S&D, mixed)
- [[2026-09-15 214 Veronika Cifrová Ostrihoňová]] (Renew, mixed)
- [[2026-09-15 215 Erik Marquardt]] (Verts-ALE, opposes)
- [[2026-09-15 216 Estrella Galán]] (The Left, opposes)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 222 Kinga Gál]] (PfE, supports)
- [[2026-09-15 237 Birgit Sippel (question)]] (S&D, opposes)
- [[2026-09-15 242 Fabienne Keller]] (Renew, mixed)
- [[2026-09-15 243 Tineke Strik]] (Verts-ALE, opposes)
- [[2026-09-15 248 Anna Strolenberg (question)]] (Verts-ALE, not stated)
- [[2026-09-15 249 Javier Zarzalejos (answer)]] (PPE, not stated)
- [[2026-09-15 250 Sandro Ruotolo (question)]] (S&D, opposes)
- [[2026-09-15 253 Malik Azmani]] (Renew, mixed)
- [[2026-09-15 257 Konstantinos Arvanitis]] (The Left, opposes)
- [[2026-09-15 261 Murielle Laurent]] (S&D, opposes)
- [[2026-09-15 265 Jadwiga Wiśniewska]] (ECR, supports)
- [[2026-09-15 266 Jan-Christoph Oetjen]] (Renew, mixed)
- [[2026-09-15 269 Eero Heinäluoma]] (S&D, supports)
- [[2026-09-15 271 Abir Al-Sahlani]] (Renew, mixed)
- [[2026-09-15 272 Ana Miguel Pedro]] (PPE, supports)
- [[2026-09-15 273 Juan Fernando López Aguilar]] (S&D, opposes)
- [[2026-09-15 280 Anna Strolenberg]] (Verts-ALE, opposes)
- [[2026-09-15 282 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 289 Rihards Kols (written)]] (ECR, supports)
- [[2026-09-15 291 Marcin Sypniewski (written)]] (ESN, supports)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 281 Joachim Stanisław Brudziński (written)]] (ECR, supports)
- [[2026-06-16 282 Mariusz Kamiński (written)]] (ECR, supports)
