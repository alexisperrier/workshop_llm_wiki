---
type: topic
aliases: []
---
# Majorities in Parliament

Who votes with whom, e.g. the PPE and the groups to its right. Added with the Return Regulation debate.

## Positions by group

**[[PPE]].** [[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]] says the final text is based on the EPP's own; in the Ceuta debate [[2026-09-15 236 Lena Düpont (answer)|Lena Düpont]] rejects a PfE speaker's complaint about the EPP.

**[[PfE]].** [[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]] says the vote shows what the right of the House can do together; [[2026-09-15 235 András László (question)|András László]] attacks the EPP-led Commission.

**[[ECR]].** ECR speakers ask the EPP to work with them ([[2026-09-15 223 Assita Kanko|Assita Kanko]]), divide the House into common sense and the far left ([[2026-06-16 271 Charlie Weimers|Charlie Weimers]]) and blame the left-wing majority for past blockage ([[2026-06-16 285 Ivaylo Valchev (written)|Ivaylo Valchev]]).

**[[ESN]].** [[2026-06-16 275 Mary Khan|Mary Khan]] says the vote shows what happens when parties drop their 'cowardice'.

**[[S&D]].** [[2026-06-16 269 Murielle Laurent|Murielle Laurent]] accuses the right of turning Parliament into a sounding board for national campaigns.

**[[Renew]].** [[2026-06-16 272 Fabienne Keller|Fabienne Keller]] warns against approving the text under far-right pressure.

**[[Verts-ALE]].** [[2026-06-16 273 Mélissa Camara|Mélissa Camara]] calls the regulation the fruit of open collaboration between the EPP and the far right.

**[[The Left]].** [[2026-06-16 274 Estrella Galán|Estrella Galán]] says the EPP has been ideologically captured by the far right.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 223 Assita Kanko]] (ECR, supports)
- [[2026-09-15 235 András László (question)]] (PfE, not stated)
- [[2026-09-15 236 Lena Düpont (answer)]] (PPE, not stated)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 268 François-Xavier Bellamy]] (PPE, supports)
- [[2026-06-16 269 Murielle Laurent]] (S&D, opposes)
- [[2026-06-16 270 Fabrice Leggeri]] (PfE, supports)
- [[2026-06-16 271 Charlie Weimers]] (ECR, supports)
- [[2026-06-16 272 Fabienne Keller]] (Renew, opposes)
- [[2026-06-16 273 Mélissa Camara]] (Verts-ALE, opposes)
- [[2026-06-16 274 Estrella Galán]] (The Left, opposes)
- [[2026-06-16 275 Mary Khan]] (ESN, supports)
- [[2026-06-16 285 Ivaylo Valchev (written)]] (ECR, supports)
