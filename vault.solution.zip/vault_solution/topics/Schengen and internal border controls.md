---
type: topic
aliases: []
---
# Schengen and internal border controls

Free movement, reintroduced internal border controls.

## Positions by group

**Council and Commission.** The Council and Commission say Ceuta's special status kept the Schengen area intact and that Schengen must be preserved ([[2026-09-15 209 Magnus Brunner|Magnus Brunner]], [[2026-09-15 218 Magnus Brunner|Magnus Brunner]], [[2026-09-15 282 Thomas Byrne|Thomas Byrne]]).

**[[PPE]].** PPE speakers say protecting Schengen begins with the external border ([[2026-09-15 290 Emil Radev (written)|Emil Radev]]) and point to the revised Schengen Borders Code ([[2026-09-15 234 Lena Düpont|Lena Düpont]]).

**[[S&D]].** S&D speakers condemn Italy's border controls on Spain as senseless or illegal ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]], [[2026-09-15 237 Birgit Sippel (question)|Birgit Sippel]], [[2026-09-15 250 Sandro Ruotolo (question)|Sandro Ruotolo]], [[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]).

**[[Renew]].** Renew speakers call Italy's controls disproportionate and ask for them to be lifted ([[2026-09-15 242 Fabienne Keller|Fabienne Keller]], [[2026-09-15 266 Jan-Christoph Oetjen|Jan-Christoph Oetjen]]), and reject suspending Schengen ([[2026-09-15 271 Abir Al-Sahlani|Abir Al-Sahlani]]).

**[[Verts-ALE]].** [[2026-09-15 243 Tineke Strik|Tineke Strik]] says Italy unlawfully reintroduced border controls.

**[[The Left]].** [[2026-09-15 244 Ilaria Salis|Ilaria Salis]] criticises the Italian government for blocking Schengen with Spain.

**[[PfE]].** PfE speakers stress that Ceuta is in Schengen ([[2026-09-15 251 Fabrice Leggeri|Fabrice Leggeri]]) and call for Spain's exclusion ([[2026-09-15 264 Anna Bryłka|Anna Bryłka]]).

**[[ECR]].** [[2026-09-15 270 Marion Maréchal|Marion Maréchal]] praises Italy's border closure and proposes reserving free movement to EU residents; [[2026-09-15 265 Jadwiga Wiśniewska|Jadwiga Wiśniewska]] says Schengen must not die in Ceuta.

**[[ESN]].** [[2026-09-15 217 Mary Khan|Mary Khan]] demands Spain's temporary exclusion from Schengen.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 208 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 211 Iratxe García Pérez]] (S&D, mixed)
- [[2026-09-15 217 Mary Khan]] (ESN, supports)
- [[2026-09-15 218 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 234 Lena Düpont]] (PPE, supports)
- [[2026-09-15 237 Birgit Sippel (question)]] (S&D, opposes)
- [[2026-09-15 242 Fabienne Keller]] (Renew, mixed)
- [[2026-09-15 243 Tineke Strik]] (Verts-ALE, opposes)
- [[2026-09-15 244 Ilaria Salis]] (The Left, opposes)
- [[2026-09-15 250 Sandro Ruotolo (question)]] (S&D, opposes)
- [[2026-09-15 251 Fabrice Leggeri]] (PfE, supports)
- [[2026-09-15 261 Murielle Laurent]] (S&D, opposes)
- [[2026-09-15 264 Anna Bryłka]] (PfE, supports)
- [[2026-09-15 265 Jadwiga Wiśniewska]] (ECR, supports)
- [[2026-09-15 266 Jan-Christoph Oetjen]] (Renew, mixed)
- [[2026-09-15 270 Marion Maréchal]] (ECR, supports)
- [[2026-09-15 271 Abir Al-Sahlani]] (Renew, mixed)
- [[2026-09-15 273 Juan Fernando López Aguilar]] (S&D, opposes)
- [[2026-09-15 282 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 290 Emil Radev (written)]] (PPE, supports)
