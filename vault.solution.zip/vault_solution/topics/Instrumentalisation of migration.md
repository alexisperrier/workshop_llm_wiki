---
type: topic
aliases: []
---
# Instrumentalisation of migration

Migrants used by a state as a means of pressure; hybrid attacks.

## Positions by group

**Council and Commission.** The Council and the Commission treat Ceuta as instrumentalisation backed by information manipulation, to be answered with early warning, a stronger Frontex and unity ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 209 Magnus Brunner|Magnus Brunner]]).

**[[PPE]].** PPE speakers call the events a hybrid attack or 'textbook hybrid war' and demand an EU emergency mechanism and firm defence of the border ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]], [[2026-09-15 274 Alma Ezcurra Almansa|Alma Ezcurra Almansa]], [[2026-09-15 287 Loucas Fourlas (written)|Loucas Fourlas]], [[2026-09-15 290 Emil Radev (written)|Emil Radev]]); [[2026-09-15 268 Bartłomiej Sienkiewicz|Bartłomiej Sienkiewicz]] argues that a mass storming cannot be handled under individual asylum law.

**[[S&D]].** S&D speakers accept the hybrid-attack reading ([[2026-09-15 221 Ana Catarina Mendes|Ana Catarina Mendes]], [[2026-09-15 250 Sandro Ruotolo (question)|Sandro Ruotolo]]) but see disinformation and division as its real goal and answer it with solidarity ([[2026-09-15 237 Birgit Sippel (question)|Birgit Sippel]]); [[2026-09-15 269 Eero Heinäluoma|Eero Heinäluoma]] draws the parallel with Russia's pressure on Finland.

**[[PfE]].** PfE speakers call the events an invasion to be fought, territorial or Islamic ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]], [[2026-09-15 222 Kinga Gál|Kinga Gál]], [[2026-09-15 238 Susanna Ceccardi|Susanna Ceccardi]]).

**[[ECR]].** ECR speakers say the instrumentalisation was predictable and blame Spanish policy for making it possible ([[2026-09-15 252 Alessandro Ciriani|Alessandro Ciriani]], [[2026-09-15 285 Nikola Bartůšek (written)|Nikola Bartůšek]]), compare it with Belarus ([[2026-09-15 289 Rihards Kols (written)|Rihards Kols]]) or call it an Islamic conquest ([[2026-09-15 278 Sebastian Tynkkynen|Sebastian Tynkkynen]]).

**[[Renew]].** Renew speakers acknowledge the instrumentalisation but stress disinformation and early warning ([[2026-09-15 214 Veronika Cifrová Ostrihoňová|Veronika Cifrová Ostrihoňová]], [[2026-09-15 242 Fabienne Keller|Fabienne Keller]]) and a firm but humane response ([[2026-09-15 271 Abir Al-Sahlani|Abir Al-Sahlani]]); [[2026-09-15 230 Lukas Sieper (question)|Lukas Sieper]] asks whether a hybrid attack makes it an invasion.

**[[Verts-ALE]].** Greens speakers argue that treating instrumentalised people as invaders makes the instrumentalisation succeed ([[2026-09-15 215 Erik Marquardt|Erik Marquardt]]) and that punishing its victims is itself instrumentalisation ([[2026-09-15 243 Tineke Strik|Tineke Strik]]); [[2026-09-15 254 Tineke Strik (question)|Tineke Strik]] warns that return hubs create new dependence and blackmail.

**[[The Left]].** The Left speakers place responsibility on Morocco and its foreign backers rather than on the migrants ([[2026-09-15 216 Estrella Galán|Estrella Galán]], [[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]], [[2026-09-15 267 Pernando Barrena Arza|Pernando Barrena Arza]]) and on political centres seeking to destabilise left-wing governments ([[2026-09-15 257 Konstantinos Arvanitis|Konstantinos Arvanitis]]).

**[[ESN]].** ESN speakers call it an invasion and an act of war ([[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]], [[2026-09-15 231 Roberto Vannacci (answer)|Roberto Vannacci]]) and urge pressure on Morocco ([[2026-09-15 288 Tomasz Froelich (written)|Tomasz Froelich]], [[2026-09-15 291 Marcin Sypniewski (written)|Marcin Sypniewski]]).

**[[NI]].** [[2026-09-15 276 Malika Sorel|Malika Sorel]] reports the view of Ceuta's president that Morocco used illegal immigration to violate EU borders.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 208 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 211 Iratxe García Pérez]] (S&D, mixed)
- [[2026-09-15 212 Jorge Buxadé Villalba]] (PfE, supports)
- [[2026-09-15 214 Veronika Cifrová Ostrihoňová]] (Renew, mixed)
- [[2026-09-15 215 Erik Marquardt]] (Verts-ALE, opposes)
- [[2026-09-15 216 Estrella Galán]] (The Left, opposes)
- [[2026-09-15 217 Mary Khan]] (ESN, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 222 Kinga Gál]] (PfE, supports)
- [[2026-09-15 226 Isabel Serra Sánchez]] (The Left, opposes)
- [[2026-09-15 229 Roberto Vannacci]] (ESN, supports)
- [[2026-09-15 230 Lukas Sieper (question)]] (Renew, not stated)
- [[2026-09-15 231 Roberto Vannacci (answer)]] (ESN, supports)
- [[2026-09-15 237 Birgit Sippel (question)]] (S&D, opposes)
- [[2026-09-15 238 Susanna Ceccardi]] (PfE, supports)
- [[2026-09-15 242 Fabienne Keller]] (Renew, mixed)
- [[2026-09-15 243 Tineke Strik]] (Verts-ALE, opposes)
- [[2026-09-15 247 Javier Zarzalejos]] (PPE, supports)
- [[2026-09-15 250 Sandro Ruotolo (question)]] (S&D, opposes)
- [[2026-09-15 252 Alessandro Ciriani]] (ECR, supports)
- [[2026-09-15 254 Tineke Strik (question)]] (Verts-ALE, not stated)
- [[2026-09-15 257 Konstantinos Arvanitis]] (The Left, opposes)
- [[2026-09-15 267 Pernando Barrena Arza]] (The Left, not stated)
- [[2026-09-15 268 Bartłomiej Sienkiewicz]] (PPE, supports)
- [[2026-09-15 269 Eero Heinäluoma]] (S&D, supports)
- [[2026-09-15 271 Abir Al-Sahlani]] (Renew, mixed)
- [[2026-09-15 274 Alma Ezcurra Almansa]] (PPE, supports)
- [[2026-09-15 276 Malika Sorel]] (NI, supports)
- [[2026-09-15 277 Juan Ignacio Zoido Álvarez]] (PPE, supports)
- [[2026-09-15 278 Sebastian Tynkkynen]] (ECR, supports)
- [[2026-09-15 285 Nikola Bartůšek (written)]] (ECR, supports)
- [[2026-09-15 287 Loucas Fourlas (written)]] (PPE, supports)
- [[2026-09-15 288 Tomasz Froelich (written)]] (ESN, mixed)
- [[2026-09-15 289 Rihards Kols (written)]] (ECR, supports)
- [[2026-09-15 290 Emil Radev (written)]] (PPE, supports)
- [[2026-09-15 291 Marcin Sypniewski (written)]] (ESN, supports)
