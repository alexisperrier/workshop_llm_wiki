---
type: topic
aliases: []
---
# Return hubs

Return centres in third countries, e.g. the Italian centre in Albania. Added with the Return Regulation debate.

## Positions by group

**[[PPE]].** [[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]] welcomes return centres as an end to the blackmail of regimes that block returns.

**[[Renew]].** The rapporteur presents return hubs as one tool for enforcing returns ([[2026-06-16 266 Malik Azmani|Malik Azmani]]) and defends cooperation with third countries as realpolitik ([[2026-09-15 255 Malik Azmani (answer)|Malik Azmani]]); [[2026-06-16 283 Katri Kulmuni (written)|Katri Kulmuni]] notes the possibility of centres outside the EU.

**[[S&D]].** [[2026-06-16 269 Murielle Laurent|Murielle Laurent]] says return hubs are placed far away to avoid scrutiny.

**[[Verts-ALE]].** [[2026-09-15 254 Tineke Strik (question)|Tineke Strik]] warns that return hubs create dependence on autocracies; [[2026-06-16 273 Mélissa Camara|Mélissa Camara]] describes the Italian centre in Albania as dehumanising.

**[[The Left]].** [[2026-06-16 274 Estrella Galán|Estrella Galán]] calls the centres 'European Guantánamos'.

**[[PfE]].** [[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]] welcomes return hubs outside the EU.

**[[ECR]].** ECR speakers welcome 'big, beautiful return hubs' and centres outside the EU ([[2026-06-16 271 Charlie Weimers|Charlie Weimers]], [[2026-06-16 282 Mariusz Kamiński (written)|Mariusz Kamiński]]).

**[[ESN]].** [[2026-06-16 275 Mary Khan|Mary Khan]] says Germany can now prepare return centres.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 254 Tineke Strik (question)]] (Verts-ALE, not stated)
- [[2026-09-15 255 Malik Azmani (answer)]] (Renew, not stated)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 266 Malik Azmani]] (Renew, supports)
- [[2026-06-16 268 François-Xavier Bellamy]] (PPE, supports)
- [[2026-06-16 269 Murielle Laurent]] (S&D, opposes)
- [[2026-06-16 270 Fabrice Leggeri]] (PfE, supports)
- [[2026-06-16 271 Charlie Weimers]] (ECR, supports)
- [[2026-06-16 273 Mélissa Camara]] (Verts-ALE, opposes)
- [[2026-06-16 274 Estrella Galán]] (The Left, opposes)
- [[2026-06-16 275 Mary Khan]] (ESN, supports)
- [[2026-06-16 282 Mariusz Kamiński (written)]] (ECR, supports)
- [[2026-06-16 283 Katri Kulmuni (written)]] (Renew, mixed)
