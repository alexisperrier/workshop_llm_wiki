---
type: topic
aliases: []
---
# Returns

Return of people with no right to stay, return agreements.

## Positions by group

**Council and Commission.** The Council and the Commission want swift returns to Morocco and better return rates, with the Return Regulation as the main tool ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 209 Magnus Brunner|Magnus Brunner]], [[2026-09-15 218 Magnus Brunner|Magnus Brunner]], [[2026-09-15 282 Thomas Byrne|Thomas Byrne]], [[2026-06-16 267 Magnus Brunner|Magnus Brunner]], [[2026-06-16 276 Magnus Brunner|Magnus Brunner]]).

**[[PPE]].** PPE speakers want all irregular migrants returned, minors included ([[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]]), and present the Return Regulation as ending decades of powerlessness ([[2026-09-15 258 François-Xavier Bellamy|François-Xavier Bellamy]], [[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]]); [[2026-09-15 249 Javier Zarzalejos (answer)|Javier Zarzalejos]] notes that the Spanish government voted against it.

**[[S&D]].** S&D speakers accept returns in principle but within the law ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]]) and reject the regulation's methods ([[2026-06-16 269 Murielle Laurent|Murielle Laurent]]).

**[[Renew]].** Renew speakers support returns within the law ([[2026-09-15 224 Oihane Agirregoitia Martínez|Oihane Agirregoitia Martínez]]); the rapporteur defends the regulation as effective and rights-based ([[2026-06-16 266 Malik Azmani|Malik Azmani]], [[2026-06-16 277 Malik Azmani|Malik Azmani]]), while [[2026-06-16 272 Fabienne Keller|Fabienne Keller]] opposes it for families with children and [[2026-06-16 283 Katri Kulmuni (written)|Katri Kulmuni]] supports it with reservations.

**[[Verts-ALE]].** Greens speakers condemn the 'Send them back' climate around the regulation ([[2026-09-15 256 Ana Miranda Paz|Ana Miranda Paz]]) and ask for dignified returns ([[2026-09-15 280 Anna Strolenberg|Anna Strolenberg]]).

**[[PfE]].** PfE speakers want those Morocco claims sent back and illegal migrants expelled ([[2026-09-15 251 Fabrice Leggeri|Fabrice Leggeri]], [[2026-09-15 264 Anna Bryłka|Anna Bryłka]]), and welcome the regulation as a change of course ([[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]]).

**[[ECR]].** ECR speakers want returns without delay and celebrate the 'era of deportations' ([[2026-09-15 213 Diego Solier|Diego Solier]], [[2026-09-15 252 Alessandro Ciriani|Alessandro Ciriani]], [[2026-06-16 271 Charlie Weimers|Charlie Weimers]], [[2026-06-16 281 Joachim Stanisław Brudziński (written)|Joachim Stanisław Brudziński]], [[2026-06-16 282 Mariusz Kamiński (written)|Mariusz Kamiński]], [[2026-06-16 285 Ivaylo Valchev (written)|Ivaylo Valchev]]).

**[[ESN]].** ESN speakers call for rapid returns and support the regulation's harsher rules ([[2026-09-15 291 Marcin Sypniewski (written)|Marcin Sypniewski]], [[2026-06-16 275 Mary Khan|Mary Khan]], [[2026-06-16 284 Marcin Sypniewski (written)|Marcin Sypniewski]]).

**[[NI]].** [[2026-09-15 276 Malika Sorel|Malika Sorel]] asks for the return of all arrivals, minors included; [[2026-06-16 280 Nikola Bartůšek (written)|Nikola Bartůšek]] calls the regulation a necessary correction.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 208 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 211 Iratxe García Pérez]] (S&D, mixed)
- [[2026-09-15 213 Diego Solier]] (ECR, supports)
- [[2026-09-15 218 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 224 Oihane Agirregoitia Martínez]] (Renew, mixed)
- [[2026-09-15 234 Lena Düpont]] (PPE, supports)
- [[2026-09-15 249 Javier Zarzalejos (answer)]] (PPE, not stated)
- [[2026-09-15 251 Fabrice Leggeri]] (PfE, supports)
- [[2026-09-15 252 Alessandro Ciriani]] (ECR, supports)
- [[2026-09-15 255 Malik Azmani (answer)]] (Renew, not stated)
- [[2026-09-15 256 Ana Miranda Paz]] (Verts-ALE, opposes)
- [[2026-09-15 258 François-Xavier Bellamy]] (PPE, supports)
- [[2026-09-15 264 Anna Bryłka]] (PfE, supports)
- [[2026-09-15 265 Jadwiga Wiśniewska]] (ECR, supports)
- [[2026-09-15 276 Malika Sorel]] (NI, supports)
- [[2026-09-15 277 Juan Ignacio Zoido Álvarez]] (PPE, supports)
- [[2026-09-15 278 Sebastian Tynkkynen]] (ECR, supports)
- [[2026-09-15 280 Anna Strolenberg]] (Verts-ALE, opposes)
- [[2026-09-15 282 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 287 Loucas Fourlas (written)]] (PPE, supports)
- [[2026-09-15 289 Rihards Kols (written)]] (ECR, supports)
- [[2026-09-15 290 Emil Radev (written)]] (PPE, supports)
- [[2026-09-15 291 Marcin Sypniewski (written)]] (ESN, supports)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 266 Malik Azmani]] (Renew, supports)
- [[2026-06-16 267 Magnus Brunner]] (Council/Commission, supports)
- [[2026-06-16 268 François-Xavier Bellamy]] (PPE, supports)
- [[2026-06-16 269 Murielle Laurent]] (S&D, opposes)
- [[2026-06-16 270 Fabrice Leggeri]] (PfE, supports)
- [[2026-06-16 271 Charlie Weimers]] (ECR, supports)
- [[2026-06-16 272 Fabienne Keller]] (Renew, opposes)
- [[2026-06-16 275 Mary Khan]] (ESN, supports)
- [[2026-06-16 276 Magnus Brunner]] (Council/Commission, supports)
- [[2026-06-16 277 Malik Azmani]] (Renew, supports)
- [[2026-06-16 280 Nikola Bartůšek (written)]] (NI, supports)
- [[2026-06-16 281 Joachim Stanisław Brudziński (written)]] (ECR, supports)
- [[2026-06-16 282 Mariusz Kamiński (written)]] (ECR, supports)
- [[2026-06-16 283 Katri Kulmuni (written)]] (Renew, mixed)
- [[2026-06-16 284 Marcin Sypniewski (written)]] (ESN, supports)
- [[2026-06-16 285 Ivaylo Valchev (written)]] (ECR, supports)
