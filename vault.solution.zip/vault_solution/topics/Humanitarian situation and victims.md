---
type: topic
aliases: []
---
# Humanitarian situation and victims

Deaths, injuries, reception conditions, unaccompanied minors, rights of migrants.

## Positions by group

**Council and Commission.** The Council and Commission express condolences for the dead and stress the 2,000 unaccompanied minors in Ceuta ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 209 Magnus Brunner|Magnus Brunner]]).

**[[PPE]].** PPE speakers describe the suffering of Ceuta's residents and the victims of illegal immigration ([[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 258 François-Xavier Bellamy|François-Xavier Bellamy]]), and the bodies not repatriated by Morocco ([[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]]).

**[[S&D]].** S&D speakers recall the dead and ask for the protection of unaccompanied minors ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]], [[2026-09-15 237 Birgit Sippel (question)|Birgit Sippel]], [[2026-09-15 261 Murielle Laurent|Murielle Laurent]], [[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]) and object to the detention of minors under the Return Regulation ([[2026-06-16 269 Murielle Laurent|Murielle Laurent]]).

**[[Renew]].** Renew speakers ask for the protection of the unaccompanied minors ([[2026-09-15 242 Fabienne Keller|Fabienne Keller]], [[2026-09-15 253 Malik Azmani|Malik Azmani]]) and oppose returning families with children ([[2026-06-16 272 Fabienne Keller|Fabienne Keller]]).

**[[Verts-ALE]].** Greens speakers centre the 141 dead and human dignity ([[2026-09-15 215 Erik Marquardt|Erik Marquardt]], [[2026-09-15 243 Tineke Strik|Tineke Strik]]) and describe conditions in the Italian centre in Albania ([[2026-06-16 273 Mélissa Camara|Mélissa Camara]]).

**[[The Left]].** The Left speakers frame migrants as victims of geopolitics and of a colonial system ([[2026-09-15 216 Estrella Galán|Estrella Galán]], [[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]], [[2026-09-15 244 Ilaria Salis|Ilaria Salis]]) and denounce the detention of children ([[2026-06-16 274 Estrella Galán|Estrella Galán]]).

**[[PfE]].** PfE speakers stress insecurity and sexual assaults suffered by residents ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]], [[2026-09-15 251 Fabrice Leggeri|Fabrice Leggeri]], [[2026-09-15 279 Silvia Sardone|Silvia Sardone]]).

**[[ECR]].** ECR speakers describe crime, fear and shanty towns in Ceuta ([[2026-09-15 241 Nora Junco García|Nora Junco García]], [[2026-09-15 270 Marion Maréchal|Marion Maréchal]], [[2026-09-15 286 Joachim Stanisław Brudziński (written)|Joachim Stanisław Brudziński]]).

**[[ESN]].** ESN speakers describe Ceuta as a slum with daily sexual assaults ([[2026-09-15 217 Mary Khan|Mary Khan]]) and cite rising crime ([[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]]).

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 208 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 211 Iratxe García Pérez]] (S&D, mixed)
- [[2026-09-15 212 Jorge Buxadé Villalba]] (PfE, supports)
- [[2026-09-15 213 Diego Solier]] (ECR, supports)
- [[2026-09-15 214 Veronika Cifrová Ostrihoňová]] (Renew, mixed)
- [[2026-09-15 215 Erik Marquardt]] (Verts-ALE, opposes)
- [[2026-09-15 216 Estrella Galán]] (The Left, opposes)
- [[2026-09-15 217 Mary Khan]] (ESN, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 224 Oihane Agirregoitia Martínez]] (Renew, mixed)
- [[2026-09-15 225 Jaume Asens Llodrà]] (Verts-ALE, not stated)
- [[2026-09-15 226 Isabel Serra Sánchez]] (The Left, opposes)
- [[2026-09-15 227 Diego Solier (question)]] (ECR, not stated)
- [[2026-09-15 228 Isabel Serra Sánchez (answer)]] (The Left, not stated)
- [[2026-09-15 229 Roberto Vannacci]] (ESN, supports)
- [[2026-09-15 237 Birgit Sippel (question)]] (S&D, opposes)
- [[2026-09-15 241 Nora Junco García]] (ECR, supports)
- [[2026-09-15 242 Fabienne Keller]] (Renew, mixed)
- [[2026-09-15 243 Tineke Strik]] (Verts-ALE, opposes)
- [[2026-09-15 244 Ilaria Salis]] (The Left, opposes)
- [[2026-09-15 246 Ilaria Salis (answer)]] (The Left, opposes)
- [[2026-09-15 247 Javier Zarzalejos]] (PPE, supports)
- [[2026-09-15 250 Sandro Ruotolo (question)]] (S&D, opposes)
- [[2026-09-15 251 Fabrice Leggeri]] (PfE, supports)
- [[2026-09-15 253 Malik Azmani]] (Renew, mixed)
- [[2026-09-15 256 Ana Miranda Paz]] (Verts-ALE, opposes)
- [[2026-09-15 258 François-Xavier Bellamy]] (PPE, supports)
- [[2026-09-15 261 Murielle Laurent]] (S&D, opposes)
- [[2026-09-15 268 Bartłomiej Sienkiewicz]] (PPE, supports)
- [[2026-09-15 270 Marion Maréchal]] (ECR, supports)
- [[2026-09-15 271 Abir Al-Sahlani]] (Renew, mixed)
- [[2026-09-15 273 Juan Fernando López Aguilar]] (S&D, opposes)
- [[2026-09-15 274 Alma Ezcurra Almansa]] (PPE, supports)
- [[2026-09-15 276 Malika Sorel]] (NI, supports)
- [[2026-09-15 278 Sebastian Tynkkynen]] (ECR, supports)
- [[2026-09-15 279 Silvia Sardone]] (PfE, supports)
- [[2026-09-15 280 Anna Strolenberg]] (Verts-ALE, opposes)
- [[2026-09-15 286 Joachim Stanisław Brudziński (written)]] (ECR, supports)
- [[2026-09-15 287 Loucas Fourlas (written)]] (PPE, supports)
- [[2026-09-15 289 Rihards Kols (written)]] (ECR, supports)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 269 Murielle Laurent]] (S&D, opposes)
- [[2026-06-16 272 Fabienne Keller]] (Renew, opposes)
- [[2026-06-16 273 Mélissa Camara]] (Verts-ALE, opposes)
- [[2026-06-16 274 Estrella Galán]] (The Left, opposes)
- [[2026-06-16 283 Katri Kulmuni (written)]] (Renew, mixed)
