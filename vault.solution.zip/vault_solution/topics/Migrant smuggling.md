---
type: topic
aliases: []
---
# Migrant smuggling

Smugglers, trafficking networks.

## Positions by group

**Council and Commission.** The Council and Commission make dismantling smuggling networks a priority and ask for the anti-smuggling directive ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 209 Magnus Brunner|Magnus Brunner]], [[2026-09-15 282 Thomas Byrne|Thomas Byrne]]).

**[[PPE]].** PPE speakers say rewarding illegal immigration empowers smugglers ([[2026-09-15 258 François-Xavier Bellamy|François-Xavier Bellamy]]) and welcome the regulation's tools against them ([[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]]).

**[[S&D]].** [[2026-09-15 221 Ana Catarina Mendes|Ana Catarina Mendes]] names smugglers and disinformation as the main culprits and calls for legal routes.

**[[Renew]].** Renew speakers call for fighting the mafias ([[2026-09-15 224 Oihane Agirregoitia Martínez|Oihane Agirregoitia Martínez]], [[2026-09-15 271 Abir Al-Sahlani|Abir Al-Sahlani]]).

**[[ECR]].** ECR speakers link legalisations to the smugglers' business model ([[2026-09-15 262 Nicolas Bay (question)|Nicolas Bay]], [[2026-09-15 285 Nikola Bartůšek (written)|Nikola Bartůšek]]) and want the state, not smugglers, to decide who enters ([[2026-06-16 282 Mariusz Kamiński (written)|Mariusz Kamiński]]).

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 208 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 224 Oihane Agirregoitia Martínez]] (Renew, mixed)
- [[2026-09-15 258 François-Xavier Bellamy]] (PPE, supports)
- [[2026-09-15 262 Nicolas Bay (question)]] (ECR, not stated)
- [[2026-09-15 265 Jadwiga Wiśniewska]] (ECR, supports)
- [[2026-09-15 271 Abir Al-Sahlani]] (Renew, mixed)
- [[2026-09-15 282 Thomas Byrne]] (Council/Commission, mixed)
- [[2026-09-15 285 Nikola Bartůšek (written)]] (ECR, supports)
- [[2026-09-15 287 Loucas Fourlas (written)]] (PPE, supports)
- [[2026-09-15 291 Marcin Sypniewski (written)]] (ESN, supports)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 268 François-Xavier Bellamy]] (PPE, supports)
- [[2026-06-16 282 Mariusz Kamiński (written)]] (ECR, supports)
