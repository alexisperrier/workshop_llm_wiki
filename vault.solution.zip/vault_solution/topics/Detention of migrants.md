---
type: topic
aliases: []
---
# Detention of migrants

Detention before return, including families and children. Added with the Return Regulation debate.

## Positions by group

**[[PPE]].** [[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]] welcomes unlimited detention for dangerous individuals.

**[[Renew]].** [[2026-06-16 266 Malik Azmani|Malik Azmani]] presents broader possibilities to act against absconding as part of the regulation.

**[[S&D]].** [[2026-06-16 269 Murielle Laurent|Murielle Laurent]] objects to the detention of unaccompanied minors and families with children.

**[[Verts-ALE]].** [[2026-06-16 273 Mélissa Camara|Mélissa Camara]] opposes the detention of families in centres without rights monitoring.

**[[The Left]].** [[2026-06-16 274 Estrella Galán|Estrella Galán]] denounces detention of children for up to 30 months.

**[[PfE]].** [[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]] welcomes the extension of detention to 24 months.

**[[ECR]].** [[2026-06-16 271 Charlie Weimers|Charlie Weimers]] welcomes detaining criminals for as long as necessary.

**[[ESN]].** [[2026-06-16 284 Marcin Sypniewski (written)|Marcin Sypniewski]] supports detention of up to 24 months for security threats.

## Speeches

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 266 Malik Azmani]] (Renew, supports)
- [[2026-06-16 268 François-Xavier Bellamy]] (PPE, supports)
- [[2026-06-16 269 Murielle Laurent]] (S&D, opposes)
- [[2026-06-16 270 Fabrice Leggeri]] (PfE, supports)
- [[2026-06-16 271 Charlie Weimers]] (ECR, supports)
- [[2026-06-16 273 Mélissa Camara]] (Verts-ALE, opposes)
- [[2026-06-16 274 Estrella Galán]] (The Left, opposes)
- [[2026-06-16 284 Marcin Sypniewski (written)]] (ESN, supports)
