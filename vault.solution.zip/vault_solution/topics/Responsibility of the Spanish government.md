---
type: topic
aliases: []
---
# Responsibility of the Spanish government

Criticism or defence of how the Spanish government handled the events.

## Positions by group

**Council and Commission.** The Council says the Spanish authorities acted quickly to restore control ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]]).

**[[PPE]].** PPE speakers say Pedro Sánchez ignored warnings, went on holiday and failed to request EU help ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 277 Juan Ignacio Zoido Álvarez|Juan Ignacio Zoido Álvarez]]), and failed to apply the Pact ([[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]], [[2026-09-15 272 Ana Miguel Pedro|Ana Miguel Pedro]]).

**[[S&D]].** S&D speakers defend the Spanish government's legal and humane response ([[2026-09-15 221 Ana Catarina Mendes|Ana Catarina Mendes]], [[2026-09-15 261 Murielle Laurent|Murielle Laurent]], [[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]) and accuse the PPE of exploiting the crisis ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]]).

**[[Renew]].** Renew speakers say Spain acted too hesitantly but deserves solidarity ([[2026-09-15 266 Jan-Christoph Oetjen|Jan-Christoph Oetjen]]) and do not ignore its responsibility ([[2026-09-15 224 Oihane Agirregoitia Martínez|Oihane Agirregoitia Martínez]]).

**[[PfE]].** PfE speakers blame the socialist government's migration policy ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]], [[2026-09-15 222 Kinga Gál|Kinga Gál]], [[2026-09-15 264 Anna Bryłka|Anna Bryłka]], [[2026-09-15 279 Silvia Sardone|Silvia Sardone]]).

**[[ECR]].** ECR speakers say the Sánchez government mismanaged and minimised the crisis ([[2026-09-15 241 Nora Junco García|Nora Junco García]], [[2026-09-15 252 Alessandro Ciriani|Alessandro Ciriani]], [[2026-09-15 270 Marion Maréchal|Marion Maréchal]], [[2026-09-15 286 Joachim Stanisław Brudziński (written)|Joachim Stanisław Brudziński]]).

**[[ESN]].** ESN speakers blame Sánchez's 'selfish' migration policy for the incentives ([[2026-09-15 217 Mary Khan|Mary Khan]], [[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]], [[2026-09-15 288 Tomasz Froelich (written)|Tomasz Froelich]]).

**[[The Left]].** The Left speakers stand with Spain's government ([[2026-09-15 257 Konstantinos Arvanitis|Konstantinos Arvanitis]]) while criticising all Spanish governments' alliance with Morocco ([[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]]).

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 211 Iratxe García Pérez]] (S&D, mixed)
- [[2026-09-15 212 Jorge Buxadé Villalba]] (PfE, supports)
- [[2026-09-15 213 Diego Solier]] (ECR, supports)
- [[2026-09-15 217 Mary Khan]] (ESN, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 222 Kinga Gál]] (PfE, supports)
- [[2026-09-15 224 Oihane Agirregoitia Martínez]] (Renew, mixed)
- [[2026-09-15 226 Isabel Serra Sánchez]] (The Left, opposes)
- [[2026-09-15 229 Roberto Vannacci]] (ESN, supports)
- [[2026-09-15 234 Lena Düpont]] (PPE, supports)
- [[2026-09-15 241 Nora Junco García]] (ECR, supports)
- [[2026-09-15 247 Javier Zarzalejos]] (PPE, supports)
- [[2026-09-15 251 Fabrice Leggeri]] (PfE, supports)
- [[2026-09-15 252 Alessandro Ciriani]] (ECR, supports)
- [[2026-09-15 257 Konstantinos Arvanitis]] (The Left, opposes)
- [[2026-09-15 258 François-Xavier Bellamy]] (PPE, supports)
- [[2026-09-15 259 Alvise Pérez (question)]] (NI, not stated)
- [[2026-09-15 261 Murielle Laurent]] (S&D, opposes)
- [[2026-09-15 262 Nicolas Bay (question)]] (ECR, not stated)
- [[2026-09-15 264 Anna Bryłka]] (PfE, supports)
- [[2026-09-15 266 Jan-Christoph Oetjen]] (Renew, mixed)
- [[2026-09-15 270 Marion Maréchal]] (ECR, supports)
- [[2026-09-15 272 Ana Miguel Pedro]] (PPE, supports)
- [[2026-09-15 273 Juan Fernando López Aguilar]] (S&D, opposes)
- [[2026-09-15 274 Alma Ezcurra Almansa]] (PPE, supports)
- [[2026-09-15 277 Juan Ignacio Zoido Álvarez]] (PPE, supports)
- [[2026-09-15 279 Silvia Sardone]] (PfE, supports)
- [[2026-09-15 286 Joachim Stanisław Brudziński (written)]] (ECR, supports)
- [[2026-09-15 288 Tomasz Froelich (written)]] (ESN, mixed)
