---
type: topic
aliases: []
---
# Pact on Migration and Asylum

The Pact, its implementation, its crisis rules.

## Positions by group

**Council and Commission.** The Commission presents the Pact as working, with falling arrivals, and the Return Regulation as its last piece ([[2026-09-15 209 Magnus Brunner|Magnus Brunner]], [[2026-09-15 218 Magnus Brunner|Magnus Brunner]], [[2026-06-16 267 Magnus Brunner|Magnus Brunner]]).

**[[PPE]].** PPE speakers say all instruments of the Pact are there and must be implemented ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 234 Lena Düpont|Lena Düpont]], [[2026-09-15 290 Emil Radev (written)|Emil Radev]]), call it the best tool for returns ([[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]]) and say Spain has done nothing to apply it ([[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]]).

**[[S&D]].** S&D speakers invoke the Pact's solidarity principle ([[2026-09-15 221 Ana Catarina Mendes|Ana Catarina Mendes]]) and say Spain is applying it ([[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]).

**[[Renew]].** [[2026-09-15 266 Jan-Christoph Oetjen|Jan-Christoph Oetjen]] asks for the Pact to be implemented; [[2026-06-16 266 Malik Azmani|Malik Azmani]] calls the Return Regulation its missing piece, while [[2026-06-16 272 Fabienne Keller|Fabienne Keller]] warns that the regulation risks undermining it.

**[[Verts-ALE]].** [[2026-09-15 243 Tineke Strik|Tineke Strik]] says the Pact's promise of solidarity proved hollow.

**[[The Left]].** [[2026-06-16 274 Estrella Galán|Estrella Galán]] says the Pact has become the skeleton of a deportation machine.

## Speeches

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 209 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 210 Jeroen Lenaers]] (PPE, supports)
- [[2026-09-15 218 Magnus Brunner]] (Council/Commission, supports)
- [[2026-09-15 219 Dolors Montserrat]] (PPE, supports)
- [[2026-09-15 221 Ana Catarina Mendes]] (S&D, opposes)
- [[2026-09-15 234 Lena Düpont]] (PPE, supports)
- [[2026-09-15 243 Tineke Strik]] (Verts-ALE, opposes)
- [[2026-09-15 247 Javier Zarzalejos]] (PPE, supports)
- [[2026-09-15 266 Jan-Christoph Oetjen]] (Renew, mixed)
- [[2026-09-15 273 Juan Fernando López Aguilar]] (S&D, opposes)
- [[2026-09-15 290 Emil Radev (written)]] (PPE, supports)

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 266 Malik Azmani]] (Renew, supports)
- [[2026-06-16 267 Magnus Brunner]] (Council/Commission, supports)
- [[2026-06-16 272 Fabienne Keller]] (Renew, opposes)
- [[2026-06-16 274 Estrella Galán]] (The Left, opposes)
