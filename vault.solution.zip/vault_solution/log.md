# Log

## 2026-11-22 · Ceuta · conversion (step 2)
- `to_markdown.py debate_ceuta.json --vault vault_solution`: speeches 81, debates 1, people 63, groups 9, parties 46, countries 17.

## 2026-11-22 · rules
- AGENTS.md = AGENTS.sandbox.md (complete version: group aliases, naming rules, chair rule, 15 topics, debate questions).
- Group notes: added the aliases of AGENTS.md section 3.

## 2026-11-22 · Ceuta · enrichment batch 207–226
- Notes enriched: 19
- Entity notes created (47): [[Ceuta]], [[Morocco]], [[Jim O'Callaghan]], [[Integrated Political Crisis Response]], [[Coreper]], [[European Commission]], [[European External Action Service]], [[Melilla]], [[Schengen Area]], [[Frontex]], [[European Union Agency for Asylum]], [[Europol]], [[Justice and Home Affairs Council]], [[European Council]], [[Pact on Migration and Asylum]], [[Madrid]], [[Ángel Víctor Torres]], [[Fernando Grande-Marlaska]], [[Elma Saiz]], [[Juan Jesús Vivas]], [[Ursula von der Leyen]], [[Global Alliance to Counter Migrant Smuggling]], [[Anti-smuggling directive]], [[Return Regulation]], [[Syria]], [[Pedro Sánchez]], [[Government of Spain]], [[Giorgia Meloni]], [[Lampedusa migration crisis (2023)]], [[Lithuania]], [[Alexander Lukashenko]], [[Spanish Minors Act]], [[Spanish Aliens Act]], [[EU-Morocco Association Agreement]], [[Digital Services Act]], [[United States]], [[Israel]], [[LIBE Committee]], [[Entry-Exit System]], [[Rabat]], [[Viktor Orbán]], [[Embassy of Morocco]], [[Ku Klux Klan]], [[Red Cross]], [[Donald Trump]], [[Benjamin Netanyahu]], [[Western Sahara]]
- Entity notes reused (18): [[Belgium]], [[Erik Marquardt]], [[Finland]], [[France]], [[Germany]], [[Greece]], [[Hungary]], [[Iratxe García Pérez]], [[Italy]], [[Jorge Buxadé Villalba]], [[Magnus Brunner]], [[PP (ESP)]], [[PPE]], [[PSOE (ESP)]], [[PfE]], [[Poland]], [[Spain]], [[VOX (ESP)]]

## 2026-11-22 · Ceuta · enrichment batch 227–246
- Notes enriched: 20
- Entity notes created (17): [[Russia]], [[Cuba]], [[Irene Montero]], [[Bureau of the European Parliament]], [[Schengen Borders Code]], [[Safe Third Country Regulation]], [[Mohammed VI]], [[Arab Spring]], [[Oriana Fallaci]], [[Stefano Bonaccini]], [[Saxony]], [[Lampedusa]], [[Pantelleria]], [[Berlin]], [[Warsaw]], [[Paris]], [[Sicily]]
- Entity notes reused (18): [[AfD (DEU)]], [[Alvise Pérez]], [[Ceuta]], [[European Commission]], [[Giorgia Meloni]], [[Government of Spain]], [[Hungary]], [[Ilaria Salis]], [[Italy]], [[Lampedusa migration crisis (2023)]], [[Magnus Brunner]], [[Morocco]], [[PPE]], [[Pact on Migration and Asylum]], [[Pedro Sánchez]], [[Schengen Area]], [[Spain]], [[The Left]]

## 2026-11-22 · Ceuta · enrichment batch 247–266
- Notes enriched: 20
- Entity notes created (6): [[Sidi Embarek cemetery]], [[Brussels]], [[Emmanuel Macron]], [[Grandchildren's Law (Spain)]], [[Supreme Court of Spain]], [[Belarus]]
- Entity notes reused (26): [[Benjamin Netanyahu]], [[Ceuta]], [[Donald Trump]], [[European Commission]], [[François-Xavier Bellamy]], [[Frontex]], [[Giorgia Meloni]], [[Government of Spain]], [[Greece]], [[Italy]], [[Jeroen Lenaers]], [[LIBE Committee]], [[Lampedusa]], [[Madrid]], [[Malik Azmani]], [[Melilla]], [[Morocco]], [[PP (ESP)]], [[PPE]], [[Pact on Migration and Asylum]], [[Pedro Sánchez]], [[PiS (POL)]], [[Return Regulation]], [[Schengen Area]], [[Spain]], [[VOX (ESP)]]

## 2026-11-22 · Ceuta · enrichment batch 267–291
- Notes enriched: 22
- Entity notes created (15): [[United Nations]], [[Court of Justice of the European Union]], [[Strait of Hormuz]], [[Bab el-Mandeb]], [[Strait of Gibraltar]], [[Constitution of Spain]], [[Ceuta border crisis (2021)]], [[Cairo Resolution (1964)]], [[African Union]], [[Rome]], [[National Intelligence Centre (Spain)]], [[National Police (Spain)]], [[Algeria]], [[Global Gateway]], [[European Investment Bank]]
- Entity notes reused (37): [[Belarus]], [[Berlin]], [[Bulgaria]], [[Ceuta]], [[European Commission]], [[European Council]], [[Finland]], [[France]], [[Frontex]], [[Government of Spain]], [[Israel]], [[Italy]], [[Juan Fernando López Aguilar]], [[Juan Jesús Vivas]], [[Justice and Home Affairs Council]], [[Lampedusa]], [[Lithuania]], [[Madrid]], [[Magnus Brunner]], [[Melilla]], [[Morocco]], [[PP (ESP)]], [[PPE]], [[PSOE (ESP)]], [[Pact on Migration and Asylum]], [[Paris]], [[Pedro Sánchez]], [[Poland]], [[Rabat]], [[Russia]], [[Schengen Area]], [[Schengen Borders Code]], [[Spain]], [[Spanish Aliens Act]], [[United States]], [[VOX (ESP)]], [[Western Sahara]]

## 2026-11-22 · lint (Ceuta)
- No unresolved links, no orphan notes, no topic outside the list, no missing section; no entity link not named in the text.
- Fixed: removed the alias `Madrid` from [[Government of Spain]] (it is the file name of the place note [[Madrid]]); the links `[[Government of Spain|Madrid]]` stay.
- Kept: `PS (FRA)`, `PS (PRT)`, `PS (SVK)` share the label `PS` by design (three parties).

## 2026-11-22 · Ceuta · fallacy labelling (step 8)
- Batches 207–226, 227–246, 247–266, 267–291 labelled with fallacy_detection_codebook.md, judging only the `## Text` section.
- Fallacy notes created in fallacies/: the 6 codes and the control code UNSUPPORTED_ASSERTION.

## 2026-11-22 · Return Regulation · conversion (step 9)
- `to_markdown.py debate_return_regulation.json --vault vault_solution`: speeches 20 new, debates 1 new, people 6 new / 11 kept, parties 5 new / 9 kept, groups 0 new / 9 kept, countries 0 new / 9 kept.
- Group change reported: [[Nikola Bartůšek]] is NI in June and ECR in September; the person note was left as it is.
- Rules: the question of the Return Regulation debate and the topics Return hubs, Detention of migrants and Majorities in Parliament were already in AGENTS.sandbox.md; chair rule checked (Javi López).

## 2026-11-22 · Return Regulation · enrichment batch 265–285
- Notes enriched: 20
- Entity notes created (15): [[Council of the European Union]], [[Return Directive]], [[Western Balkan route]], [[Solingen]], [[Aschaffenburg]], [[Munich]], [[Villach]], [[Mannheim]], [[Ylva Johansson]], [[Safe Countries of Origin Regulation]], [[U.S. Immigration and Customs Enforcement]], [[Albania]], [[Taliban]], [[Friedrich Merz]], [[Cologne]]
- Entity notes reused (21): [[AfD (DEU)]], [[Algeria]], [[Berlin]], [[Brussels]], [[Bulgaria]], [[Donald Trump]], [[Entry-Exit System]], [[European Commission]], [[France]], [[Frontex]], [[Germany]], [[Italy]], [[LIBE Committee]], [[Magnus Brunner]], [[Malik Azmani]], [[PPE]], [[Pact on Migration and Asylum]], [[Return Regulation]], [[Safe Third Country Regulation]], [[United Nations]], [[United States]]
- Fallacies labelled for the same batch.

## 2026-11-22 · synthesis (both debates)
- Topic notes (15): `## Positions by group` and `## Speeches`, by debate.
- Group notes (9): `## In the debates`, one subsection per debate.
- Debate notes (2): `## Overview` and `## Main lines of division`.
- index.md rebuilt.

## 2026-11-22 · lint (both debates)
1. Unresolved links: 0
2. Orphan notes (no incoming link, index.md excluded): 0
3. Possible duplicate entities: overlapping names/aliases 1, similar file names 4
   - overlap: PS (FRA) / PS (PRT) / PS (SVK)
   - similar: AfD (DEU) / FDP (DEU)
   - similar: FdL (ITA) / L (ITA)
   - similar: PdF (DEU) / SPD (DEU)
   - similar: RN (FRA) / Ren (FRA)
4. Topic links outside the list: 0
5. Speech notes missing a section: 0
6. Entity links not named in the text, in 10 random speech notes (229 2026-09-15, 285 2026-06-16, 238 2026-09-15, 271 2026-09-15, 271 2026-06-16, 274 2026-06-16, 256 2026-09-15, 277 2026-06-16, 234 2026-09-15, 262 2026-09-15): 0
- Items 3 are not duplicates: the PS parties are three parties by design; the similar names are different parties. Nothing to fix.
