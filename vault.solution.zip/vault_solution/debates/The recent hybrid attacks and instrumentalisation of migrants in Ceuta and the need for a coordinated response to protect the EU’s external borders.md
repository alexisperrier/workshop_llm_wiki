---
type: "debate"
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
title: "The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders (debate)"
url: "https://www.europarl.europa.eu/doceo/document/CRE-10-2026-09-15-ITM-007_EN.html"
sitting_url: "https://www.europarl.europa.eu/doceo/document/CRE-10-2026-09-15_EN.html"
interventions: 85
words: 15205
aliases: ["The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders (debate)"]
---

# The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders

Source: https://www.europarl.europa.eu/doceo/document/CRE-10-2026-09-15-ITM-007_EN.html

## Interventions

- 207. [[2026-09-15 207 Antonella Sberna (chair)]] (ECR, chair)
- 208. [[2026-09-15 208 Thomas Byrne]] (President-in-Office of the Council)
- 209. [[2026-09-15 209 Magnus Brunner]] (Member of the Commission)
- 210. [[2026-09-15 210 Jeroen Lenaers]] (PPE)
- 211. [[2026-09-15 211 Iratxe García Pérez]] (S&D)
- 212. [[2026-09-15 212 Jorge Buxadé Villalba]] (PfE)
- 213. [[2026-09-15 213 Diego Solier]] (ECR)
- 214. [[2026-09-15 214 Veronika Cifrová Ostrihoňová]] (Renew)
- 215. [[2026-09-15 215 Erik Marquardt]] (Verts-ALE)
- 216. [[2026-09-15 216 Estrella Galán]] (The Left)
- 217. [[2026-09-15 217 Mary Khan]] (ESN)
- 218. [[2026-09-15 218 Magnus Brunner]] (Member of the Commission)
- 219. [[2026-09-15 219 Dolors Montserrat]] (PPE)
- 220. *PRÉSIDENCE: YOUNOUS OMARJEE Vice-Président*
- 221. [[2026-09-15 221 Ana Catarina Mendes]] (S&D)
- 222. [[2026-09-15 222 Kinga Gál]] (PfE)
- 223. [[2026-09-15 223 Assita Kanko]] (ECR)
- 224. [[2026-09-15 224 Oihane Agirregoitia Martínez]] (Renew)
- 225. [[2026-09-15 225 Jaume Asens Llodrà]] (Verts-ALE)
- 226. [[2026-09-15 226 Isabel Serra Sánchez]] (The Left)
- 227. [[2026-09-15 227 Diego Solier (question)]] (ECR, question)
- 228. [[2026-09-15 228 Isabel Serra Sánchez (answer)]] (The Left, answer)
- 229. [[2026-09-15 229 Roberto Vannacci]] (ESN)
- 230. [[2026-09-15 230 Lukas Sieper (question)]] (Renew, question)
- 231. [[2026-09-15 231 Roberto Vannacci (answer)]] (ESN, answer)
- 232. [[2026-09-15 232 Alvise Pérez]] (NI)
- 233. [[2026-09-15 233 Younous Omarjee (chair)]] (The Left, chair)
- 234. [[2026-09-15 234 Lena Düpont]] (PPE)
- 235. [[2026-09-15 235 András László (question)]] (PfE, question)
- 236. [[2026-09-15 236 Lena Düpont (answer)]] (PPE, answer)
- 237. [[2026-09-15 237 Birgit Sippel (question)]] (S&D, question)
- 238. [[2026-09-15 238 Susanna Ceccardi]] (PfE)
- 239. [[2026-09-15 239 Abir Al-Sahlani (question)]] (Renew, question)
- 240. [[2026-09-15 240 Susanna Ceccardi (answer)]] (PfE, answer)
- 241. [[2026-09-15 241 Nora Junco García]] (ECR)
- 242. [[2026-09-15 242 Fabienne Keller]] (Renew)
- 243. [[2026-09-15 243 Tineke Strik]] (Verts-ALE)
- 244. [[2026-09-15 244 Ilaria Salis]] (The Left)
- 245. [[2026-09-15 245 Susanna Ceccardi (question)]] (PfE, question)
- 246. [[2026-09-15 246 Ilaria Salis (answer)]] (The Left, answer)
- 247. [[2026-09-15 247 Javier Zarzalejos]] (PPE)
- 248. [[2026-09-15 248 Anna Strolenberg (question)]] (Verts-ALE, question)
- 249. [[2026-09-15 249 Javier Zarzalejos (answer)]] (PPE, answer)
- 250. [[2026-09-15 250 Sandro Ruotolo (question)]] (S&D, question)
- 251. [[2026-09-15 251 Fabrice Leggeri]] (PfE)
- 252. [[2026-09-15 252 Alessandro Ciriani]] (ECR)
- 253. [[2026-09-15 253 Malik Azmani]] (Renew)
- 254. [[2026-09-15 254 Tineke Strik (question)]] (Verts-ALE, question)
- 255. [[2026-09-15 255 Malik Azmani (answer)]] (Renew, answer)
- 256. [[2026-09-15 256 Ana Miranda Paz]] (Verts-ALE)
- 257. [[2026-09-15 257 Konstantinos Arvanitis]] (The Left)
- 258. [[2026-09-15 258 François-Xavier Bellamy]] (PPE)
- 259. [[2026-09-15 259 Alvise Pérez (question)]] (NI, question)
- 260. [[2026-09-15 260 François-Xavier Bellamy (answer)]] (PPE, answer)
- 261. [[2026-09-15 261 Murielle Laurent]] (S&D)
- 262. [[2026-09-15 262 Nicolas Bay (question)]] (ECR, question)
- 263. [[2026-09-15 263 Murielle Laurent (answer)]] (S&D, answer)
- 264. [[2026-09-15 264 Anna Bryłka]] (PfE)
- 265. [[2026-09-15 265 Jadwiga Wiśniewska]] (ECR)
- 266. [[2026-09-15 266 Jan-Christoph Oetjen]] (Renew)
- 267. [[2026-09-15 267 Pernando Barrena Arza]] (The Left)
- 268. [[2026-09-15 268 Bartłomiej Sienkiewicz]] (PPE)
- 269. [[2026-09-15 269 Eero Heinäluoma]] (S&D)
- 270. [[2026-09-15 270 Marion Maréchal]] (ECR)
- 271. [[2026-09-15 271 Abir Al-Sahlani]] (Renew)
- 272. [[2026-09-15 272 Ana Miguel Pedro]] (PPE)
- 273. [[2026-09-15 273 Juan Fernando López Aguilar]] (S&D)
- 274. [[2026-09-15 274 Alma Ezcurra Almansa]] (PPE)
- 275. *Interventions à la demande*
- 276. [[2026-09-15 276 Malika Sorel]] (NI)
- 277. [[2026-09-15 277 Juan Ignacio Zoido Álvarez]] (PPE)
- 278. [[2026-09-15 278 Sebastian Tynkkynen]] (ECR)
- 279. [[2026-09-15 279 Silvia Sardone]] (PfE)
- 280. [[2026-09-15 280 Anna Strolenberg]] (Verts-ALE)
- 281. *(Fin des interventions à la demande)*
- 282. [[2026-09-15 282 Thomas Byrne]] (President-in-Office of the Council)
- 283. [[2026-09-15 283 Younous Omarjee (chair)]] (The Left, chair)
- 284. *Déclarations écrites (article 178)*
- 285. [[2026-09-15 285 Nikola Bartůšek (written)]] (ECR, written)
- 286. [[2026-09-15 286 Joachim Stanisław Brudziński (written)]] (ECR, written)
- 287. [[2026-09-15 287 Loucas Fourlas (written)]] (PPE, written)
- 288. [[2026-09-15 288 Tomasz Froelich (written)]] (ESN, written)
- 289. [[2026-09-15 289 Rihards Kols (written)]] (ECR, written)
- 290. [[2026-09-15 290 Emil Radev (written)]] (PPE, written)
- 291. [[2026-09-15 291 Marcin Sypniewski (written)]] (ESN, written)

## Chair

- From the start: [[Antonella Sberna]]
- From 220: [[Younous Omarjee]] *PRÉSIDENCE: YOUNOUS OMARJEE Vice-Président*

## Overview

The debate followed the crossing of tens of thousands of people from Morocco into Ceuta at the end of July 2026, in which more than 140 people died ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 209 Magnus Brunner|Magnus Brunner]]). The Council and the Commission presented the events as a stress test passed thanks to Spain and cooperation with Morocco, and announced emergency aid, a stronger Frontex and more returns ([[2026-09-15 208 Thomas Byrne|Thomas Byrne]], [[2026-09-15 209 Magnus Brunner|Magnus Brunner]], [[2026-09-15 282 Thomas Byrne|Thomas Byrne]]). PPE and right-wing speakers called the events a hybrid attack or invasion and blamed Pedro Sánchez's government and its regularisations ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 258 François-Xavier Bellamy|François-Xavier Bellamy]]). S&D, Greens and The Left speakers stressed the dead, the minors and the lack of European solidarity, and condemned Italy's border controls on Spain ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]], [[2026-09-15 215 Erik Marquardt|Erik Marquardt]], [[2026-09-15 243 Tineke Strik|Tineke Strik]], [[2026-09-15 250 Sandro Ruotolo (question)|Sandro Ruotolo]]). Nine blue-card exchanges, all between different groups, turned on women's safety, the meaning of 'invasion', Ceuta's history and return hubs ([[2026-09-15 227 Diego Solier (question)|Diego Solier]], [[2026-09-15 230 Lukas Sieper (question)|Lukas Sieper]], [[2026-09-15 239 Abir Al-Sahlani (question)|Abir Al-Sahlani]], [[2026-09-15 245 Susanna Ceccardi (question)|Susanna Ceccardi]], [[2026-09-15 254 Tineke Strik (question)|Tineke Strik]]).

## Main lines of division

- **Border protection or solidarity first:** the right and the Commission call for a stronger Frontex, barriers and returns ([[2026-09-15 209 Magnus Brunner|Magnus Brunner]], [[2026-09-15 251 Fabrice Leggeri|Fabrice Leggeri]], [[2026-09-15 278 Sebastian Tynkkynen|Sebastian Tynkkynen]]); the left calls for solidarity, legal routes and transfers ([[2026-09-15 216 Estrella Galán|Estrella Galán]], [[2026-09-15 221 Ana Catarina Mendes|Ana Catarina Mendes]], [[2026-09-15 237 Birgit Sippel (question)|Birgit Sippel]]).
- **Who is responsible:** the Spanish government for the right ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 252 Alessandro Ciriani|Alessandro Ciriani]]); Morocco and its backers for the left ([[2026-09-15 216 Estrella Galán|Estrella Galán]], [[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]], [[2026-09-15 267 Pernando Barrena Arza|Pernando Barrena Arza]]).
- **Language of invasion:** used by PfE, ECR, ESN and some PPE speakers ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]], [[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]], [[2026-09-15 274 Alma Ezcurra Almansa|Alma Ezcurra Almansa]]); rejected as racist or self-defeating by the left and the Greens ([[2026-09-15 215 Erik Marquardt|Erik Marquardt]], [[2026-09-15 225 Jaume Asens Llodrà|Jaume Asens Llodrà]], [[2026-09-15 256 Ana Miranda Paz|Ana Miranda Paz]]).
- **Internal border controls:** praised by [[2026-09-15 270 Marion Maréchal|Marion Maréchal]], condemned by S&D, Renew and Greens ([[2026-09-15 242 Fabienne Keller|Fabienne Keller]], [[2026-09-15 243 Tineke Strik|Tineke Strik]], [[2026-09-15 250 Sandro Ruotolo (question)|Sandro Ruotolo]]).
