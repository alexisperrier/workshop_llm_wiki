---
type: "debate"
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
title: "Common system for the return of third-country nationals staying illegally in the Union (Return Regulation) (debate)"
url: "https://www.europarl.europa.eu/doceo/document/CRE-10-2026-06-16-ITM-011_EN.html"
sitting_url: "https://www.europarl.europa.eu/doceo/document/CRE-10-2026-06-16_EN.html"
interventions: 22
words: 4900
aliases: ["Common system for the return of third-country nationals staying illegally in the Union (Return Regulation) (debate)"]
---

# Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)

Source: https://www.europarl.europa.eu/doceo/document/CRE-10-2026-06-16-ITM-011_EN.html

## Interventions

- 265. [[2026-06-16 265 Javi López (chair)]] (S&D, chair)
- 266. [[2026-06-16 266 Malik Azmani]] (Renew)
- 267. [[2026-06-16 267 Magnus Brunner]] (Member of the Commission)
- 268. [[2026-06-16 268 François-Xavier Bellamy]] (PPE)
- 269. [[2026-06-16 269 Murielle Laurent]] (S&D)
- 270. [[2026-06-16 270 Fabrice Leggeri]] (PfE)
- 271. [[2026-06-16 271 Charlie Weimers]] (ECR)
- 272. [[2026-06-16 272 Fabienne Keller]] (Renew)
- 273. [[2026-06-16 273 Mélissa Camara]] (Verts-ALE)
- 274. [[2026-06-16 274 Estrella Galán]] (The Left)
- 275. [[2026-06-16 275 Mary Khan]] (ESN)
- 276. [[2026-06-16 276 Magnus Brunner]] (Member of the Commission)
- 277. [[2026-06-16 277 Malik Azmani]] (Renew)
- 278. [[2026-06-16 278 Javi López (chair)]] (S&D, chair)
- 279. *Written Statements (Rule 178)*
- 280. [[2026-06-16 280 Nikola Bartůšek (written)]] (NI, written)
- 281. [[2026-06-16 281 Joachim Stanisław Brudziński (written)]] (ECR, written)
- 282. [[2026-06-16 282 Mariusz Kamiński (written)]] (ECR, written)
- 283. [[2026-06-16 283 Katri Kulmuni (written)]] (Renew, written)
- 284. [[2026-06-16 284 Marcin Sypniewski (written)]] (ESN, written)
- 285. [[2026-06-16 285 Ivaylo Valchev (written)]] (ECR, written)
- 286. *(The sitting was suspended at 14:44)*

## Chair

- From the start: [[Javi López]]

## Overview

The debate took place on the eve of the final vote on the Return Regulation, a few days after the Pact on Migration and Asylum entered into application ([[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]], [[2026-06-16 267 Magnus Brunner|Magnus Brunner]]). The rapporteur Malik Azmani and Commissioner Brunner presented the regulation as the last piece of the Pact, needed because only about one in four return decisions is enforced ([[2026-06-16 266 Malik Azmani|Malik Azmani]], [[2026-06-16 267 Magnus Brunner|Magnus Brunner]]). PPE, PfE, ECR and ESN speakers welcomed longer detention, return hubs and entry bans as a break with decades of failure ([[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]], [[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]], [[2026-06-16 271 Charlie Weimers|Charlie Weimers]], [[2026-06-16 275 Mary Khan|Mary Khan]]). S&D, Greens and The Left speakers, and Fabienne Keller of Renew, opposed the text for allowing the detention of children and returns to countries without rights guarantees ([[2026-06-16 269 Murielle Laurent|Murielle Laurent]], [[2026-06-16 272 Fabienne Keller|Fabienne Keller]], [[2026-06-16 273 Mélissa Camara|Mélissa Camara]], [[2026-06-16 274 Estrella Galán|Estrella Galán]]). There were no blue cards; the debate also turned on the majority behind the text, the PPE with the groups to its right ([[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]], [[2026-06-16 273 Mélissa Camara|Mélissa Camara]], [[2026-06-16 274 Estrella Galán|Estrella Galán]]).

## Main lines of division

- **Effectiveness and rights:** supporters say they go hand in hand ([[2026-06-16 266 Malik Azmani|Malik Azmani]], [[2026-06-16 277 Malik Azmani|Malik Azmani]], [[2026-06-16 280 Nikola Bartůšek (written)|Nikola Bartůšek]]); opponents say the text sacrifices rights without making returns more effective ([[2026-06-16 269 Murielle Laurent|Murielle Laurent]], [[2026-06-16 272 Fabienne Keller|Fabienne Keller]]).
- **Children and families:** the central objection of S&D, Renew's Keller, the Greens and The Left ([[2026-06-16 269 Murielle Laurent|Murielle Laurent]], [[2026-06-16 272 Fabienne Keller|Fabienne Keller]], [[2026-06-16 273 Mélissa Camara|Mélissa Camara]], [[2026-06-16 274 Estrella Galán|Estrella Galán]]).
- **Return hubs and detention:** welcomed by the right ([[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]], [[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]], [[2026-06-16 271 Charlie Weimers|Charlie Weimers]]), denounced as 'European Guantánamos' by the left ([[2026-06-16 274 Estrella Galán|Estrella Galán]]).
- **The majority:** praised as common sense ([[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]], [[2026-06-16 271 Charlie Weimers|Charlie Weimers]]), denounced as collaboration with the far right ([[2026-06-16 273 Mélissa Camara|Mélissa Camara]], [[2026-06-16 274 Estrella Galán|Estrella Galán]]).
