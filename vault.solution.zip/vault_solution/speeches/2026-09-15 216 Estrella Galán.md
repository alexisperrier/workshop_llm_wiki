---
type: "intervention"
kind: "speech"
speech_id: "2017094943116"
order: 216
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:37:15"
end_time: "13:38:48"
speaker: "Estrella Galán"
speaker_label: "Estrella Galán, en nombre del Grupo The Left."
group: "The Left"
party: "SMR (ESP)"
country: "Spain"
on_behalf_of_group: "THE_LEFT"
language: "es"
words: 217
position: opposes
topics: [Humanitarian situation and victims, Instrumentalisation of migration, EU-Morocco relations, External border protection, Solidarity between Member States]
fallacies: [UNSUPPORTED_ASSERTION]
---

Speaker: [[Estrella Galán]] · Group: [[The Left]] · Party: [[SMR (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 216 Estrella Galán

> Estrella Galán, en nombre del Grupo The Left.

## Text

Señora presidenta, señor comisario, la crisis de Ceuta está siendo una jugosa oportunidad para muchos que tenían ganas de ajustar cuentas con la España progresista.

Marruecos, junto a Estados Unidos e Israel, lo ha hecho generando una crisis humanitaria con más de 150 muertos solo por intereses geopolíticos; Meloni y la derecha europea colocando una agenda ultra; y VOX y el PP —que ya no sabemos quién es quién— sembrando el odio con firmes fines electoralistas. Incluso hablan de cazar a personas.

Esta crisis demuestra que cuando Europa externaliza sus fronteras, alquila su soberanía y nos hace más vulnerables. Y cuando entrega la llave a países que no respetan los derechos humanos y no son democráticos, los seres humanos acaban siendo utilizados como munición y chantaje.

Necesitamos vías legales y seguras, comisario. Ceuta no puede afrontar sola esta emergencia. Y mientras, desde aquí, solo hablan de más expulsiones, de devolver, de devoluciones urgentes —que saben que son ilegales—. Y presionan: están presionando a España para impedir los traslados. Y eso no puede ser porque están colapsando a Ceuta.

¿Saben lo que necesitan realmente los ceutíes? Que no conviertan su ciudad en un campo abierto de refugiados. Necesitan solidaridad y corresponsabilidad. Necesitan urgentemente traslados a la península de todos los niños y niñas y de los perfiles vulnerables.

## Summary
Estrella Galán says Morocco, with the United States and Israel, caused a humanitarian crisis with more than 150 dead for geopolitical reasons, while Meloni, the European right, VOX and the PP sow hatred. She argues that outsourcing borders to non-democratic countries makes Europe vulnerable, calls for legal and safe routes, and demands urgent transfers of children and vulnerable people to the mainland.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She calls for legal routes, solidarity and transfers of vulnerable people rather than more expulsions and border outsourcing.
- Quote: "Necesitamos vías legales y seguras, comisario." (translation by the agent: "We need legal and safe routes, Commissioner.")

## Entities
- [[Ceuta]]
- [[Spain|España]]
- [[Morocco|Marruecos]]
- [[United States|Estados Unidos]]
- [[Israel]]
- [[Giorgia Meloni|Meloni]]
- [[VOX (ESP)|VOX]]
- [[PP (ESP)|PP]]

## Topics
- [[Humanitarian situation and victims]]
- [[Instrumentalisation of migration]]
- [[EU-Morocco relations]]
- [[External border protection]]
- [[Solidarity between Member States]]

## Fallacies
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "Marruecos, junto a Estados Unidos e Israel, lo ha hecho generando una crisis humanitaria con más de 150 muertos solo por intereses geopolíticos" (translation by the agent: "Morocco, together with the United States and Israel, did it by generating a humanitarian crisis with more than 150 dead only for geopolitical interests")
  - Conclusion: The crisis was engineered by foreign states.
  - Defect: The involvement of the United States and Israel is asserted with no support.
