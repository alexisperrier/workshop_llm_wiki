---
type: "intervention"
kind: "question"
speech_id: "2017094943143"
order: 230
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:56:48"
end_time: "13:57:07"
speaker: "Lukas Sieper"
speaker_label: "Lukas Sieper (Renew), domanda \"cartellino blu\"."
group: "Renew"
party: "PdF (DEU)"
country: "Germany"
language: "it"
words: 30
position: not_stated
topics: [Instrumentalisation of migration]
fallacies: []
---

Speaker: [[Lukas Sieper]] · Group: [[Renew]] · Party: [[PdF (DEU)]] · Country: [[Germany]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 229 Roberto Vannacci]]

# 2026-09-15 230 Lukas Sieper (question)

> Lukas Sieper (Renew), domanda "cartellino blu".

## Text

Grazie mille collega. Vorrei fare una domanda come generale: pensa che sia possibile usare la migrazione come un'arma in una guerra ibrida? E se viene usata così, allora è un'invasione?

## Summary
In a blue-card question to Roberto Vannacci, Lukas Sieper asks him, as a general, whether migration can be used as a weapon in hybrid war, and if so whether that makes it an invasion.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about the definition of an invasion.
- Quote: "pensa che sia possibile usare la migrazione come un'arma in una guerra ibrida?" (translation by the agent: "do you think it is possible to use migration as a weapon in a hybrid war?")

## Entities
None.

## Topics
- [[Instrumentalisation of migration]]

## Fallacies
None.
