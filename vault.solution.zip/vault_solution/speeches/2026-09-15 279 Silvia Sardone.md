---
type: "intervention"
kind: "speech"
speech_id: "2017094949436"
order: 279
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:53:03"
end_time: "14:53:58"
speaker: "Silvia Sardone"
speaker_label: "Silvia Sardone (PfE)."
group: "PfE"
party: "L (ITA)"
country: "Italy"
language: "it"
words: 134
position: supports
topics: [Responsibility of the Spanish government, Humanitarian situation and victims, Regularisation of migrants, External border protection]
fallacies: [FALSE_CAUSE]
---

Speaker: [[Silvia Sardone]] · Group: [[PfE]] · Party: [[L (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 279 Silvia Sardone

> Silvia Sardone (PfE).

## Text

Signor Presidente, onorevoli colleghi, l'invasione di Ceuta è la dimostrazione più chiara dell'incapacità della sinistra di affrontare il problema dell'immigrazione. Il dramma di Ceuta, con migliaia di immigrati ancora nelle strade e sulle spiagge, è l'emblema del fallimento del governo spagnolo e anche della sua propaganda pro-accoglienza.

Eppure, nei giorni successivi all'invasione dicevano: "È tutto risolto, è tutto sotto controllo". E invece si moltiplicano scene di risse tra i migranti, violenze sulle donne, furti nelle case e in negozi, baraccopoli sulla costa.

La sinistra europea deve chiedere scusa: anni di buonismo, di porte aperte, di sanatorie, di slogan come "nessuno è clandestino" hanno portato solo problemi di sicurezza, di degrado e danni economici e sociali.

I cittadini europei sono stanchi della vostra ideologia: è l'ora di cambiare rotta. L'immigrazione irregolare va contrastata, non favorita.

## Summary
Silvia Sardone says the 'invasion' of Ceuta shows the left's inability to handle immigration and the failure of the Spanish government's pro-reception propaganda, with brawls, violence against women, thefts and shanty towns. She says years of do-goodism, open doors and amnesties brought only insecurity, and that irregular immigration must be fought, not encouraged.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She says irregular immigration must be fought, not encouraged.
- Quote: "L'immigrazione irregolare va contrastata, non favorita." (translation by the agent: "Irregular immigration must be fought, not encouraged.")

## Entities
- [[Ceuta]]

## Topics
- [[Responsibility of the Spanish government]]
- [[Humanitarian situation and victims]]
- [[Regularisation of migrants]]
- [[External border protection]]

## Fallacies
- [[FALSE_CAUSE]] (borderline)
  - Quote: "anni di buonismo, di porte aperte, di sanatorie" (translation by the agent: "years of do-goodism, of open doors, of amnesties")
  - Conclusion: Left-wing policies caused the crisis.
  - Defect: A single family of causes is given for an outcome with several causes, without support.
