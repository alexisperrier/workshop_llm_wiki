---
type: "intervention"
kind: "speech"
speech_id: "2017094949432"
order: 277
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:50:25"
end_time: "14:51:41"
speaker: "Juan Ignacio Zoido Álvarez"
speaker_label: "Juan Ignacio Zoido Álvarez (PPE)."
group: "PPE"
party: "PP (ESP)"
country: "Spain"
language: "es"
words: 209
position: supports
topics: [Responsibility of the Spanish government, Sovereignty of Ceuta and Melilla, Returns, Instrumentalisation of migration]
fallacies: []
---

Speaker: [[Juan Ignacio Zoido Álvarez]] · Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 277 Juan Ignacio Zoido Álvarez

> Juan Ignacio Zoido Álvarez (PPE).

## Text

Señor presidente, señorías, imagínense por un momento que en menos de veinticuatro horas, doce millones de inmigrantes asaltan las fronteras de Francia y ocupan París, que cuatro millones toman Berlín en un solo día o tres millones toman Roma.

Pues bien, eso —en proporción— es lo que ha ocurrido en Ceuta, una ciudad de 80 000 habitantes asaltada por 80 000 inmigrantes, de los cuales —después de mes y medio— al menos 15 000 quedan todavía en Ceuta. Y todo ello a pesar de las alertas del Centro Nacional de Inteligencia español y de la Policía Nacional. Y a pesar de las numerosas llamadas que hizo el presidente de Ceuta.

Pero, señorías, Pedro Sánchez prefirió hacer oídos sordos e irse de veraneo. Y ahora quieren engañar a todo el mundo —sobre todo Sánchez—, pero también quieren engañar a los europeos.

Por eso, comisario, ahora que va a ir usted a Madrid, le ruego que le exija al Gobierno de Sánchez que le cuente la verdad, que le diga quién lanzó la invasión, cuántos han entrado y cuándo los van a retornar. Los ceutíes merecen saber la verdad sobre la invasión de su ciudad.

Pese a quien pese, Ceuta es España y Europa. Ceuta no se vende. Ceuta se defiende.

## Summary
Juan Ignacio Zoido Álvarez compares the entry of 80,000 people into a city of 80,000 to 12 million taking Paris, and says at least 15,000 remain despite warnings from the CNI, the National Police and Ceuta's president. He says Sánchez ignored them and went on holiday, and asks the Commissioner to demand the truth from the Sánchez government on who launched the invasion, how many entered and when they will be returned.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He asks for the truth and for returns, defending Ceuta as Spain and Europe.
- Quote: "le diga quién lanzó la invasión, cuántos han entrado y cuándo los van a retornar" (translation by the agent: "tell you who launched the invasion, how many have entered and when they will be returned")

## Entities
- [[France|Francia]]
- [[Paris|París]]
- [[Berlin|Berlín]]
- [[Rome|Roma]]
- [[Ceuta]]
- [[National Intelligence Centre (Spain)|Centro Nacional de Inteligencia español]]
- [[National Police (Spain)|Policía Nacional]]
- [[Pedro Sánchez]]
- [[Madrid]]
- [[Spain|España]]

## Topics
- [[Responsibility of the Spanish government]]
- [[Sovereignty of Ceuta and Melilla]]
- [[Returns]]
- [[Instrumentalisation of migration]]

## Fallacies
None.
