---
type: "intervention"
kind: "question"
speech_id: "2017094949397"
order: 259
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:29:50"
end_time: "14:30:37"
speaker: "Alvise Pérez"
speaker_label: "Alvise Pérez (NI), pregunta de «tarjeta azul»."
group: "NI"
party: "SALF (ESP)"
country: "Spain"
language: "es"
words: 99
position: not_stated
topics: [Regularisation of migrants, Responsibility of the Spanish government]
fallacies: [UNSUPPORTED_ASSERTION]
---

Speaker: [[Alvise Pérez]] · Group: [[NI]] · Party: [[SALF (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 258 François-Xavier Bellamy]]

# 2026-09-15 259 Alvise Pérez (question)

> Alvise Pérez (NI), pregunta de «tarjeta azul».

## Text

Muchas gracias por su intervención, señor Bellamy. Usted ha mencionado indirectamente el golpe de Estado electoral que el señor Pedro Sánchez intenta imponer con la regularización masiva de ilegales. Esto en España preocupa muchísimo en referencia a la Ley de Nietos que el Tribunal Supremo está intentando paralizar para evitar que haya muchos pueblos que tengan incluso más ciudadanos no naturales de allí votantes por correo desde fuera que viviendo allí realmente.

Querría saber cuál es su opinión sobre este cambio normativo que el Gobierno socialista intenta implantar en España para mejorar sus posibilidades electorales el año que viene.

## Summary
In a blue-card question to François-Xavier Bellamy, Alvise Pérez calls Sánchez's mass regularisation an electoral coup, links it to the 'Grandchildren's Law' that the Supreme Court is trying to halt, and asks his opinion on this change.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about the regularisation and voting, not border protection.
- Quote: "Querría saber cuál es su opinión sobre este cambio normativo" (translation by the agent: "I would like to know your opinion on this regulatory change")

## Entities
- [[François-Xavier Bellamy|señor Bellamy]]
- [[Pedro Sánchez]]
- [[Spain|España]]
- [[Grandchildren's Law (Spain)|Ley de Nietos]]
- [[Supreme Court of Spain|Tribunal Supremo]]

## Topics
- [[Regularisation of migrants]]
- [[Responsibility of the Spanish government]]

## Fallacies
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "el golpe de Estado electoral que el señor Pedro Sánchez intenta imponer con la regularización masiva de ilegales" (translation by the agent: "the electoral coup that Mr Pedro Sánchez is trying to impose with the mass regularisation of illegal immigrants")
  - Conclusion: The regularisation has an electoral purpose.
  - Defect: A strong accusation is stated without support.
