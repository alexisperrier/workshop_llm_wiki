---
type: "intervention"
kind: "speech"
speech_id: "2017081987265"
order: 269
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:27:06"
end_time: "14:29:01"
speaker: "Murielle Laurent"
speaker_label: "Murielle Laurent, au nom du groupe S&D."
group: "S&D"
party: "PS (FRA)"
country: "France"
on_behalf_of_group: "S_D"
language: "fr"
words: 238
position: opposes
topics: [Returns, Detention of migrants, Return hubs, Humanitarian situation and victims, Majorities in Parliament]
fallacies: []
---

Speaker: [[Murielle Laurent]] · Group: [[S&D]] · Party: [[PS (FRA)]] · Country: [[France]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 269 Murielle Laurent

> Murielle Laurent, au nom du groupe S&D.

## Text

Monsieur le Président, Monsieur le Commissaire, chers collègues, une politique de retour n’est pas un problème en soi. Une démocratie doit mettre en œuvre ses décisions, mais elle se juge aussi à la manière dont elle les fait respecter. Aujourd’hui, nous aurions pu débattre d’un règlement rendant les retours plus efficaces tout en restant fidèle à ce qui fonde l’Union européenne: la dignité humaine. Au lieu de cela, le texte ouvre la voie à la détention des mineurs non accompagnés et de familles avec enfants; il favorise le renvoi vers des pays ne respectant pas les droits fondamentaux; il crée des hubs de retour, ces centres que l’on préfère installer loin de nos frontières pour mieux détourner le regard.

Une politique de retour n’est pas crédible parce qu’elle est plus dure. Elle ne l’est que lorsqu’elle est efficace et conforme à l’état de droit. Quand une politique échoue ailleurs, la droite européenne décide de l’importer en Europe. Certains ici ont choisi l’affichage: ils transforment ce Parlement en caisse de résonance de leur campagne nationale. Mais les vraies questions restent sans réponse: comment renforcer la coopération avec les pays d’origine? Comment rendre les retours plus efficaces?

Une Europe qui renonce à ses principes ne devient pas plus forte, elle devient simplement moins européenne. L’Europe n’a pas besoin de choisir entre l’efficacité et ses valeurs. Ce règlement, lui, fait comme si ce choix était inévitable: c’est précisément là son échec.

## Summary
Murielle Laurent says a return policy is legitimate but a democracy is judged by how it enforces its decisions. She says the text allows detention of unaccompanied minors and families with children, returns to countries that do not respect fundamental rights and return hubs far from scrutiny, accuses the right of importing failed policies for national campaigns, and says the regulation wrongly opposes effectiveness and values.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: opposes
- Justification: She calls the regulation a failure because it sacrifices values without making returns more effective.
- Quote: "Ce règlement, lui, fait comme si ce choix était inévitable: c'est précisément là son échec." (translation by the agent: "This regulation acts as if this choice were inevitable: that is precisely its failure.")

## Entities
None.

## Topics
- [[Returns]]
- [[Detention of migrants]]
- [[Return hubs]]
- [[Humanitarian situation and victims]]
- [[Majorities in Parliament]]

## Fallacies
None.
