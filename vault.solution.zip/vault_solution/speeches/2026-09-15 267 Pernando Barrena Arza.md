---
type: "intervention"
kind: "speech"
speech_id: "2017094949412"
order: 267
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:37:37"
end_time: "14:39:00"
speaker: "Pernando Barrena Arza"
speaker_label: "Pernando Barrena Arza (The Left)."
group: "The Left"
party: "EH BILDU (ESP)"
country: "Spain"
language: "es"
words: 245
position: not_stated
topics: [EU-Morocco relations, Instrumentalisation of migration]
fallacies: [UNSUPPORTED_ASSERTION]
---

Speaker: [[Pernando Barrena Arza]] · Group: [[The Left]] · Party: [[EH BILDU (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 267 Pernando Barrena Arza

> Pernando Barrena Arza (The Left).

## Text

Señor presidente, más allá de las ciento cincuenta víctimas del episodio del pasado 30 de julio, hay que poner de relieve que Marruecos practica ataques de guerra híbrida contra los cinco Estados con los que tiene frontera, en este caso contra territorio de la Unión.

La Unión Europea ha regado a Marruecos con más de 8 mil millones EUR en los últimos cinco años, algunos a fondo perdido, otros de financiación a muy bajo coste. ¿No es inconcebible que la Unión esté financiando a un país que lleva a cabo ataques de guerra híbrida contra la propia Unión Europea? A mí me parece que está fuera de toda lógica y que es inaceptable.

Marruecos modula los flujos migratorios, el tráfico de drogas y el yihadismo para ejercer presión sobre la Unión Europea y, así, de vez en cuando, recordarnos que nada de apoyar las resoluciones de la ONU en favor del derecho de autodeterminación del pueblo saharaui, nada de aplicar las sentencias del TJUE contra el expolio de los recursos saharauis y que no pare el chorro europeo de millones hacia la dictadura alauí.

Cuando todavía no se ha reanudado el tráfico en Ormuz y el estrecho de Bab el-Mandeb puede cerrarse en breve tiempo, está muy claro que el estrecho de Gibraltar tiene una importancia estratégica enorme. Estados Unidos se ha dado cuenta, Israel se ha dado cuenta, y parece que quienes no se han dado cuenta son la Comisión y el Consejo Europeo.

## Summary
Pernando Barrena Arza says Morocco carries out hybrid attacks against all five states it borders, now against EU territory, while the EU has given it over 8 billion euros in five years. He says Morocco modulates migration, drug trafficking and jihadism to stop the EU supporting Sahrawi self-determination and applying CJEU rulings, and stresses the strategic weight of the Strait of Gibraltar.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: He criticises EU funding of Morocco but does not say whether border protection should be the main response.
- Quote: "¿No es inconcebible que la Unión esté financiando a un país que lleva a cabo ataques de guerra híbrida contra la propia Unión Europea?" (translation by the agent: "Is it not inconceivable that the Union is financing a country that carries out hybrid war attacks against the European Union itself?")

## Entities
- [[Morocco|Marruecos]]
- [[United Nations|ONU]]
- [[Court of Justice of the European Union|TJUE]]
- [[Strait of Hormuz|Ormuz]]
- [[Bab el-Mandeb]]
- [[Strait of Gibraltar|estrecho de Gibraltar]]
- [[United States|Estados Unidos]]
- [[Israel]]
- [[European Commission|la Comisión]]
- [[European Council|Consejo Europeo]]

## Topics
- [[EU-Morocco relations]]
- [[Instrumentalisation of migration]]

## Fallacies
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "Marruecos practica ataques de guerra híbrida contra los cinco Estados con los que tiene frontera" (translation by the agent: "Morocco carries out hybrid war attacks against the five states it borders")
  - Conclusion: EU funding to Morocco is unacceptable.
  - Defect: A sweeping claim is stated with no case cited.
