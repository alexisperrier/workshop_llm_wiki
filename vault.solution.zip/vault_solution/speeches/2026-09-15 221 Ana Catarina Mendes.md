---
type: "intervention"
kind: "speech"
speech_id: "2017094943126"
order: 221
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:44:41"
end_time: "13:47:06"
speaker: "Ana Catarina Mendes"
speaker_label: "Ana Catarina Mendes (S&D)."
group: "S&D"
party: "PS (PRT)"
country: "Portugal"
language: "pt"
words: 331
position: opposes
topics: [Instrumentalisation of migration, Solidarity between Member States, Responsibility of the Spanish government, EU-Morocco relations, Pact on Migration and Asylum, Humanitarian situation and victims, Migrant smuggling, Schengen and internal border controls]
fallacies: []
---

Speaker: [[Ana Catarina Mendes]] · Group: [[S&D]] · Party: [[PS (PRT)]] · Country: [[Portugal]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 221 Ana Catarina Mendes

> Ana Catarina Mendes (S&D).

## Text

Senhor Presidente, Senhor Comissário, caros colegas, Ceuta é Europa, e julgo que é melhor recentrarmos o debate. Este debate tem três dimensões essenciais. Em primeiro lugar, não podemos ignorar, depois do debate desta manhã, que o que aconteceu em Ceuta foi um ataque híbrido a um Estado‑Membro e a uma fronteira externa da União Europeia. Um ataque híbrido que instrumentalizou imigrantes, que disseminou desinformação e que, com isso, fez com que houvesse uma tragédia a que todos nós assistimos. Por isso, é de lamentar, neste Parlamento Europeu, as mortes que foram vividas.

Mas este é o momento para chamarmos não a atenção deste ou daquele governo, mas, Senhora Deputada, é o momento de exigir solidariedade europeia, que faltou nas primeiras horas. É o momento de perceber que, quando um Estado‑Membro é atacado, é toda a Europa que é atacada. E é por isso mesmo que é tão importante que este Parlamento Europeu faça este debate — não para continuar a instrumentalizar, não para continuar com a demagogia, mas para exigir solidariedade no espaço Schengen, solidariedade no projeto europeu, solidariedade que faltou.

Eu gostava de aqui dizer que é verdade que, quando um Estado‑Membro é atacado, é toda a Europa que é atacada. Mas foi o governo espanhol que teve de responder e acudir de imediato às emergências desta crise humanitária. E por isso foi possível reenviar um conjunto de pessoas para Marrocos, em cooperação, de resto, com o governo de Marrocos. Mas responsabilidade europeia é solidariedade europeia e por isso, Senhor Comissário, aquilo que eu lhe peço é que, na implementação do Pacto em matéria de Migração e Asilo, possa exigir o cumprimento desse princípio basilar que é a solidariedade que faltou.

E, por último, gostaria de dizer que falta, de facto, que nós continuemos a defender canais legais e seguros de imigração, sem os quais não é possível estancar aqueles que são os principais responsáveis por isto: os que disseminam desinformação e aqueles que são os traficantes de seres humanos.

## Summary
Ana Catarina Mendes says Ceuta was a hybrid attack on a Member State that instrumentalised migrants and spread disinformation. She argues the moment calls for European solidarity, which was lacking in the first hours, defends the Spanish government's response in cooperation with Morocco, asks the Commissioner to enforce solidarity under the Pact, and calls for legal and safe migration channels.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She makes European solidarity and legal migration channels the response, rather than border reinforcement.
- Quote: "é o momento de exigir solidariedade europeia, que faltou nas primeiras horas" (translation by the agent: "it is the moment to demand European solidarity, which was lacking in the first hours")

## Entities
- [[Ceuta]]
- [[Schengen Area|espaço Schengen]]
- [[Government of Spain|governo espanhol]]
- [[Morocco|Marrocos]]
- [[Pact on Migration and Asylum|Pacto em matéria de Migração e Asilo]]

## Topics
- [[Instrumentalisation of migration]]
- [[Solidarity between Member States]]
- [[Responsibility of the Spanish government]]
- [[EU-Morocco relations]]
- [[Pact on Migration and Asylum]]
- [[Humanitarian situation and victims]]
- [[Migrant smuggling]]
- [[Schengen and internal border controls]]

## Fallacies
None.
