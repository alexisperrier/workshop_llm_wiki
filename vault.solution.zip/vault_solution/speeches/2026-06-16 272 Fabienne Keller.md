---
type: "intervention"
kind: "speech"
speech_id: "2017081987272"
order: 272
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:33:48"
end_time: "14:35:05"
speaker: "Fabienne Keller"
speaker_label: "Fabienne Keller, au nom du groupe Renew."
group: "Renew"
party: "Ren (FRA)"
country: "France"
on_behalf_of_group: "RENEW"
language: "fr"
words: 184
position: opposes
topics: [Returns, Humanitarian situation and victims, Pact on Migration and Asylum, Majorities in Parliament]
fallacies: []
---

Speaker: [[Fabienne Keller]] · Group: [[Renew]] · Party: [[Ren (FRA)]] · Country: [[France]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 272 Fabienne Keller

> Fabienne Keller, au nom du groupe Renew.

## Text

Monsieur le Président, Monsieur le Commissaire – cher Magnus Brunner –, mes chers collègues, l’Europe s’est construite sur un socle de valeurs solides et une conviction partagée: le respect des droits humains. Le règlement sur le retour soumis au vote demain est contraire à ces valeurs. L’Europe ne doit pas permettre le renvoi de familles avec enfants vers des pays à l’autre bout du monde, avec lesquels elles n’ont aucun lien et sans garantie des droits humains.

Se résoudre à approuver un tel dispositif sous la pression de l’extrême droite serait un aveu d’échec pour l’Europe et une ligne rouge franchie par ce Parlement. En 2024, nous avons abouti sur un ensemble de dix textes à la fois fermes, efficaces et respectueux des droits humains: le pacte sur la migration et l’asile. Aujourd’hui, nous prenons le risque de tout renverser. Nous prenons le risque de mettre à mal l’efficacité du pacte. Il est encore possible d’éviter cela.

Chers collègues, soutenez l’amendement pour protéger les enfants en les excluant de ces renvois, comme la Commission nous l’avait d’ailleurs proposé initialement! L’Europe vaut mieux que cela.

## Summary
Fabienne Keller says the regulation contradicts Europe's values because it allows families with children to be sent to faraway countries with which they have no link and without human-rights guarantees. Adopting it under far-right pressure would cross a red line and risk undermining the Pact; she asks colleagues to support the amendment excluding children, as the Commission first proposed.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: opposes
- Justification: She opposes the text as it stands unless children are excluded from such returns.
- Quote: "Le règlement sur le retour soumis au vote demain est contraire à ces valeurs." (translation by the agent: "The return regulation put to the vote tomorrow is contrary to these values.")

## Entities
- [[Magnus Brunner|cher Magnus Brunner]]
- [[Return Regulation|règlement sur le retour]]
- [[Pact on Migration and Asylum|pacte sur la migration et l'asile]]
- [[European Commission|la Commission]]

## Topics
- [[Returns]]
- [[Humanitarian situation and victims]]
- [[Pact on Migration and Asylum]]
- [[Majorities in Parliament]]

## Fallacies
None.
