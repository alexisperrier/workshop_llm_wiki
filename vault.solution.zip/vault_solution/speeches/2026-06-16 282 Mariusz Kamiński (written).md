---
type: "intervention"
kind: "written"
speech_id: "2017083751414"
order: 282
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
speaker: "Mariusz Kamiński"
speaker_label: "Mariusz Kamiński (ECR), na piśmie."
group: "ECR"
party: "PiS (POL)"
country: "Poland"
language: "pl"
words: 193
position: supports
topics: [Returns, Return hubs, Solidarity between Member States, Migrant smuggling]
fallacies: []
---

Speaker: [[Mariusz Kamiński]] · Group: [[ECR]] · Party: [[PiS (POL)]] · Country: [[Poland]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-06-16 282 Mariusz Kamiński (written)

> Mariusz Kamiński (ECR), na piśmie.

## Text

Dzisiaj, po latach błędów i szkodliwych decyzji, zwyciężył zdrowy rozsądek. To krok w stronę normalności, w kierunku zerwania ze zbankrutowaną europejską polityką migracyjną, powrotu do zasad, które dla mojego obozu politycznego i dla zdecydowanej większości Polaków od zawsze były oczywiste.W czasie, gdy Bruksela i Berlin forsowały kolejne rozwiązania osłabiające kontrolę nad migracją, my konsekwentnie powtarzaliśmy, że państwo musi kontrolować własne granice. To państwo, a nie przemytnicy ludzi, nie brukselscy urzędnicy, musi decydować o tym, kto może przekroczyć jego granice, kto może pozostać na jego terytorium, a kto powinien je opuścić.Przez lata unijne elity budowały dysfunkcyjny system oparty na absurdalnej logice „Herzlich Willkommen” i „Wir schaffen das”. System, który wpuścił do Europy miliony migrantów, a w którym wykonywana jest zaledwie co czwarta decyzja powrotowa.Przez dekady niewyobrażalne było skuteczne wydalanie nielegalnych migrantów. Niewyobrażalne było, by przestępstwo skutkowało zakazem ponownego wjazdu. Niewyobrażalne było rozbijanie siatek przemytników ludzi, przełamanie szantażu państw odmawiających przyjmowania własnych obywateli czy tworzenie centrów powrotowych poza granicami Unii Europejskiej.Dzisiejsze głosowanie nie rozwiązuje wszystkich problemów. Nie naprawia całego szkodliwego systemu, który przez lata nagradzał nielegalną migrację, a karał państwa próbujące chronić własne granice. Potrzebne są kolejne działania. Potrzebujemy odrzucenia mechanizmu relokacji i przymusowej solidarności.

## Summary
In a written statement, Mariusz Kamiński says common sense has prevailed after years of errors, and that the state, not smugglers or Brussels officials, must decide who enters and stays. He criticises the 'Herzlich Willkommen' logic under which only one in four return decisions is enforced, welcomes entry bans and return centres outside the EU, and calls for rejecting relocation and forced solidarity.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He calls the vote a step towards normality.
- Quote: "Dzisiaj, po latach błędów i szkodliwych decyzji, zwyciężył zdrowy rozsądek." (translation by the agent: "Today, after years of mistakes and harmful decisions, common sense has won.")

## Entities
- [[Brussels|Bruksela]]
- [[Berlin]]

## Topics
- [[Returns]]
- [[Return hubs]]
- [[Solidarity between Member States]]
- [[Migrant smuggling]]

## Fallacies
None.
