---
type: "intervention"
kind: "speech"
speech_id: "2017081987274"
order: 273
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:35:11"
end_time: "14:36:25"
speaker: "Mélissa Camara"
speaker_label: "Mélissa Camara, au nom du groupe Verts/ALE."
group: "Verts-ALE"
party: "Les Écologistes (FRA)"
country: "France"
on_behalf_of_group: "VERTS_ALE"
language: "fr"
words: 213
position: opposes
topics: [Return hubs, Detention of migrants, Humanitarian situation and victims, Majorities in Parliament]
fallacies: [SLIPPERY_SLOPE]
---

Speaker: [[Mélissa Camara]] · Group: [[Verts-ALE]] · Party: [[Les Écologistes (FRA)]] · Country: [[France]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 273 Mélissa Camara

> Mélissa Camara, au nom du groupe Verts/ALE.

## Text

Monsieur le Président, mes chers collègues, nous avons été nombreux à être choqués par les violences commises par l’ICE aux États-Unis: des familles déchirées, des enfants terrorisés, une logique d’enfermement toujours plus généralisée. Eh bien demain, vos proches, les gens que vous aimez, pourraient vivre les mêmes erreurs.

Nous voyons déjà où mènent les politiques inhumaines. «Vous, Européens, vous nous envoyez ici pour qu’on nous oublie. Car nous ne sommes pas des humains pour vous.» Ce sont les mots qu’un retenu m’a confiés lors de ma visite du centre italien en Albanie. Un endroit où les personnes sont désignées par des numéros, un centre au milieu des montagnes, loin de tout regard, où le registre des incidents fait état de tentatives de suicide chaque semaine.

Voter ce règlement sur le retour, fruit d’une collaboration assumée entre le PPE et l’extrême droite, c’est cautionner cette déshumanisation, c’est approuver l’enfermement de familles vers des centres qui bafouent la dignité humaine, où, par votre volonté, aucun mécanisme de surveillance des droits fondamentaux ne sera créé. Sans contrôle, ces personnes seront seules face à tous les abus possibles, dans de véritables zones de non-droit.

Mes chers collègues, soyez à la hauteur des valeurs qui fondent l’Union européenne. Défendez les droits. Défendez le droit. Votez contre ce règlement.

## Summary
Mélissa Camara recalls the violence of ICE in the United States and quotes a detainee she met in the Italian centre in Albania, where suicide attempts are recorded every week. She says the regulation, produced by the EPP working with the far right, endorses dehumanisation and the detention of families in centres with no human-rights monitoring, and asks colleagues to vote against.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: opposes
- Justification: She asks colleagues to vote against the regulation.
- Quote: "Votez contre ce règlement." (translation by the agent: "Vote against this regulation.")

## Entities
- [[U.S. Immigration and Customs Enforcement|ICE]]
- [[United States|États-Unis]]
- [[Italy|italien]]
- [[Albania|Albanie]]
- [[Return Regulation|règlement sur le retour]]
- [[PPE]]

## Topics
- [[Return hubs]]
- [[Detention of migrants]]
- [[Humanitarian situation and victims]]
- [[Majorities in Parliament]]

## Fallacies
- [[SLIPPERY_SLOPE]] (borderline)
  - Quote: "Eh bien demain, vos proches, les gens que vous aimez, pourraient vivre les mêmes erreurs." (translation by the agent: "Well, tomorrow your loved ones, the people you love, could suffer the same mistakes.")
  - Conclusion: The regulation must be rejected.
  - Defect: A chain from the regulation to ICE-style abuses against the listeners' own relatives is asserted without intermediate steps.
