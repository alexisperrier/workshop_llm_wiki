---
type: "intervention"
kind: "speech"
speech_id: "2017094949418"
order: 270
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:41:30"
end_time: "14:42:34"
speaker: "Marion Maréchal"
speaker_label: "Marion Maréchal (ECR)."
group: "ECR"
party: "IDL (FRA)"
country: "France"
language: "fr"
words: 179
position: supports
topics: [Humanitarian situation and victims, Regularisation of migrants, Responsibility of the Spanish government, Schengen and internal border controls, External border protection]
fallacies: [FALSE_CAUSE]
---

Speaker: [[Marion Maréchal]] · Group: [[ECR]] · Party: [[IDL (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 270 Marion Maréchal

> Marion Maréchal (ECR).

## Text

Monsieur le Président, «Je veux pouvoir aller tranquillement à l'école. Nous ne pouvons pas y aller. Nous avons très peur. Nous avons très mal.» Ces mots ont été prononcés par une petite fille de Ceuta en larmes. Mais manifestement, les larmes des petites Européennes ne valent pas grand-chose devant l'agenda immigrationniste de cette gauche.

Parce que l'invasion de Ceuta est la tragique conséquence des régularisations massives du socialiste Pedro Sánchez. Et le résultat est tragique: crise sanitaire, menaces de djihadistes, cambriolages multipliés par soixante, agressions multipliées par quinze et presque un cas d'agression sexuelle par jour, selon la procureure de Ceuta.

Alors oui, bravo au gouvernement italien d'avoir eu le courage de fermer ses frontières à l'Espagne. Bravo, parce que seule la fermeté face à ce défi nous permettra de défendre notre souveraineté, nos valeurs, nos modes de vie, notre sécurité. Il faudrait même aller encore plus loin et réserver la libre circulation des espaces Schengen aux seuls résidents et citoyens européens. Parce que protéger nos frontières n'est pas un crime, c'est au contraire le premier devoir d'un État.

## Summary
Marion Maréchal quotes a crying girl from Ceuta who is afraid to go to school and says the 'invasion' is the consequence of Pedro Sánchez's mass regularisations, citing rising crime and sexual assaults. She praises the Italian government for closing its borders to Spain and proposes reserving free movement in Schengen to EU residents and citizens.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She calls for firmness and border closures to defend sovereignty and security.
- Quote: "protéger nos frontières n'est pas un crime, c'est au contraire le premier devoir d'un État" (translation by the agent: "protecting our borders is not a crime, it is on the contrary the first duty of a state")

## Entities
- [[Ceuta]]
- [[Pedro Sánchez]]
- [[Italy|gouvernement italien]]
- [[Spain|l'Espagne]]
- [[Schengen Area|Schengen]]

## Topics
- [[Humanitarian situation and victims]]
- [[Regularisation of migrants]]
- [[Responsibility of the Spanish government]]
- [[Schengen and internal border controls]]
- [[External border protection]]

## Fallacies
- [[FALSE_CAUSE]] (clear)
  - Quote: "l'invasion de Ceuta est la tragique conséquence des régularisations massives du socialiste Pedro Sánchez" (translation by the agent: "the invasion of Ceuta is the tragic consequence of the socialist Pedro Sánchez's mass regularisations")
  - Conclusion: The Spanish government caused the crisis.
  - Defect: A single cause is asserted for an event with several causes, without support.
