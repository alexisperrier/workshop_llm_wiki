---
type: "intervention"
kind: "chair"
speech_id: "2017081987283"
order: 278
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:44:26"
end_time: "14:44:43"
speaker: "Javi López"
speaker_label: "President."
group: "S&D"
party: "PSC-PSOE (ESP)"
country: "Spain"
language: "en"
words: 10
topics: []
fallacies: []
---

Speaker: [[Javi López]] · Group: [[S&D]] · Party: [[PSC-PSOE (ESP)]] · Country: [[Spain]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 278 Javi López (chair)

> President.

## Text

The debate is closed. The vote will be held tomorrow.

## Summary
The chair, Javi López, closes the debate and announces the vote for the following day.

## Entities
None.

## Topics
None.

## Fallacies
None.
