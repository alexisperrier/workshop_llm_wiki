---
type: "intervention"
kind: "answer"
speech_id: "2017094949372"
order: 246
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:14:16"
end_time: "14:14:50"
speaker: "Ilaria Salis"
speaker_label: "Ilaria Salis (The Left), risposta a una domanda \"cartellino blu\"."
group: "The Left"
party: "SI (ITA)"
country: "Italy"
language: "it"
words: 87
position: opposes
topics: [Sovereignty of Ceuta and Melilla, Humanitarian situation and victims]
fallacies: [AD_HOMINEM]
---

Speaker: [[Ilaria Salis]] · Group: [[The Left]] · Party: [[SI (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 245 Susanna Ceccardi (question)]]

# 2026-09-15 246 Ilaria Salis (answer)

> Ilaria Salis (The Left), risposta a una domanda "cartellino blu".

## Text

È un residuo coloniale: questo non lo dico io ma lo dicono i libri di storia; se i colleghi di destra, magari, li avessero aperti per caso. Il problema di voi di destra è che siete insicuri, siete pieni di insicurezza e siete pieni di paure.

Se davvero pensate che un continente ricco, di 450 milioni di abitanti, non è in grado di accogliere 60.000 persone, allora forse dovreste cambiare mestiere, perché dovreste smetterla di riversare la vostra insicurezza sui cittadini per racimolare qualche voto in più.

## Summary
Answering Susanna Ceccardi, Ilaria Salis says history books call Ceuta a colonial remnant, that the right is full of insecurity and fear, and that a rich continent of 450 million can welcome 60,000 people.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She says Europe can take in the 60,000 arrivals.
- Quote: "un continente ricco, di 450 milioni di abitanti, non è in grado di accogliere 60.000 persone" (translation by the agent: "a rich continent of 450 million inhabitants is not able to welcome 60,000 people")

## Entities
None.

## Topics
- [[Sovereignty of Ceuta and Melilla]]
- [[Humanitarian situation and victims]]

## Fallacies
- [[AD_HOMINEM]] (clear)
  - Quote: "Il problema di voi di destra è che siete insicuri, siete pieni di insicurezza e siete pieni di paure." (translation by the agent: "The problem with you on the right is that you are insecure, you are full of insecurity and full of fears.")
  - Conclusion: The right's position on Ceuta is wrong.
  - Defect: The opposing position is dismissed by attributing psychological traits to those who hold it.
