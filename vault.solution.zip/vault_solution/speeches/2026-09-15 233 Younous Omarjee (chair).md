---
type: "intervention"
kind: "chair"
speech_id: "2017094949348"
order: 233
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:59:21"
end_time: "14:00:14"
speaker: "Younous Omarjee"
speaker_label: "Le Président."
group: "The Left"
party: "LFI (FRA)"
country: "France"
language: "fr"
words: 68
topics: []
fallacies: []
---

Speaker: [[Younous Omarjee]] · Group: [[The Left]] · Party: [[LFI (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 233 Younous Omarjee (chair)

> Le Président.

## Text

Monsieur Pérez, votre temps est épuisé. Je ne vois pas à quoi vous faites référence, mais je me souviens qu'ici, en plénière, vous avez insulté une députée du groupe The Left, Madame Montero, et que vous avez été sanctionné par le Bureau du Parlement européen. Votre temps est épuisé. Vous n'avez plus la parole. Merci de bien vouloir rejoindre votre siège. Monsieur Pérez, Monsieur Pérez, rejoignez votre siège.

## Summary
The chair, Younous Omarjee, ends Alvise Pérez's speaking time and recalls that he was sanctioned by the Bureau for insulting Irene Montero.

## Entities
- [[Alvise Pérez|Monsieur Pérez]]
- [[The Left]]
- [[Irene Montero|Madame Montero]]
- [[Bureau of the European Parliament|Bureau du Parlement européen]]

## Topics
None.

## Fallacies
None.
