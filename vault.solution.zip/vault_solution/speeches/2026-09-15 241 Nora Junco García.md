---
type: "intervention"
kind: "speech"
speech_id: "2017094949362"
order: 241
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:08:02"
end_time: "14:09:10"
speaker: "Nora Junco García"
speaker_label: "Nora Junco García (ECR)."
group: "ECR"
country: "Spain"
language: "es"
words: 177
position: supports
topics: [Responsibility of the Spanish government, Sovereignty of Ceuta and Melilla, Humanitarian situation and victims, EU-Morocco relations]
fallacies: []
---

Speaker: [[Nora Junco García]] · Group: [[ECR]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 241 Nora Junco García

> Nora Junco García (ECR).

## Text

Señor presidente, señor comisario, playas tomadas, chabolas, campamentos, duchas, mercadillos improvisados. Esta es la normalidad que pretende el Gobierno español para Ceuta: barrios enteros naciendo de una situación que jamás debió consolidarse. Y todo esto en una ciudad en la Unión Europea.

Lo extraordinario es que se está convirtiendo en una ciudad permanente, o sea, lo que se llama colonización. Y aquí parece que hemos aprendido y hemos decidido acostumbrarnos. Pues yo no.

Marruecos tiene una responsabilidad, el Gobierno de Sánchez tiene una responsabilidad, y nosotros aquí, comisario, en el Parlamento Europeo, también tenemos una responsabilidad.

El ciudadano ceutí paga los mismos impuestos que un ciudadano en Berlín, en Varsovia o en París. Los ceutíes tienen los mismos derechos que cualquier otro ciudadano de la Unión y están siendo víctimas de una invasión en toda regla.

Vayan a Ceuta, señorías, vayan y mírenla. El colapso de una ciudad es el reflejo del proyecto de la Unión Europea. Mientras que en Ceuta están comprobando que nadie la defiende, el resto del mundo está comprobando la vulnerabilidad de Europa.

## Summary
Nora Junco García describes beaches taken over, shacks and makeshift markets in Ceuta, which she calls a colonisation that the Spanish government wants to normalise. She says Morocco, the Sánchez government and the European Parliament all bear responsibility, and that the people of Ceuta, EU citizens like any other, are victims of an invasion nobody is defending them from.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She says no one is defending Ceuta and calls on the EU to do so.
- Quote: "Mientras que en Ceuta están comprobando que nadie la defiende, el resto del mundo está comprobando la vulnerabilidad de Europa." (translation by the agent: "While in Ceuta they see that no one defends it, the rest of the world sees Europe's vulnerability.")

## Entities
- [[Government of Spain|Gobierno español]]
- [[Ceuta]]
- [[Morocco|Marruecos]]
- [[Pedro Sánchez|Sánchez]]
- [[Berlin|Berlín]]
- [[Warsaw|Varsovia]]
- [[Paris|París]]

## Topics
- [[Responsibility of the Spanish government]]
- [[Sovereignty of Ceuta and Melilla]]
- [[Humanitarian situation and victims]]
- [[EU-Morocco relations]]

## Fallacies
None.
