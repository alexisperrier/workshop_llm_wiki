---
type: "intervention"
kind: "speech"
speech_id: "2017094949426"
order: 274
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:46:46"
end_time: "14:48:55"
speaker: "Alma Ezcurra Almansa"
speaker_label: "Alma Ezcurra Almansa (PPE)."
group: "PPE"
party: "PP (ESP)"
country: "Spain"
language: "es"
words: 421
position: supports
topics: [Instrumentalisation of migration, Sovereignty of Ceuta and Melilla, Responsibility of the Spanish government, EU-Morocco relations, External border protection, Humanitarian situation and victims]
fallacies: [AD_HOMINEM]
---

Speaker: [[Alma Ezcurra Almansa]] · Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 274 Alma Ezcurra Almansa

> Alma Ezcurra Almansa (PPE).

## Text

Señor presidente, señorías, sé que en esta Casa funcionan mejor los eufemismos, pero yo no he venido a complacer a nadie, así que voy a utilizar las palabras exactas.

Cuando un Estado utiliza una frontera para desafiar la soberanía de otro, se llama agresión. Y si ese Estado utiliza personas para hacerlo y, además, les cuesta la vida, no es una cuestión de solidaridad, es instrumentalización.

Cuando un Gobierno sabe que eso va a suceder y no hace nada, se llama negligencia, no solidaridad. Y si 45 días después sigue habiendo miedo en la calle, los policías son agredidos a diario, las mujeres migrantes e inmigrantes sufren violaciones, etcétera, eso no es Derecho internacional, señor Aguilar, eso es abandonar a tus compatriotas.

Señor comisario, a mí todo esto no me parece un problema migratorio de libro, sino una invasión. Y yo entiendo que la gente de la izquierda, en esta Cámara, atienda órdenes y no se haya estudiado la lección, pero les voy a decir una cosa: Ceuta es España y España es Europa, y hasta donde yo sé, el pacto consiste en que las fronteras de la Unión se protegen, pero no porque nos dibujen en el mapa, sino porque es la mejor forma de protegernos a todos y a todo lo que está detrás: la libertad, la seguridad y los derechos.

Así que cuando una frontera es atacada —y me da igual que sea Polonia, Finlandia o Lituania— tiene que ser defendida de la misma manera: no vamos a variar nuestra respuesta en función de quién provoque el ataque. De hecho, en el año 2021, 10 000 personas entraron en Ceuta y esta Cámara fue absolutamente contundente con Marruecos.

Señores del Partido Socialista, ¿me pueden explicar qué razón del progresismo justifica que ahora lo seamos menos? Porque han entrado 70 000 personas más. Yo se lo digo: no hay ninguna razón porque esto no es un problema de ideología, es un problema de soberanía. Y comprendo, comisario, que para defender la soberanía hace falta diplomacia. Lo que no tengo claro es que permitir que un tercer país utilice a seres humanos —muchos de ellos niños— para desestabilizar a un Estado miembro y no decir nada por no incomodar un interés comercial sea diplomacia. Yo creo que es asumir que hay vidas que valen menos que otras y aceptar un chantaje.

Las fronteras de Europa valen lo mismo, esté Bielorrusia o Marruecos al otro lado, así que seamos consecuentes. Pedro Sánchez ha elegido claudicación. ¿Qué van a votar todos ustedes?

## Summary
Alma Ezcurra Almansa says a state using people to challenge another's sovereignty is aggression and instrumentalisation, and a government that knew and did nothing is negligent. Replying to López Aguilar, she calls the events an invasion, says the Pact means the Union's borders are protected, recalls Parliament's firm stance on Morocco in 2021, and accuses Pedro Sánchez of capitulation.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She says the external borders must be defended the same way whoever attacks them.
- Quote: "cuando una frontera es atacada —y me da igual que sea Polonia, Finlandia o Lituania— tiene que ser defendida de la misma manera" (translation by the agent: "when a border is attacked, and I don't care if it is Poland, Finland or Lithuania, it has to be defended in the same way")

## Entities
- [[Juan Fernando López Aguilar|señor Aguilar]]
- [[Ceuta]]
- [[Spain|España]]
- [[Pact on Migration and Asylum|el pacto]]
- [[Poland|Polonia]]
- [[Finland|Finlandia]]
- [[Lithuania|Lituania]]
- [[Ceuta border crisis (2021)|en el año 2021]]
- [[Morocco|Marruecos]]
- [[PSOE (ESP)|Partido Socialista]]
- [[Belarus|Bielorrusia]]
- [[Pedro Sánchez]]

## Topics
- [[Instrumentalisation of migration]]
- [[Sovereignty of Ceuta and Melilla]]
- [[Responsibility of the Spanish government]]
- [[EU-Morocco relations]]
- [[External border protection]]
- [[Humanitarian situation and victims]]

## Fallacies
- [[AD_HOMINEM]] (borderline)
  - Quote: "entiendo que la gente de la izquierda, en esta Cámara, atienda órdenes y no se haya estudiado la lección" (translation by the agent: "I understand that the people on the left in this House take orders and have not learnt the lesson")
  - Conclusion: The left's reading of the events is wrong.
  - Defect: The opponents' view is dismissed by claiming they follow orders and are ill-informed; the rest of the speech gives arguments, so it is borderline.
