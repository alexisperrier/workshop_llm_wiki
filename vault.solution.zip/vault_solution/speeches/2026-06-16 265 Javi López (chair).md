---
type: "intervention"
kind: "chair"
speech_id: "2017081987256"
order: 265
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:15:32"
end_time: "14:16:02"
speaker: "Javi López"
speaker_label: "President."
group: "S&D"
party: "PSC-PSOE (ESP)"
country: "Spain"
language: "en"
words: 80
topics: []
fallacies: []
---

Speaker: [[Javi López]] · Group: [[S&D]] · Party: [[PSC-PSOE (ESP)]] · Country: [[Spain]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 265 Javi López (chair)

> President.

## Text

The next item is the debate on the report by Mr Azmani, on behalf of the Committee on Civil Liberties, Justice and Home Affairs, on the common system for the return of third-country nationals staying illegally in the Union (Return Regulation) (COM(2025)0101 – C10‑0047/2025 – 2025/0059(COD)) (A10-0048/2026).

I would like to inform Members that there will be only one round of political group speakers for this debate. Therefore, there is no catch-the-eye procedure and no blue cards will be accepted.

## Summary
The chair, Javi López, opens the debate on Malik Azmani's LIBE report on the Return Regulation and announces one round of group speakers, with no catch-the-eye and no blue cards.

## Entities
- [[Malik Azmani|Mr Azmani]]
- [[LIBE Committee|Committee on Civil Liberties, Justice and Home Affairs]]
- [[Return Regulation]]

## Topics
None.

## Fallacies
None.
