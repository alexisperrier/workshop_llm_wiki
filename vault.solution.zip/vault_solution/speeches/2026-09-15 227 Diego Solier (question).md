---
type: "intervention"
kind: "question"
speech_id: "2017094943138"
order: 227
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:54:02"
end_time: "13:54:16"
speaker: "Diego Solier"
speaker_label: "Diego Solier (ECR), pregunta de «tarjeta azul»."
group: "ECR"
country: "Spain"
language: "es"
words: 31
position: not_stated
topics: [Humanitarian situation and victims]
fallacies: []
---

Speaker: [[Diego Solier]] · Group: [[ECR]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 226 Isabel Serra Sánchez]]

# 2026-09-15 227 Diego Solier (question)

> Diego Solier (ECR), pregunta de «tarjeta azul».

## Text

Solo una pregunta sencilla: ¿consideras que las mujeres en Ceuta pueden salir a la calle tranquilas y volver a su casa «solas y borrachas», como decía el eslogan de su compañera?

## Summary
In a blue-card question to Isabel Serra Sánchez, Diego Solier asks whether women in Ceuta can now walk home 'alone and drunk', as in a slogan of her colleague.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about women's safety, not the EU's response.
- Quote: "¿consideras que las mujeres en Ceuta pueden salir a la calle tranquilas" (translation by the agent: "do you think women in Ceuta can go out into the street calmly")

## Entities
- [[Ceuta]]

## Topics
- [[Humanitarian situation and victims]]

## Fallacies
None.
