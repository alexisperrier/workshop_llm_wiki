---
type: "intervention"
kind: "speech"
speech_id: "2017094949391"
order: 256
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:25:48"
end_time: "14:27:05"
speaker: "Ana Miranda Paz"
speaker_label: "Ana Miranda Paz (Verts/ALE)."
group: "Verts-ALE"
party: "BNG (ESP)"
country: "Spain"
language: "es"
words: 200
position: opposes
topics: [Humanitarian situation and victims, Returns, EU-Morocco relations]
fallacies: [AD_HOMINEM]
---

Speaker: [[Ana Miranda Paz]] · Group: [[Verts-ALE]] · Party: [[BNG (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 256 Ana Miranda Paz

> Ana Miranda Paz (Verts/ALE).

## Text

Señor presidente, señor comisario, formo parte de un pueblo emigrante —(la oradora se expresa en una lengua no oficial)—, y, por eso, me da mucha vergüenza escuchar tanto racismo.

La verdadera frontera de Europa, señor comisario, no es geográfica, es moral.

El debate no es la frontera física, es el límite a la deshumanización. Este Parlamento hace mucho que cruzó este límite. En junio, la derecha y la extrema derecha gritaron «Send them back» cuando aprobaron el vergonzoso Reglamento de retorno. Fue bochornoso.

¿Dónde queda su humanidad? No existe. Solo racismo y odio. ¿Hasta cuándo el Partido Popular de la mano de los fascistas de VOX y sus amigos de extrema derecha van a seguir criminalizando a niños y a niñas? Los llaman invasores, hablan de invasión en Ceuta y crean un lenguaje de odio que legitima perseguir a familias que escapan de guerras y de pobreza.

Son personas. Se callan ante la corrupción del régimen marroquí y su gendarme migratorio. Se calla Europa. Es un secreto a voces que Marruecos presiona al Estado español —que se deja— y también a la UE. Yo solamente digo una cosa: ayudas para Ceuta, infraestructuras, atención y asilo. Frente a su odio, humanidad.

## Summary
Ana Miranda Paz says Europe's real border is moral, not geographic, and that Parliament crossed the line of dehumanisation when the right shouted 'Send them back' while adopting the Return Regulation. She accuses the PP and VOX of criminalising children, says Europe is silent about the corrupt Moroccan regime and its pressure on Spain, and calls for aid, infrastructure, care and asylum for Ceuta.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She rejects the physical-border framing and asks for humanitarian support and asylum.
- Quote: "La verdadera frontera de Europa, señor comisario, no es geográfica, es moral." (translation by the agent: "Europe's real border, Commissioner, is not geographic, it is moral.")

## Entities
- [[Return Regulation|Reglamento de retorno]]
- [[PP (ESP)|Partido Popular]]
- [[VOX (ESP)|VOX]]
- [[Ceuta]]
- [[Morocco|Marruecos]]

## Topics
- [[Humanitarian situation and victims]]
- [[Returns]]
- [[EU-Morocco relations]]

## Fallacies
- [[AD_HOMINEM]] (borderline)
  - Quote: "¿Dónde queda su humanidad? No existe. Solo racismo y odio." (translation by the agent: "Where is your humanity? It does not exist. Only racism and hatred.")
  - Conclusion: The right's position on returns and Ceuta is illegitimate.
  - Defect: The opponents' position is dismissed by attributing racism and hatred to them rather than by an argument.
