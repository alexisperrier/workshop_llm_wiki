---
type: "intervention"
kind: "speech"
speech_id: "2017094943140"
order: 229
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:55:02"
end_time: "13:56:37"
speaker: "Roberto Vannacci"
speaker_label: "Roberto Vannacci (ESN)."
group: "ESN"
party: "FN (ITA)"
country: "Italy"
language: "it"
words: 212
position: supports
topics: [External border protection, Instrumentalisation of migration, Regularisation of migrants, Responsibility of the Spanish government, Humanitarian situation and victims]
fallacies: [FALSE_CAUSE]
---

Speaker: [[Roberto Vannacci]] · Group: [[ESN]] · Party: [[FN (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 229 Roberto Vannacci

> Roberto Vannacci (ESN).

## Text

Signor Presidente, onorevoli colleghi, in appena due giorni a Ceuta, più di 70.000 invasori hanno travolto illegalmente una frontiera esterna dell'Unione europea: dovevano invaderci i russi, e invece, ci hanno invaso i marocchini.

Oggi ci indebitiamo per 800 miliardi di euro per difenderci dal Cremlino. Ma questa stessa Europa si rifiuta di finanziare quelle barriere fisiche che gli invasori hanno violato per entrare sul territorio spagnolo.

Sanchez prima alimenta il disastro con le sue regolarizzazioni di massa, poi ricaccia indietro in maniera coatta decine di migliaia di persone: in pratica, attua la remigrazione, con tanto di plauso della sinistra progressista. E questo a noi fa molto piacere.

Oggi si stima che a Ceuta ci siano ancora 10.000 clandestini: la polizia spagnola stima la criminalità incrementata di otto volte e la procura indaga su decine di aggressioni sessuali. E questa la chiamiamo emergenza, Commissario Brunner? No, Commissario. Un'immigrazione clandestina che perdura da decenni e che attraversa legislature e governi non è un'emergenza ma è una deliberata scelta politica.

E noi siamo qua per cambiarla, questa politica. Commissario Brunner, e il suo compito principale è smetterla di chiudere gli occhi di fronte a quella che è la vera minaccia per l'Unione europea – l'immigrazione clandestina – e continuare a considerarla un fenomeno antico, ineludibile.

## Summary
Roberto Vannacci says more than 70,000 'invaders' overran an EU external border and that the EU borrows 800 billion euros for defence against Russia but refuses to fund physical barriers. He says Sánchez fed the disaster with mass regularisations, cites rising crime in Ceuta, and tells Commissioner Brunner that decades of illegal immigration are a political choice, not an emergency.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He wants the EU to fund physical barriers against illegal immigration.
- Quote: "questa stessa Europa si rifiuta di finanziare quelle barriere fisiche che gli invasori hanno violato" (translation by the agent: "this same Europe refuses to fund the physical barriers that the invaders breached")

## Entities
- [[Ceuta]]
- [[Russia|russi]]
- [[Spain|spagnolo]]
- [[Pedro Sánchez|Sanchez]]
- [[Magnus Brunner|Commissario Brunner]]

## Topics
- [[External border protection]]
- [[Instrumentalisation of migration]]
- [[Regularisation of migrants]]
- [[Responsibility of the Spanish government]]
- [[Humanitarian situation and victims]]

## Fallacies
- [[FALSE_CAUSE]] (borderline)
  - Quote: "Sanchez prima alimenta il disastro con le sue regolarizzazioni di massa" (translation by the agent: "Sanchez first feeds the disaster with his mass regularisations")
  - Conclusion: The Spanish government caused the crisis.
  - Defect: A causal link between the regularisation and the crossing is asserted without support.
