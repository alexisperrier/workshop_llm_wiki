---
type: "intervention"
kind: "answer"
speech_id: "2017094949344"
order: 231
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:57:07"
end_time: "13:57:40"
speaker: "Roberto Vannacci"
speaker_label: "Roberto Vannacci (ESN), risposta a una domanda \"cartellino blu\"."
group: "ESN"
party: "FN (ITA)"
country: "Italy"
language: "it"
words: 84
position: supports
topics: [Instrumentalisation of migration, External border protection]
fallacies: []
---

Speaker: [[Roberto Vannacci]] · Group: [[ESN]] · Party: [[FN (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 230 Lukas Sieper (question)]]

# 2026-09-15 231 Roberto Vannacci (answer)

> Roberto Vannacci (ESN), risposta a una domanda "cartellino blu".

## Text

Guardi, le rispondo come generale: tutto è possibile in una guerra ibrida. Ma a una guerra si risponde con una guerra, e quindi, si risponde con tutte quelle procedure che sono tipiche di un'attività bellica, e quindi, questo avvalora il fatto che queste barriere fisiche avrebbero dovuto essere finanziate in anticipo e non con il costante rifiuto di questo Parlamento e di questa Commissione di creare una vera barriera contro l'immigrazione clandestina, la quale può essere anche utilizzata come un sistema di guerra ibrido.

## Summary
Answering Lukas Sieper, Roberto Vannacci says everything is possible in hybrid war, that war must be answered with war, and that physical barriers against illegal immigration should have been funded in advance.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He says physical barriers should have been funded in advance.
- Quote: "queste barriere fisiche avrebbero dovuto essere finanziate in anticipo" (translation by the agent: "these physical barriers should have been financed in advance")

## Entities
None.

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]

## Fallacies
None.
