---
type: "intervention"
kind: "chair"
speech_id: "2017094949442"
order: 283
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:57:48"
end_time: "14:58:01"
speaker: "Younous Omarjee"
speaker_label: "Le Président."
group: "The Left"
party: "LFI (FRA)"
country: "France"
language: "fr"
words: 25
topics: []
fallacies: []
---

Speaker: [[Younous Omarjee]] · Group: [[The Left]] · Party: [[LFI (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 283 Younous Omarjee (chair)

> Le Président.

## Text

Merci beaucoup, Monsieur le Ministre. J'ai reçu sept propositions de résolution pour clore ce débat. Le débat est clos et le vote aura lieu jeudi.

## Summary
The chair, Younous Omarjee, announces seven motions for resolutions, closes the debate and says the vote will take place on Thursday.

## Entities
None.

## Topics
None.

## Fallacies
None.
