---
type: "intervention"
kind: "speech"
speech_id: "2017094943132"
order: 224
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:49:55"
end_time: "13:51:13"
speaker: "Oihane Agirregoitia Martínez"
speaker_label: "Oihane Agirregoitia Martínez (Renew)."
group: "Renew"
party: "PNV (ESP)"
country: "Spain"
language: "es"
words: 219
position: mixed
topics: [External border protection, Migrant smuggling, Returns, EU-Morocco relations, Humanitarian situation and victims, Responsibility of the Spanish government]
fallacies: []
---

Speaker: [[Oihane Agirregoitia Martínez]] · Group: [[Renew]] · Party: [[PNV (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 224 Oihane Agirregoitia Martínez

> Oihane Agirregoitia Martínez (Renew).

## Text

Señor presidente, no vamos a mirar hacia otro lado con respecto a las responsabilidades del Reino de Marruecos, del Gobierno español o de la Unión Europea, pero tampoco vamos a participar en circos.

Hemos visto una frontera exterior europea violada, una ciudad sobrepasada, problemas de seguridad, menores pululando en condiciones indignas, un Gobierno desbordado y una mala respuesta por parte de varios Estados miembros de la Unión Europea.

La inmigración hay que gobernarla, las fronteras hay que controlarlas. Hay que luchar contra las mafias. Quien tiene derecho a protección debe recibirla y quien no tenga derecho a permanecer deberá retornar, siempre de acuerdo a la ley y con respeto a los derechos humanos.

Pero hoy también quiero hacerme eco de ese email que recibíamos ayer todos los eurodiputados y eurodiputadas de la Embajada del Reino de Marruecos. Y me remito a leer literalmente: «Marruecos se compromete a readmitir a todas las personas afectadas, incluidos los ciudadanos marroquíes, los menores no acompañados y los nacionales de terceros países». Pues hágase, porque las imágenes y la información que estamos recibiendo no dicen lo mismo.

Marruecos, un país que es sede y que aspira a acoger la final de un mundial de fútbol en 2030 debería tener capacidad de abordar estas y otras realidades y desigualdades sociales. Eso es gobernar y distribuir...

## Summary
Oihane Agirregoitia Martínez says she will not ignore the responsibilities of Morocco, the Spanish government or the EU, but will not take part in a circus. She calls for governing migration, controlling borders, fighting smugglers and returning those with no right to stay within the law, and asks Morocco to honour its commitment, read from its embassy's email, to readmit everyone.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: mixed
- Justification: She supports border control and returns but insists on the law and human rights and on Morocco's responsibility.
- Quote: "La inmigración hay que gobernarla, las fronteras hay que controlarlas. Hay que luchar contra las mafias." (translation by the agent: "Immigration must be governed, borders must be controlled. We must fight the mafias.")

## Entities
- [[Morocco|Reino de Marruecos]]
- [[Government of Spain|Gobierno español]]
- [[Embassy of Morocco|Embajada del Reino de Marruecos]]

## Topics
- [[External border protection]]
- [[Migrant smuggling]]
- [[Returns]]
- [[EU-Morocco relations]]
- [[Humanitarian situation and victims]]
- [[Responsibility of the Spanish government]]

## Fallacies
None.
