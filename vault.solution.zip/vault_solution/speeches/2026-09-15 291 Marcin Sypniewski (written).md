---
type: "intervention"
kind: "written"
speech_id: "2017096449360"
order: 291
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
speaker: "Marcin Sypniewski"
speaker_label: "Marcin Sypniewski (ESN), na piśmie."
group: "ESN"
party: "Konfederacja (POL)"
country: "Poland"
language: "pl"
words: 200
position: supports
topics: [Instrumentalisation of migration, External border protection, Returns, Migrant smuggling, Solidarity between Member States]
fallacies: []
---

Speaker: [[Marcin Sypniewski]] · Group: [[ESN]] · Party: [[Konfederacja (POL)]] · Country: [[Poland]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-09-15 291 Marcin Sypniewski (written)

> Marcin Sypniewski (ESN), na piśmie.

## Text

Nielegalna masowa migracja jest jednym z najpoważniejszych zagrożeń dla bezpieczeństwa i stabilności państw europejskich, szczególnie wtedy, gdy staje się narzędziem nacisku politycznego ze strony państw trzecich. Wydarzenia w Ceucie pokazują, do czego prowadzi wieloletnia polityka tolerowania presji migracyjnej i tworzenia przekonania, że nielegalne przekroczenie granicy może ostatecznie zakończyć się pozostaniem w Europie. Taki model zachęca do podejmowania kolejnych prób, wzmacnia przemytników ludzi i utrudnia państwom skuteczną ochronę własnego terytorium. Hiszpania powinna zdecydowanie bronić swoich granic, tak jak Polska robiła to w obliczu presji migracyjnej organizowanej przez reżim białoruski. Państwo ma obowiązek chronić własne terytorium i nie może pozwalać, by nielegalna migracja była wykorzystywana jako narzędzie nacisku politycznego.Jednocześnie należy krytycznie spojrzeć na unijną politykę migracyjną, która zbyt często koncentruje się na zarządzaniu skutkami masowej migracji zamiast na jej powstrzymywaniu. Nie wystarczą deklaracje o solidarności, koordynacji czy kolejnych mechanizmach współpracy, jeśli równocześnie osłabia się znaczenie fizycznej ochrony granic i skutecznych procedur deportacji. Szczególnie niezrozumiałe jest odrzucanie rozwiązań, które pozwalałyby realnie wzmocnić kontrolę na granicy Ceuty z Marokiem. Potrzebujemy polityki opartej na ochronie granic, szybkich powrotach osób przebywających nielegalnie oraz odpowiedzialności państw za własne bezpieczeństwo. Solidarność europejska powinna oznaczać pomoc w zatrzymywaniu nielegalnej migracji, a nie rozdzielanie jej skutków pomiędzy kolejne państwa członkowskie

## Summary
In a written statement, Marcin Sypniewski calls illegal mass migration one of the gravest threats to European states, especially when used by third states as political pressure. He says Spain should defend its borders as Poland did against Belarus, and that European solidarity should mean help to stop illegal migration, not distributing its effects among Member States.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He calls for physical border protection and rapid returns.
- Quote: "Potrzebujemy polityki opartej na ochronie granic, szybkich powrotach osób przebywających nielegalnie" (translation by the agent: "We need a policy based on border protection and rapid returns of those staying illegally")

## Entities
- [[Ceuta|Ceucie]]
- [[Spain|Hiszpania]]
- [[Poland|Polska]]
- [[Belarus|białoruski]]
- [[Morocco|Marokiem]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Returns]]
- [[Migrant smuggling]]
- [[Solidarity between Member States]]

## Fallacies
None.
