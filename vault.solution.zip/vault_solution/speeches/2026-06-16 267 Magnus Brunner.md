---
type: "intervention"
kind: "speech"
speech_id: "2017081987260"
order: 267
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:21:14"
end_time: "14:24:21"
speaker: "Magnus Brunner"
speaker_label: "Magnus Brunner, Member of the Commission."
language: "en"
words: 442
position: supports
topics: [Returns, Pact on Migration and Asylum, External border protection]
fallacies: []
---

Speaker: [[Magnus Brunner]] · Role: Member of the Commission
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 267 Magnus Brunner

> Magnus Brunner, Member of the Commission.

## Text

Mr President, honourable Members, tomorrow's vote on the Return Regulation comes a few days after the entry into application of the Pact on Migration and Asylum. Finally, there are actually no longer any missing pieces in this whole European reform – our major reform – with which we are bringing our European House in order.

Ten years ago, we did take a lot of responsibility as a European Union, but, as I always like to say, we didn't have a system, we didn't have rules – or we didn't have the right rules – and we didn't have control over what is happening in the European Union.

So now we are actually opening a new chapter with fair rules, with firm rules, with more effective rules, also, that counter abuses with a strong balance between solidarity and responsibility, with better control of our borders, also, thanks to new tools and new technology – the Entry/Exit System, for instance – and also with a stronger and more assertive migration diplomacy.

We have already taken a lot of actions, and it's actually starting to pay off. We've seen a decrease of illegal migration of 55 % in the last two years – on some routes, like the Western Balkan route, even of 90 % in the last three years. But –and that's what tomorrow is about – also, we need to get better in returning, of course, people who are in Europe without any right.

Today, as we know, only slightly more than one out of four people who have no right to stay in the European Union are actually being returned. This is just not acceptable and not sustainable. The citizens in Europe cannot accept, which I totally understand, that people don't respect our rules also. The Return Regulation, I think, is an important answer to the concerns that citizens in Europe actually have.

We will make return swifter, more effective, while also, of course, respecting the people's rights. And it will give us stronger tools to return people who don't cooperate, as you mentioned, with the authorities, if they run away from their obligation, if they do not return voluntarily, or especially if they pose a security risk to the European Union. So this regulation tells everybody that it is us and not the smugglers deciding who can stay in the in the European Union and who must leave.

I would like to thank this House and in particular, of course, you, Mr Azmani, as rapporteur, all the shadow rapporteurs, of course, and the whole negotiating teams also for their work on this key instrument. I think it is really a success.

## Summary
Commissioner Brunner says the vote comes days after the Pact entered into application and completes the reform, which gives the EU fair, firm rules, better border control with tools like the Entry/Exit System and stronger migration diplomacy. Illegal migration fell 55% in two years, but only one in four people with no right to stay is returned; the regulation will make returns swifter and give tools against those who abscond or pose a security risk.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He calls the regulation a key instrument and a success.
- Quote: "The Return Regulation, I think, is an important answer to the concerns that citizens in Europe actually have."

## Entities
- [[Return Regulation]]
- [[Pact on Migration and Asylum]]
- [[Entry-Exit System|Entry/Exit System]]
- [[Western Balkan route]]
- [[Malik Azmani|Mr Azmani]]

## Topics
- [[Returns]]
- [[Pact on Migration and Asylum]]
- [[External border protection]]

## Fallacies
None.
