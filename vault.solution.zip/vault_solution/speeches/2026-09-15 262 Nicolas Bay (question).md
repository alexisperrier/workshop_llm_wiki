---
type: "intervention"
kind: "question"
speech_id: "2017094949403"
order: 262
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:32:33"
end_time: "14:33:09"
speaker: "Nicolas Bay"
speaker_label: "Nicolas Bay (ECR), question «carton bleu»."
group: "ECR"
party: "IDL (FRA)"
country: "France"
language: "fr"
words: 120
position: not_stated
topics: [Regularisation of migrants, Responsibility of the Spanish government, Migrant smuggling]
fallacies: [FALSE_CAUSE]
---

Speaker: [[Nicolas Bay]] · Group: [[ECR]] · Party: [[IDL (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 261 Murielle Laurent]]

# 2026-09-15 262 Nicolas Bay (question)

> Nicolas Bay (ECR), question «carton bleu».

## Text

Monsieur le Président, quand on écoute la gauche européenne depuis tout à l'heure, on nous explique qu'il faut faire preuve de solidarité à l'égard de Ceuta. Évidemment, nous sommes solidaires des populations de Ceuta. Mais c'est vous qui les avez trahies. C'est la gauche européenne, le gouvernement de Sanchez, avec 500 000 régularisations, qui a envoyé le signal le plus désastreux, celui du laxisme migratoire.

Ce signal a été reçu cinq sur cinq à la fois par les candidats à l'immigration clandestine et par les mafias de passeurs. Le résultat? Parce que le gouvernement socialiste espagnol que vous défendez est le maillon le plus faible de l'Europe en matière migratoire, eh bien, ce sont les habitants de Ceuta qui trinquent.

## Summary
In a blue-card question to Murielle Laurent, Nicolas Bay says the European left and the Sánchez government betrayed the people of Ceuta, because 500,000 regularisations sent a signal of laxity to would-be migrants and smugglers.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about the regularisation, not border protection.
- Quote: "c'est vous qui les avez trahies" (translation by the agent: "it is you who betrayed them")

## Entities
- [[Ceuta]]
- [[Pedro Sánchez|Sanchez]]

## Topics
- [[Regularisation of migrants]]
- [[Responsibility of the Spanish government]]
- [[Migrant smuggling]]

## Fallacies
- [[FALSE_CAUSE]] (borderline)
  - Quote: "le gouvernement de Sanchez, avec 500 000 régularisations, qui a envoyé le signal le plus désastreux, celui du laxisme migratoire" (translation by the agent: "the Sanchez government, with 500,000 regularisations, which sent the most disastrous signal, that of migratory laxity")
  - Conclusion: The regularisation caused the crisis in Ceuta.
  - Defect: A single cause is asserted for the crossing without support.
