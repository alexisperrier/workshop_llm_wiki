---
type: "intervention"
kind: "written"
speech_id: "2017096858859"
order: 286
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
speaker: "Joachim Stanisław Brudziński"
speaker_label: "Joachim Stanisław Brudziński (ECR), na piśmie."
group: "ECR"
party: "PiS (POL)"
country: "Poland"
language: "pl"
words: 198
position: supports
topics: [Responsibility of the Spanish government, Humanitarian situation and victims, EU-Morocco relations, External border protection]
fallacies: [UNSUPPORTED_ASSERTION, HASTY_GENERALIZATION]
---

Speaker: [[Joachim Stanisław Brudziński]] · Group: [[ECR]] · Party: [[PiS (POL)]] · Country: [[Poland]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-09-15 286 Joachim Stanisław Brudziński (written)

> Joachim Stanisław Brudziński (ECR), na piśmie.

## Text

Kiedy 80 000 nielegalnych imigrantów wdziera się do miasta liczącego 80 000 mieszkańców, o obszarze mniejszym niż 20 kilometrów kwadratowych – nie jest to przypadek. Hiszpański rząd zapewnia, że wszystko jest pod kontrolą, że większość najeźdzców już wróciła do Maroka i że wszystko jest w porządku. Jednak każdy, kto widział relacje z Ceuty i słyszał, co mają do powiedzenia jej mieszkańcy wie, jak dalekie od prawdy są te zapewnienia. Plaże zamieniły się w dzikie obozowiska i slumsy, a mieszkańcy Ceuty boją się wychodzić na ulice. Pewnie zastanawiają się co się dzieje, dlaczego nikt ich nie chroni i gdzie są ich prawa?I tu jest problem: lewicowy rząd Hiszpanii może po prostu nie przestrzegać prawa, przy przyzwoleniu KE wpuszczać na teren UE kogo tylko chce, wciąż ślepo wierząc, że głosami tych nowoprzybyłych utrzyma się u władzy. A gdzie jest poszanowanie prawa migracyjnego? Gdzie ochrona granic zewnętrznych UE? Gdzie ochrona nawet hiszpańskich obywateli mieszkających na Ceucie? A przecież Maroko otrzymuje ogromne fundusze z unijnej kasy na politykę migracyjną, na zarządzanie granicami i zwalczanie nielegalnej migracji. W latach 2021–2024 UE przekazała Maroku 222 mln euro. Do końca obecnego cyklu budżetowego planowane jest przekazanie kolejnych ok. 190–400 mln euro. Wniosek? To nie działa!

## Summary
In a written statement, Joachim Stanisław Brudziński says 80,000 illegal immigrants entering a city of 80,000 is no accident, contrary to the Spanish government's reassurances. He accuses the left-wing government of ignoring the law with the Commission's consent, and says EU funds for Morocco's border management (222 million euros in 2021–2024) do not work.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He demands protection of the EU's external borders.
- Quote: "Gdzie ochrona granic zewnętrznych UE?" (translation by the agent: "Where is the protection of the EU's external borders?")

## Entities
- [[Morocco|Maroka]]
- [[Ceuta|Ceuty]]
- [[European Commission|KE]]

## Topics
- [[Responsibility of the Spanish government]]
- [[Humanitarian situation and victims]]
- [[EU-Morocco relations]]
- [[External border protection]]

## Fallacies
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "wciąż ślepo wierząc, że głosami tych nowoprzybyłych utrzyma się u władzy" (translation by the agent: "still blindly believing that with the votes of these newcomers it will stay in power")
  - Conclusion: The Spanish government lets migrants in for electoral gain.
  - Defect: A motive is attributed without support.
- [[HASTY_GENERALIZATION]] (borderline)
  - Quote: "W latach 2021–2024 UE przekazała Maroku 222 mln euro. Do końca obecnego cyklu budżetowego planowane jest przekazanie kolejnych ok. 190–400 mln euro. Wniosek? To nie działa!" (translation by the agent: "In 2021–2024 the EU gave Morocco 222 million euros. By the end of the current budget cycle another 190–400 million are planned. Conclusion? It doesn't work!")
  - Conclusion: EU funding to Morocco does not work.
  - Defect: A general verdict on the funding policy is drawn from one event.
