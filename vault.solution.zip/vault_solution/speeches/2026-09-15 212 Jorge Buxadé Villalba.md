---
type: "intervention"
kind: "speech"
speech_id: "2017094943108"
order: 212
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:29:57"
end_time: "13:32:11"
speaker: "Jorge Buxadé Villalba"
speaker_label: "Jorge Buxadé Villalba, en nombre del Grupo PfE."
group: "PfE"
party: "VOX (ESP)"
country: "Spain"
on_behalf_of_group: "PFE"
language: "es"
words: 339
position: supports
topics: [Sovereignty of Ceuta and Melilla, Instrumentalisation of migration, EU-Morocco relations, Responsibility of the Spanish government, External border protection, Humanitarian situation and victims]
fallacies: [AD_HOMINEM, UNSUPPORTED_ASSERTION]
---

Speaker: [[Jorge Buxadé Villalba]] · Group: [[PfE]] · Party: [[VOX (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 212 Jorge Buxadé Villalba

> Jorge Buxadé Villalba, en nombre del Grupo PfE.

## Text

Señora presidente, la invasión de Ceuta no es un caso de entrada ilegal ni una invasión inmigratoria, es un acto de invasión territorial, de ocupación ilegal y violenta de una parte de España que lo es desde 1580, antes de que existiera el Reino de Marruecos —500 años antes— y que seguirá siendo española a pesar de Pedro Sánchez.

Después de siete años, ¿aún se siguen creyendo las mentiras de Sánchez? Ni entraron 80 000 ni se han vuelto todos. Al contrario, hay 15 000 invasores aún deambulando y produciendo inseguridad, miedo y terror en las calles de Ceuta. Señor comisario, hable con el que le hace los papeles, porque Ceuta y Melilla son España y Ceuta y Melilla están en Schengen y ahora mismo hay 15 000 extranjeros ilegalmente en Schengen.

Si el Gobierno de España calla es porque Pedro Sánchez se comporta como un agente de Marruecos y el Partido Socialista como su quinta columna. Quien actúa como un traidor y habla como un traidor es un traidor. Y si ustedes aceptan como normal que un Estado que se presenta como amigo y socio reivindique y trate de usurpar partes integrantes del territorio español, ustedes también son ya parte del problema y el pueblo español les despreciará para siempre.

Usted ha propuesto varias medidas. Yo le propongo otras, la verdadera solidaridad europea: condenar la invasión territorial de la ciudad de Ceuta y las ilegítimas reivindicaciones de Marruecos; considerarlo un acto genuino de guerra híbrida; suspender el Acuerdo de Asociación con Marruecos y todos los acuerdos internacionales con Marruecos —salvo, obviamente, los de retorno y expulsión de los marroquíes—; suspender todos los pagos pendientes a Marruecos, la expedición de visados de entrada de nacionales marroquíes y la concesión de permisos de residencia. Eso es defender España, eso es defender Europa y lo demás es contribuir al negocio de las mafias.

A propósito, no he oído ni una sola palabra de las niñas y adolescentes violadas sistemáticamente por los invasores en Ceuta en un acto genuino de guerra híbrida.

## Summary
Jorge Buxadé Villalba calls the events a territorial invasion of a city Spanish since 1580, accuses Pedro Sánchez of lying about the figures and of acting as an agent of Morocco, and says 15,000 'invaders' remain in Ceuta. He demands that the EU condemn Morocco, treat the events as hybrid war, and suspend the Association Agreement, payments, visas and residence permits for Moroccans.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He wants a much harder response to protect Spanish territory, including sanctions against Morocco.
- Quote: "condenar la invasión territorial de la ciudad de Ceuta y las ilegítimas reivindicaciones de Marruecos; considerarlo un acto genuino de guerra híbrida" (translation by the agent: "condemn the territorial invasion of the city of Ceuta and Morocco's illegitimate claims; consider it a genuine act of hybrid war")

## Entities
- [[Ceuta]]
- [[Spain|España]]
- [[Morocco|Marruecos]]
- [[Pedro Sánchez]]
- [[Melilla]]
- [[Schengen Area|Schengen]]
- [[Government of Spain|Gobierno de España]]
- [[PSOE (ESP)|Partido Socialista]]
- [[EU-Morocco Association Agreement|Acuerdo de Asociación con Marruecos]]

## Topics
- [[Sovereignty of Ceuta and Melilla]]
- [[Instrumentalisation of migration]]
- [[EU-Morocco relations]]
- [[Responsibility of the Spanish government]]
- [[External border protection]]
- [[Humanitarian situation and victims]]

## Fallacies
- [[AD_HOMINEM]] (clear)
  - Quote: "Después de siete años, ¿aún se siguen creyendo las mentiras de Sánchez?" (translation by the agent: "After seven years, do you still believe Sánchez's lies?")
  - Conclusion: The official figures on the entries and returns are false.
  - Defect: The figures are rejected by calling their source a liar, not by evidence against them.
- [[AD_HOMINEM]] (borderline)
  - Quote: "Si el Gobierno de España calla es porque Pedro Sánchez se comporta como un agente de Marruecos" (translation by the agent: "If the Government of Spain is silent it is because Pedro Sánchez behaves like an agent of Morocco")
  - Conclusion: The Spanish government's response is illegitimate.
  - Defect: The government's position is explained away by an attack on the Prime Minister's loyalty rather than discussed.
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "las niñas y adolescentes violadas sistemáticamente por los invasores en Ceuta" (translation by the agent: "the girls and teenagers systematically raped by the invaders in Ceuta")
  - Conclusion: The crossing is an act of hybrid war with grave consequences.
  - Defect: A strong claim of systematic rape is stated without any source.
