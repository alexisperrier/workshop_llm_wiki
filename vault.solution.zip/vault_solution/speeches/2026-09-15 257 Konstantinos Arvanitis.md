---
type: "intervention"
kind: "speech"
speech_id: "2017094949393"
order: 257
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:27:09"
end_time: "14:28:20"
speaker: "Konstantinos Arvanitis"
speaker_label: "Κωνσταντίνος Αρβανίτης (The Left)."
group: "The Left"
party: "SYRIZA (GRC)"
country: "Greece"
language: "el"
words: 170
position: opposes
topics: [Solidarity between Member States, Instrumentalisation of migration, Responsibility of the Spanish government]
fallacies: [STRAW_MAN]
---

Speaker: [[Konstantinos Arvanitis]] · Group: [[The Left]] · Party: [[SYRIZA (GRC)]] · Country: [[Greece]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 257 Konstantinos Arvanitis

> Κωνσταντίνος Αρβανίτης (The Left).

## Text

Κύριε Πρόεδρε, αυτό που παρακολουθούμε στη Θέουτα είναι η κανονικοποίηση και θεσμοποίηση της ακροδεξιάς αντιευρωπαϊκής ατζέντας, που καταργεί το δικαίωμα στο άσυλο, το διεθνές δίκαιο και την ανθρώπινη αξιοπρέπεια. Εμείς στην Ελλάδα έχουμε εμπειρία και εικόνα από αυτό που λέτε εσείς ευρωπαϊκή αλληλεγγύη, αλλά νομίζω ότι στη συγκεκριμένη περίπτωση είναι σαφές ότι πολιτικά κέντρα στην Ευρώπη, αλλά και εκτός αυτής, ήθελαν αποσταθεροποίηση —τόσο στην Ελλάδα το 2015 της αριστερής κυβέρνησης, όσο και στην Ισπανία σήμερα.

Είναι απαράδεκτη η πρωτοβουλία των 22 αρχηγών κρατών της Ένωσης, ανάμεσά τους και ο πρωθυπουργός της Ελλάδας, σε συνδυασμό με τις δηλώσεις Τραμπ και Νετανιάχου, που δεν είναι τίποτα άλλο από μια προσπάθεια επιβολής επικίνδυνης ατζέντας και αποσταθεροποίησης. Ο κύριος Lenaers από το PPE το είπε καθαρά: Διαφωνούμε με την πολιτική σας στο μεταναστευτικό και σας τιμωρούμε. Δεν είναι αυτό Ευρωπαϊκή Ένωση και ευρωπαϊκή αλληλεγγύη. Εμείς θα είμαστε δίπλα στην Ισπανία, και βεβαίως στην κυβέρνησή της και βεβαίως σε όλες τις χώρες του Νότου, σε όλες τις χώρες υποδοχής, απέναντι σε αυτούς τους επικίνδυνους τυχοδιωκτισμούς.

## Summary
Konstantinos Arvanitis says Ceuta shows the far-right agenda being normalised, abolishing the right to asylum and human dignity, and that political centres inside and outside Europe wanted to destabilise left-wing governments, in Greece in 2015 and in Spain now. He condemns the initiative of 22 heads of government, together with statements by Trump and Netanyahu, and stands with Spain and its government.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: He opposes the border-centred response and the 22 governments' initiative, and stands with Spain.
- Quote: "Εμείς θα είμαστε δίπλα στην Ισπανία, και βεβαίως στην κυβέρνησή της" (translation by the agent: "We will stand by Spain, and of course by its government")

## Entities
- [[Ceuta|Θέουτα]]
- [[Greece|Ελλάδα]]
- [[Spain|Ισπανία]]
- [[Donald Trump|Τραμπ]]
- [[Benjamin Netanyahu|Νετανιάχου]]
- [[Jeroen Lenaers|Lenaers]]
- [[PPE]]

## Topics
- [[Solidarity between Member States]]
- [[Instrumentalisation of migration]]
- [[Responsibility of the Spanish government]]

## Fallacies
- [[STRAW_MAN]] (clear)
  - Quote: "Ο κύριος Lenaers από το PPE το είπε καθαρά: Διαφωνούμε με την πολιτική σας στο μεταναστευτικό και σας τιμωρούμε." (translation by the agent: "Mr Lenaers of the PPE said it clearly: we disagree with your migration policy and we punish you.")
  - Conclusion: The EPP's stance is not European solidarity.
  - Defect: An opponent is credited with a statement ('we punish you') he did not make, and that version is then rejected.
