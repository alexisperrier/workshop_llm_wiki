---
type: "intervention"
kind: "question"
speech_id: "2017094949388"
order: 254
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:24:25"
end_time: "14:25:02"
speaker: "Tineke Strik"
speaker_label: "Tineke Strik (Verts/ALE), “blauwe kaart”-vraag."
group: "Verts-ALE"
party: "PRO (NLD)"
country: "Netherlands"
language: "nl"
words: 56
position: not_stated
topics: [Return hubs, Instrumentalisation of migration]
fallacies: []
---

Speaker: [[Tineke Strik]] · Group: [[Verts-ALE]] · Party: [[PRO (NLD)]] · Country: [[Netherlands]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 253 Malik Azmani]]

# 2026-09-15 254 Tineke Strik (question)

> Tineke Strik (Verts/ALE), “blauwe kaart”-vraag.

## Text

Mijnheer Azmani, u was rapporteur voor de terugkeerrichtlijn. U was een groot voorstander van returnhubs, maar met die returnhubs creëren we nog meer afhankelijkheid van derde landen, waar vaak ook autocratische regimes de macht hebben. Hoe gaat u dat voorkomen? Hoe kunnen wij voorkomen dat we in zo'n situaties nog meer blackmail, intimidatie en instrumentalisatie krijgen?

## Summary
In a blue-card question to Malik Azmani, rapporteur for the return rules, Tineke Strik says return hubs create more dependence on third countries, often autocracies, and asks how he will prevent more blackmail and instrumentalisation.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about return hubs, not the EU's response to Ceuta.
- Quote: "Hoe kunnen wij voorkomen dat we in zo'n situaties nog meer blackmail, intimidatie en instrumentalisatie krijgen?" (translation by the agent: "How can we prevent getting even more blackmail, intimidation and instrumentalisation in such situations?")

## Entities
- [[Malik Azmani|Mijnheer Azmani]]
- [[Return Regulation|terugkeerrichtlijn]]

## Topics
- [[Return hubs]]
- [[Instrumentalisation of migration]]

## Fallacies
None.
