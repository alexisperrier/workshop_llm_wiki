---
type: "intervention"
kind: "speech"
speech_id: "2017094943114"
order: 215
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:35:12"
end_time: "13:37:10"
speaker: "Erik Marquardt"
speaker_label: "Erik Marquardt, im Namen der Verts/ALE-Fraktion."
group: "Verts-ALE"
party: "GRÜNE. (DEU)"
country: "Germany"
on_behalf_of_group: "VERTS_ALE"
language: "de"
words: 316
position: opposes
topics: [Humanitarian situation and victims, Instrumentalisation of migration, Solidarity between Member States]
fallacies: [UNSUPPORTED_ASSERTION]
---

Speaker: [[Erik Marquardt]] · Group: [[Verts-ALE]] · Party: [[GRÜNE. (DEU)]] · Country: [[Germany]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 215 Erik Marquardt

> Erik Marquardt, im Namen der Verts/ALE-Fraktion.

## Text

Frau Präsidentin! Liebe Kolleginnen und Kollegen! 141 Menschen sind gestorben. 141 Leben sind nicht mehr da. Familien, die einen Sohn, eine Tochter verloren haben, die eine Schwester verloren haben. Und Europa – wir haben panisch auf diese Situation reagiert, und zwar nicht aus Mitleid mit den Verstorbenen, sondern weil so viele angekommen sind – überlebt haben.

22 Regierungschefs haben Spanien die Schuld gegeben. Parteien zeigen aufeinander, wir streiten uns und wir reden so viel über Instrumentalisierung von Migration. Aber wissen wir eigentlich genau, was das heißt? Die Schuldigen von Instrumentalisierung stehen ja nicht an den Grenzen. Die schwimmen nicht nach Ceuta, die sitzen nicht in Madrid. Die Schuldigen der Instrumentalisierung sind ganz woanders und nutzen die Menschen und ihr Leid für Geopolitik aus. Und wer reflexhaft dann instrumentalisierte Menschen zur Invasion erklärt, zur Bedrohung, ihre Rechte infrage stellt, der bekämpft ja diese Instrumentalisierung nicht, sondern der macht sie erst erfolgreich. Das Ziel der Instrumentalisierung – das ist doch nicht Migration. Das Ziel ist die Spaltung Europas.

Und wer Europa destabilisieren will, der muss einfach erreichen, dass Angst unsere Politik bestimmt. Und ich habe das Gefühl, dass er oder sie hier sehr erfolgreich war. Dass wir einander misstrauen, dass wir Prinzipien aufgeben, die uns eigentlich stark machen. Das Schlachtfeld der Instrumentalisierung, das ist nicht Zaun oder Migration. Das Schlachtfeld ist unsere Reaktion darauf. Wer Instrumentalisierung bekämpfen will, der darf eben nicht die Instrumentalisierten bekämpfen. Wir verteidigen ja hier in Europa nicht einen Zaun. Wir verteidigen die Idee, dass jeder Mensch eine Würde besitzt. Dass sich Europas Stärke darin zeigt, dass wir eben nicht unter Druck ganz schnell unsere Prinzipien aufgeben, sondern dass wir das gerade dann verteidigen, was uns ausmacht.

141 Menschen können uns nicht mehr sagen, was sie sich für ein Europa erhofft haben, aber wir können entscheiden, welches Europa an den Grenzen den Menschen beim nächsten Mal begegnet. Ich hoffe, wir treffen die richtige Entscheidung.

## Summary
Erik Marquardt mourns the 141 dead and says Europe reacted in panic because so many survived and arrived. He argues that those who instrumentalise migration are elsewhere, that calling instrumentalised people an invasion makes the instrumentalisation succeed, and that Europe defends the dignity of every person, not a fence.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: He rejects fighting instrumentalisation by fighting the people instrumentalised and says Europe defends human dignity, not a fence.
- Quote: "Wir verteidigen ja hier in Europa nicht einen Zaun. Wir verteidigen die Idee, dass jeder Mensch eine Würde besitzt." (translation by the agent: "Here in Europe we are not defending a fence. We are defending the idea that every person has dignity.")

## Entities
- [[Spain|Spanien]]
- [[Ceuta]]
- [[Madrid]]

## Topics
- [[Humanitarian situation and victims]]
- [[Instrumentalisation of migration]]
- [[Solidarity between Member States]]

## Fallacies
- [[UNSUPPORTED_ASSERTION]] (borderline)
  - Quote: "Und wer reflexhaft dann instrumentalisierte Menschen zur Invasion erklärt, zur Bedrohung, ihre Rechte infrage stellt, der bekämpft ja diese Instrumentalisierung nicht, sondern der macht sie erst erfolgreich." (translation by the agent: "And whoever reflexively declares instrumentalised people an invasion, a threat, and questions their rights is not fighting this instrumentalisation but is what makes it successful.")
  - Conclusion: A hard response to the crossing plays into the hands of those who instrumentalise migration.
  - Defect: The causal claim is stated without support.
