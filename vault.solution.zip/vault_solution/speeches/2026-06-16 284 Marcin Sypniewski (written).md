---
type: "intervention"
kind: "written"
speech_id: "2017084734447"
order: 284
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
speaker: "Marcin Sypniewski"
speaker_label: "Marcin Sypniewski (ESN), na piśmie."
group: "ESN"
party: "Konfederacja (POL)"
country: "Poland"
language: "pl"
words: 109
position: supports
topics: [Returns, Detention of migrants]
fallacies: []
---

Speaker: [[Marcin Sypniewski]] · Group: [[ESN]] · Party: [[Konfederacja (POL)]] · Country: [[Poland]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-06-16 284 Marcin Sypniewski (written)

> Marcin Sypniewski (ESN), na piśmie.

## Text

Rozmawiamy dziś o fundamencie bezpieczeństwa naszych państw. Dotychczasowa unijna polityka powrotów była fikcją- urzędniczą niemocą, którą nielegalni imigranci po prostu wyśmiewali. Czas z tym skończyć.Popieramy ten raport, ponieważ wprowadza on rozwiązania, o które od dawna zabiegamy. Koniec z bezkarnością osób, które odmawiają współpracy, ukrywają dokumenty i podają fałszywe tożsamości. Kto łamie prawo i nie współpracuje, musi ponieść tego natychmiastowe konsekwencje – w tym utratę świadczeń socjalnych i rozszerzenie zakazu wjazdu.Kluczowe jest dla nas drastyczne zaostrzenie przepisów wobec osób stanowiących zagrożenie dla bezpieczeństwa. Możliwość przetrzymywania ich w detencji do 24 miesięcy oraz bezterminowe zakazy wjazdu to jedyna skuteczna metoda ochrony naszych obywateli.Nielegalna imigracja musi spotykać się z twardą, natychmiastową deportacją.

## Summary
In a written statement, Marcin Sypniewski says EU return policy was a fiction and supports the report for ending impunity for those who refuse to cooperate, with loss of benefits and extended entry bans. He stresses detention of up to 24 months and unlimited entry bans for those posing a security threat.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He supports the report.
- Quote: "Popieramy ten raport, ponieważ wprowadza on rozwiązania, o które od dawna zabiegamy." (translation by the agent: "We support this report because it introduces solutions we have long been calling for.")

## Entities
None.

## Topics
- [[Returns]]
- [[Detention of migrants]]

## Fallacies
None.
