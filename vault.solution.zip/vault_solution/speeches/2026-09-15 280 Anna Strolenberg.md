---
type: "intervention"
kind: "speech"
speech_id: "2017094949438"
order: 280
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:54:02"
end_time: "14:55:03"
speaker: "Anna Strolenberg"
speaker_label: "Anna Strolenberg (Verts/ALE)."
group: "Verts-ALE"
party: "Volt (NLD)"
country: "Netherlands"
language: "en"
words: 146
position: opposes
topics: [Solidarity between Member States, Humanitarian situation and victims, Returns]
fallacies: []
---

Speaker: [[Anna Strolenberg]] · Group: [[Verts-ALE]] · Party: [[Volt (NLD)]] · Country: [[Netherlands]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 280 Anna Strolenberg

> Anna Strolenberg (Verts/ALE).

## Text

Mr President, in Europe, we're facing huge challenges: wildfires, the cost of living, the housing and energy crises. We have to work on them together. But how can we show citizens that we are up to the task if we're so divided, reacting after the tragedy that happened in Ceuta, leaving the people in Ceuta alone, but also causing 140 deaths?

I do not have this trust. Instead of running to Ceuta and helping them out, European leaders wanted to close our borders.

This also happened today in this debate: a blame game started, fuelled by the far-right. But we actually have the tools. We could assist Spain in handling asylum applications. We can offer help in returning people in dignity.

Let's do this so we can finally move on and leave the migration debate as it is and focus on the other issues that matter.

## Summary
Anna Strolenberg says Europe faces many challenges but is divided, leaving Ceuta alone; instead of helping, European leaders wanted to close borders and a blame game fuelled by the far right started. She says the EU has the tools to help Spain process asylum applications and return people in dignity.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She rejects border closures and asks for help to Spain with asylum and dignified returns.
- Quote: "Instead of running to Ceuta and helping them out, European leaders wanted to close our borders."

## Entities
- [[Ceuta]]
- [[Spain]]

## Topics
- [[Solidarity between Member States]]
- [[Humanitarian situation and victims]]
- [[Returns]]

## Fallacies
None.
