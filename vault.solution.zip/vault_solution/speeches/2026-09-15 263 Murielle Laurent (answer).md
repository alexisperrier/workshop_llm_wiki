---
type: "intervention"
kind: "answer"
speech_id: "2017094949404"
order: 263
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:33:09"
end_time: "14:33:37"
speaker: "Murielle Laurent"
speaker_label: "Murielle Laurent (S&D), réponse carton bleu."
group: "S&D"
party: "PS (FRA)"
country: "France"
language: "fr"
words: 84
position: not_stated
topics: [Regularisation of migrants]
fallacies: []
---

Speaker: [[Murielle Laurent]] · Group: [[S&D]] · Party: [[PS (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 262 Nicolas Bay (question)]]

# 2026-09-15 263 Murielle Laurent (answer)

> Murielle Laurent (S&D), réponse carton bleu.

## Text

Alors vous comprendrez bien que je ne suis pas vraiment d'accord avec vous, puisque le signal qu'a envoyé Pedro Sánchez est un signal positif, puisque ces régularisations ont permis aussi de répondre à des difficultés et à un besoin économique et sur la question du travail, et que ces régularisations ont été faites dans un cadre bien spécifique, et que cela répond à un besoin européen auquel on va être confronté, dans le cadre de la crise démographique aussi, dans laquelle on va rentrer.

## Summary
Answering Nicolas Bay, Murielle Laurent says Sánchez's regularisations sent a positive signal, answered labour needs within a specific framework, and respond to Europe's coming demographic crisis.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The answer is about the regularisation.
- Quote: "le signal qu'a envoyé Pedro Sánchez est un signal positif" (translation by the agent: "the signal Pedro Sánchez sent is a positive signal")

## Entities
- [[Pedro Sánchez]]

## Topics
- [[Regularisation of migrants]]

## Fallacies
None.
