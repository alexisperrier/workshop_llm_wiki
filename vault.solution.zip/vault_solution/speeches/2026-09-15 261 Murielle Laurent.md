---
type: "intervention"
kind: "speech"
speech_id: "2017094949401"
order: 261
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:31:06"
end_time: "14:32:24"
speaker: "Murielle Laurent"
speaker_label: "Murielle Laurent (S&D)."
group: "S&D"
party: "PS (FRA)"
country: "France"
language: "fr"
words: 174
position: opposes
topics: [Humanitarian situation and victims, Responsibility of the Spanish government, Solidarity between Member States, Schengen and internal border controls]
fallacies: []
---

Speaker: [[Murielle Laurent]] · Group: [[S&D]] · Party: [[PS (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 261 Murielle Laurent

> Murielle Laurent (S&D).

## Text

Monsieur le Président, Monsieur le Ministre, Monsieur le Commissaire, chers collègues, le drame de Ceuta a fait de trop nombreux morts. Pourtant, alors que l'incertitude planait, la droite et l'extrême droite se sont précipitées pour alimenter une psychose xénophobe en parlant d'invasion du continent nécessitant une militarisation, omettant sciemment que Ceuta ne fait pas partie de l'espace Schengen.

Au lieu de tomber dans l'escalade de la violence, le gouvernement espagnol a mis en place des mesures pour limiter les morts. Il a organisé le retour de la quasi-totalité des personnes dans le respect du droit international. Désormais, il faut prendre en charge les quelques 1 400 mineurs non accompagnés présents sur place. Nous parlons d'enfants. Ils ont besoin de notre solidarité. Cette solidarité doit être non seulement intra-espagnole, mais aussi intra-européenne.

La désolidarisation de nombreux pays européens qui ont appelé à fermer les frontières au lieu d'apporter leur soutien, est inacceptable. Alors que nous sommes menacés par plusieurs impérialismes, envoyer le signal d'une Europe désunie nous déshonore et nous affaiblit aux yeux du monde.

## Summary
Murielle Laurent says the right and far right fed a xenophobic psychosis by talking of an invasion requiring militarisation, while omitting that Ceuta is outside the Schengen area. She says the Spanish government limited deaths and organised almost all returns within international law, calls for solidarity with the 1,400 unaccompanied minors, and condemns countries that called for closing borders.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She rejects militarisation and border closures and calls for solidarity.
- Quote: "La désolidarisation de nombreux pays européens qui ont appelé à fermer les frontières au lieu d'apporter leur soutien, est inacceptable." (translation by the agent: "The lack of solidarity of many European countries that called for closing borders instead of giving their support is unacceptable.")

## Entities
- [[Ceuta]]
- [[Schengen Area|l'espace Schengen]]
- [[Government of Spain|le gouvernement espagnol]]

## Topics
- [[Humanitarian situation and victims]]
- [[Responsibility of the Spanish government]]
- [[Solidarity between Member States]]
- [[Schengen and internal border controls]]

## Fallacies
None.
