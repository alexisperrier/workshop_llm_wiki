---
type: "intervention"
kind: "speech"
speech_id: "2017094949382"
order: 251
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:20:09"
end_time: "14:21:22"
speaker: "Fabrice Leggeri"
speaker_label: "Fabrice Leggeri (PfE)."
group: "PfE"
party: "RN (FRA)"
country: "France"
language: "fr"
words: 197
position: supports
topics: [External border protection, Returns, Humanitarian situation and victims, Responsibility of the Spanish government, EU-Morocco relations, Schengen and internal border controls]
fallacies: [FALSE_CAUSE]
---

Speaker: [[Fabrice Leggeri]] · Group: [[PfE]] · Party: [[RN (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 251 Fabrice Leggeri

> Fabrice Leggeri (PfE).

## Text

Monsieur le Président, plus de 80 000 entrées clandestines en quelques heures. Plus de 2 000 mineurs non accompagnés recensés. 148 clandestins qui ont déjà réussi à traverser la Méditerranée. Une trentaine de procédures pour agressions sexuelles, dont cinq viols officiellement recensés fin août. Combien en réalité? Voilà ce que subit Ceuta.

Et pourtant, même lorsque le Maroc réclame le retour de ses ressortissants mineurs, Madrid préfère en transférer des centaines vers la péninsule et les maintenir sur le territoire européen. Et ne l'oublions pas, Ceuta est dans Schengen, ce qui s'y passe ne concerne donc pas seulement l'Espagne, mais toute l'Europe.

Face à cette situation, quelle est la réponse de Bruxelles? Un nouveau chèque de 115 millions d'euros à l'Espagne, alors que quelques jours auparavant, la Commission attendait encore de Madrid des réponses sur l'usage de cette aide. Comment garantir alors que cet argent protègera réellement notre frontière?

Cette submersion est le résultat de la coupable inaction de la Commission depuis des années et du laxisme que ce soit à gauche, au centre ou à droite. Rétablissez la frontière, renvoyez ceux que le Maroc réclame, expulsez les clandestins et mettez fin à la fraude à l'âge.

## Summary
Fabrice Leggeri lists over 80,000 illegal entries, over 2,000 unaccompanied minors and cases of sexual assault in Ceuta, and says Madrid transfers minors to the mainland though Morocco wants them back. He criticises the new 115 million euro cheque to Spain without guarantees, blames years of Commission inaction, and calls for restoring the border, returning those Morocco claims, expelling illegal migrants and ending age fraud.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He demands restoring the border and expelling illegal migrants.
- Quote: "Rétablissez la frontière, renvoyez ceux que le Maroc réclame, expulsez les clandestins et mettez fin à la fraude à l'âge." (translation by the agent: "Restore the border, send back those Morocco claims, expel the illegal migrants and put an end to age fraud.")

## Entities
- [[Ceuta]]
- [[Morocco|le Maroc]]
- [[Government of Spain|Madrid]]
- [[Schengen Area|Schengen]]
- [[Spain|l'Espagne]]
- [[Brussels|Bruxelles]]
- [[European Commission|la Commission]]

## Topics
- [[External border protection]]
- [[Returns]]
- [[Humanitarian situation and victims]]
- [[Responsibility of the Spanish government]]
- [[EU-Morocco relations]]
- [[Schengen and internal border controls]]

## Fallacies
- [[FALSE_CAUSE]] (borderline)
  - Quote: "Cette submersion est le résultat de la coupable inaction de la Commission depuis des années" (translation by the agent: "This submersion is the result of the Commission's culpable inaction for years")
  - Conclusion: The Commission is responsible for the crisis.
  - Defect: A single cause is given for an outcome with several causes, without support.
