---
type: "intervention"
kind: "speech"
speech_id: "2017094943103"
order: 210
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:24:26"
end_time: "13:26:49"
speaker: "Jeroen Lenaers"
speaker_label: "Jeroen Lenaers, on behalf of the PPE Group."
group: "PPE"
party: "CDA (NLD)"
country: "Netherlands"
on_behalf_of_group: "PPE"
language: "en"
words: 339
position: supports
topics: [Sovereignty of Ceuta and Melilla, External border protection, Instrumentalisation of migration, Responsibility of the Spanish government, Regularisation of migrants, Returns, Pact on Migration and Asylum, Solidarity between Member States]
fallacies: []
---

Speaker: [[Jeroen Lenaers]] · Group: [[PPE]] · Party: [[CDA (NLD)]] · Country: [[Netherlands]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 210 Jeroen Lenaers

> Jeroen Lenaers, on behalf of the PPE Group.

## Text

Madam President, for the EPP, today's debate is about a simple yet important message – and this is a message for the people of Ceuta: Ceuta is Spain, Ceuta is Europe, and we stand with you.

The sovereignty and territorial integrity of Member States are non-negotiable, borders are non-negotiable, and order must be restored, so that the people of Ceuta can return to their normal lives.

Because when Europe's external border is breached at such an unprecedented scale, this is not simply a Spanish problem, it is a European security challenge. And the warnings were there. The declassified documents make this very clear. Police and intelligence services did their job. The government failed to act.

Now, Prime Minister Sánchez is asking for solidarity in a crisis, after continuously resisting the common tools needed to prevent one: opposing more effective measures at the European level, like the returns regulation; initiating unilateral mass regularisations, even though agreements in Europe are there to not do so.

It's an interesting approach. But let us be very clear. Solidarity is needed, and our solidarity is first and foremost with the citizens of Ceuta. The European Commission did its part. It offered Spain support from day one. Yet it took weeks before the Spanish Government formally requested that European support – which is, quite frankly, unbelievable.

Now, we've had experience. We've seen instrumentalisation and weaponisation before: in Greece, in Poland, in the Baltic states and in Finland. But what is new is the scale and the fact that it is now happening on Europe's southern flank.

So what do we need to do? Three points. First, strengthen Frontex. Two, we need a genuine European emergency mechanism – Member States need exceptional tools to deal with exceptional situations. Third, implement what we already agreed. The Pact is there: screening, border procedures, solidarity, effective returns. They must work in practice, not just on paper.

Our goal is simple. Instead of debating the next crisis after it happens, let us make sure we are ready to prevent it.

## Summary
Speaking for the EPP, Jeroen Lenaers says Ceuta is Spain and Europe and that the breach is a European security challenge. He accuses the Spanish government of ignoring warnings, opposing the returns regulation and carrying out mass regularisations, and calls for a stronger Frontex, a European emergency mechanism and full implementation of the Pact.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: His first answer to the crisis is to strengthen Frontex and to create emergency tools to protect the border.
- Quote: "First, strengthen Frontex. Two, we need a genuine European emergency mechanism"

## Entities
- [[PPE|EPP]]
- [[Ceuta]]
- [[Pedro Sánchez|Prime Minister Sánchez]]
- [[Return Regulation|returns regulation]]
- [[European Commission]]
- [[Spain]]
- [[Government of Spain|Spanish Government]]
- [[Greece]]
- [[Poland]]
- [[Finland]]
- [[Frontex]]
- [[Pact on Migration and Asylum|The Pact]]

## Topics
- [[Sovereignty of Ceuta and Melilla]]
- [[External border protection]]
- [[Instrumentalisation of migration]]
- [[Responsibility of the Spanish government]]
- [[Regularisation of migrants]]
- [[Returns]]
- [[Pact on Migration and Asylum]]
- [[Solidarity between Member States]]

## Fallacies
None.
