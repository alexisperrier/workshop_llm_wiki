---
type: "intervention"
kind: "speech"
speech_id: "2017081987267"
order: 270
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:29:10"
end_time: "14:32:00"
speaker: "Fabrice Leggeri"
speaker_label: "Fabrice Leggeri, au nom du groupe PfE."
group: "PfE"
party: "RN (FRA)"
country: "France"
on_behalf_of_group: "PFE"
language: "fr"
words: 486
position: supports
topics: [Returns, Detention of migrants, Return hubs, External border protection, Majorities in Parliament]
fallacies: [HASTY_GENERALIZATION]
---

Speaker: [[Fabrice Leggeri]] · Group: [[PfE]] · Party: [[RN (FRA)]] · Country: [[France]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 270 Fabrice Leggeri

> Fabrice Leggeri, au nom du groupe PfE.

## Text

Monsieur le Président, Monsieur le Commissaire Brunner, derrière nos débats sur l’immigration, il y a des visages. Il y a Lola, il y a Philippine, il y a les victimes de Bruxelles, de Solingen, d’Aschaffenbourg, de Munich, de Villach et de Mannheim. Partout en Europe, des familles ont vu leur vie basculer. Nous leur devons la vérité.

Ces drames n’auraient jamais dû se produire – si nos frontières n’avaient pas été transformées en passoire, si les décisions d’éloignement avaient été exécutées, si certains responsables politiques n’avaient pas fermé les yeux pendant des années sur les conséquences de l’immigration illégale… C’est précisément pour cela que l’adoption du règlement sur le retour, demain, constituera une avancée significative.

Depuis trop longtemps, la politique migratoire européenne reposait sur une logique absurde. Tout était fait pour empêcher les expulsions et presque rien pour les rendre effectives. La gauche, les ONG militantes et une partie de la Commission européenne, notamment sous l’impulsion de Mme Ylva Johansson, ont entretenu cette fuite en avant avec la complicité d’une droite dite modérée, qui a trop souvent accompagné ce mouvement au lieu de le combattre.

Pendant des années, Bruxelles a davantage protégé les clandestins contre leur éloignement que les Européens contre les conséquences de l’immigration illégale. Ce texte marque enfin un changement de cap. L’allongement de la durée maximale de rétention administrative à vingt-quatre mois – alors qu’en France certains macronistes s’enorgueillissaient de l’avoir allongé de trois à sept petits mois –, le rétablissement du délit de séjour irrégulier, la fin du caractère automatiquement suspensif de nombreux recours, l’obligation pour les migrants de coopérer à leur éloignement et la création de hubs de retour hors de l’Union européenne étaient encore impensables à Bruxelles il y a quelques années.

Après les règlements sur les pays tiers sûrs et les pays d’origine sûrs, ce vote démontre qu’une autre politique migratoire est possible, lorsque les forces du bon sens de la droite de cet hémicycle travaillent ensemble. Mais ce travail n’est pas terminé. Trop de pays refusent encore de reprendre leurs ressortissants tout en profitant des avantages accordés par l’Union – je pense notamment au régime algérien. Les visas, l’aide financière européenne et les avantages accordés par l’Union doivent désormais être conditionnés à la reprise effective de leurs ressortissants.

Mais regardons aussi nos propres échecs: en France, 1 obligation de quitter le territoire sur 7 est exécutée.

Certains, dans cet hémicycle, appartiennent à des partis qui gouvernent nos pays depuis des décennies et portent une responsabilité directe dans cette situation. Pendant des années, ils ont promis la fermeté et organisé l’impuissance; ils ont promis des expulsions et laissé les clandestins rentrer; ils ont promis le contrôle et laissé prospérer le désordre migratoire.

Nos peuples ne demandent pourtant rien d’extraordinaire: ils demandent simplement que ceux qui n’ont pas le droit d’être ici repartent, que les criminels étrangers soient expulsés et que les décisions de retour deviennent enfin des retours effectifs.

## Summary
Fabrice Leggeri cites victims of attacks in Brussels, Solingen, Aschaffenburg, Munich, Villach and Mannheim, which he says would not have happened if borders had held and return decisions been enforced. He blames the left, NGOs, Ylva Johansson and the moderate right, welcomes 24-month detention, the offence of irregular stay, non-suspensive appeals, the duty to cooperate and return hubs outside the EU, and calls for conditioning visas and aid on readmission, naming Algeria.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He calls the adoption of the regulation a significant step forward.
- Quote: "l'adoption du règlement sur le retour, demain, constituera une avancée significative" (translation by the agent: "the adoption of the return regulation tomorrow will be a significant step forward")

## Entities
- [[Magnus Brunner|Monsieur le Commissaire Brunner]]
- [[Brussels|Bruxelles]]
- [[Solingen]]
- [[Aschaffenburg|Aschaffenbourg]]
- [[Munich]]
- [[Villach]]
- [[Mannheim]]
- [[Return Regulation|règlement sur le retour]]
- [[European Commission|Commission européenne]]
- [[Ylva Johansson|Mme Ylva Johansson]]
- [[France]]
- [[Safe Third Country Regulation|pays tiers sûrs]]
- [[Safe Countries of Origin Regulation|pays d'origine sûrs]]
- [[Algeria|algérien]]

## Topics
- [[Returns]]
- [[Detention of migrants]]
- [[Return hubs]]
- [[External border protection]]
- [[Majorities in Parliament]]

## Fallacies
- [[HASTY_GENERALIZATION]] (borderline)
  - Quote: "Ces drames n’auraient jamais dû se produire – si nos frontières n’avaient pas été transformées en passoire, si les décisions d’éloignement avaient été exécutées" (translation by the agent: "These tragedies should never have happened – if our borders had not been turned into a sieve, if removal decisions had been enforced")
  - Conclusion: Europe's borders and return system have failed.
  - Defect: A general verdict on borders and returns is drawn from a few cited attacks.
