---
type: "intervention"
kind: "written"
speech_id: "2017084803884"
order: 285
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
speaker: "Ivaylo Valchev"
speaker_label: "Ивайло Вълчев (ECR), в писмена форма."
group: "ECR"
party: "ITN (BGR)"
country: "Bulgaria"
language: "bg"
words: 191
position: supports
topics: [Returns, Majorities in Parliament]
fallacies: [STRAW_MAN, HASTY_GENERALIZATION]
---

Speaker: [[Ivaylo Valchev]] · Group: [[ECR]] · Party: [[ITN (BGR)]] · Country: [[Bulgaria]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-06-16 285 Ivaylo Valchev (written)

> Ивайло Вълчев (ECR), в писмена форма.

## Text

Уважаеми колеги,Трябва да приемем законодателната резолюция, с която да уредим обща система за връщане на нелегалните имигранти, които пребивават незаконно на територията на Съюза.Това трябваше да се случи много отдавна, но мнозинството в ляво се противопоставяше, въпреки очевидната нужда от мерки срещу нелегалната миграция и репатрирането на нелегалните имигранти. Вместо това те ни предложиха да ги оставим в Европа, да безчинствата, както се случи на коледния базар Кьолн, да застрашават живота на нашите жени и деца.Тази криза с нелегалната миграция доведе до това, че темата стана основна в нашите общества, а те ясно показаха, че искат всеки, който не бяга от война да бъде върнат в родината му. Всеки, който е нарушил нашата граница и е преминал нелегално, да бъде върнат в родината му. Аз съм и ще продължа да бъда застъпник на тази идея, защото Европа има нужда от сигурност и ред. А не от милион нелегални имигранти, които не са лекари и инженери, както ни убеждава левицата, а са хора, които веднага се присъединиха към криминалния контингент. България е държава на първа линия, граница на Европейския съюз. Надявам се този регламент да е стъпката към спирането на нелегалната миграция.Благодаря.

## Summary
In a written statement, Ivaylo Valchev says the regulation should have come long ago but the left-wing majority opposed it, and that citizens want everyone not fleeing war to be returned. He links illegal migrants to crime, citing Cologne, and says Bulgaria, a front-line state, hopes the regulation will stop illegal migration.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He calls for adopting the regulation.
- Quote: "Трябва да приемем законодателната резолюция" (translation by the agent: "We must adopt the legislative resolution")

## Entities
- [[Cologne|Кьолн]]
- [[Bulgaria|България]]

## Topics
- [[Returns]]
- [[Majorities in Parliament]]

## Fallacies
- [[STRAW_MAN]] (clear)
  - Quote: "Вместо това те ни предложиха да ги оставим в Европа, да безчинствата" (translation by the agent: "Instead they proposed to us that we leave them in Europe, to run riot")
  - Conclusion: The left's opposition to returns was wrong.
  - Defect: The left is credited with proposing to let migrants run riot, a position no one held, which is then rejected.
- [[HASTY_GENERALIZATION]] (borderline)
  - Quote: "не са лекари и инженери, както ни убеждава левицата, а са хора, които веднага се присъединиха към криминалния контингент" (translation by the agent: "are not doctors and engineers, as the left tries to convince us, but people who immediately joined the criminal contingent")
  - Conclusion: Illegal migrants are criminals.
  - Defect: A general claim about all illegal migrants rests on one cited case, Cologne.
