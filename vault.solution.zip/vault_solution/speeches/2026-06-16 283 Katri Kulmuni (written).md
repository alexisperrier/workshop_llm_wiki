---
type: "intervention"
kind: "written"
speech_id: "2017083047160"
order: 283
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
speaker: "Katri Kulmuni"
speaker_label: "Katri Kulmuni (Renew), kirjallinen."
group: "Renew"
party: "KESK (FIN)"
country: "Finland"
language: "fi"
words: 117
position: mixed
topics: [Returns, Return hubs, Humanitarian situation and victims]
fallacies: []
---

Speaker: [[Katri Kulmuni]] · Group: [[Renew]] · Party: [[KESK (FIN)]] · Country: [[Finland]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-06-16 283 Katri Kulmuni (written)

> Katri Kulmuni (Renew), kirjallinen.

## Text

Esitys yhteisen järjestelmän perustamisesta unionissa laittomasti olevien kolmansien maiden kansalaisten palauttamiseksi ei ole kaikilta osin ongelmaton, mutta sen tavoitteet ovat kuitenkin tarpeellisia. Perusongelma tämän kysymyksen kohdalla on se, että turvapaikkajärjestelmää on jo pitkään käytetty siirtolaisuuden väylänä Eurooppaan. Tämä ei ole järjestelmän tarkoitus eikä järjestelmä nykyisellään sellaista kestä, vaan lailliselle ja lähinnä työperäiselle maahanmuutolle on omat kanavansa.Käytännössä esitys helpottaisi laittomasti EU:n alueella olevien henkilöiden palauttamista, kun yhden jäsenmaan tekemä palautuspäätös tunnustettaisiin toisissakin maissa. Esitys mahdollistaa myös EU:n ulkopuolella olevien palautuskeskusten perustamisen. Turvapaikkapolitiikka on silti ensi sijassa jokaisen jäsenmaan omassa päätösvallassa. On myös hyvä muistaa, että jokainen tapaus on tietysti yksilöllinen, ja on pyrittävä ratkaisuihin, joissa erityisesti pienten lasten ja muiden hauraimmassa asemassa olevien ihmisten oikeudet turvataan käytännön tilanteissa.

## Summary
In a written statement, Katri Kulmuni says the proposal is not unproblematic but its goals are necessary, since the asylum system has long been used as a migration route. She notes mutual recognition of return decisions and return centres outside the EU, recalls that asylum policy remains mainly national, and asks that the rights of young children and the most vulnerable be protected.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: mixed
- Justification: She supports the goals but notes problems, especially for children and vulnerable people.
- Quote: "Esitys yhteisen järjestelmän perustamisesta unionissa laittomasti olevien kolmansien maiden kansalaisten palauttamiseksi ei ole kaikilta osin ongelmaton" (translation by the agent: "The proposal for a common system for returning third-country nationals staying illegally in the Union is not unproblematic in all respects")

## Entities
None.

## Topics
- [[Returns]]
- [[Return hubs]]
- [[Humanitarian situation and victims]]

## Fallacies
None.
