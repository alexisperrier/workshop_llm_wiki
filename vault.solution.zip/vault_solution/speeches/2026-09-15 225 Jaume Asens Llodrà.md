---
type: "intervention"
kind: "speech"
speech_id: "2017094943134"
order: 225
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:51:22"
end_time: "13:52:27"
speaker: "Jaume Asens Llodrà"
speaker_label: "Jaume Asens Llodrà (Verts/ALE)."
group: "Verts-ALE"
party: "Catalunya en Comú (ESP)"
country: "Spain"
language: "es"
words: 152
position: not_stated
topics: [Humanitarian situation and victims]
fallacies: [FALSE_CAUSE]
---

Speaker: [[Jaume Asens Llodrà]] · Group: [[Verts-ALE]] · Party: [[Catalunya en Comú (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 225 Jaume Asens Llodrà

> Jaume Asens Llodrà (Verts/ALE).

## Text

Señor presidente, señor Buxadé, tiene usted razón.

En Ceuta hay una invasión, pero no de migrantes, sino de fascistas y racistas que empezó y se extendió a otras ciudades cuando ustedes llamaron a cazar a los inmigrantes uno a uno, cazar a seres humanos.

¿De verdad, señorías de VOX? Qué miserables, qué ruines. Es por discursos como ese que ustedes son los responsables políticos de ese Ku Klux Klan de cazadores que están agrediendo, que están atacando, provocando incendios a la Cruz Roja, también atacando a los periodistas. E incluso a un niño de ocho años, que le han disparado.

En Alemania, el horror no empezó en los campos de concentración. Empezó antes, cuando se deshumanizó al otro como piezas de caza. Antes eran los judíos, ahora son los musulmanes. Los judíos sionistas también, los árabes, los palestinos y los migrantes. Y quienes los persiguen son los mismos: la derecha, ustedes.

Señorías...

## Summary
Addressing Jorge Buxadé, Jaume Asens Llodrà says the invasion in Ceuta is one of fascists and racists, and holds VOX politically responsible for vigilantes attacking migrants, the Red Cross and journalists. He compares the dehumanisation of migrants to the run-up to the Holocaust.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: He attacks the far right's language and its consequences but does not address border protection.
- Quote: "En Ceuta hay una invasión, pero no de migrantes, sino de fascistas y racistas" (translation by the agent: "In Ceuta there is an invasion, but not of migrants, of fascists and racists")

## Entities
- [[Jorge Buxadé Villalba|señor Buxadé]]
- [[Ceuta]]
- [[VOX (ESP)|VOX]]
- [[Ku Klux Klan]]
- [[Red Cross|Cruz Roja]]
- [[Germany|Alemania]]

## Topics
- [[Humanitarian situation and victims]]

## Fallacies
- [[FALSE_CAUSE]] (borderline)
  - Quote: "Es por discursos como ese que ustedes son los responsables políticos de ese Ku Klux Klan de cazadores" (translation by the agent: "It is because of speeches like that that you are politically responsible for that Ku Klux Klan of hunters")
  - Conclusion: VOX is responsible for the attacks on migrants.
  - Defect: A causal link between a speech and acts of violence is asserted without support.
