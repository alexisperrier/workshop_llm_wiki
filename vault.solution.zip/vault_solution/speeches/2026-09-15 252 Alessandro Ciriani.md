---
type: "intervention"
kind: "speech"
speech_id: "2017094949384"
order: 252
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:21:33"
end_time: "14:22:47"
speaker: "Alessandro Ciriani"
speaker_label: "Alessandro Ciriani (ECR)."
group: "ECR"
party: "FdL (ITA)"
country: "Italy"
language: "it"
words: 189
position: supports
topics: [Instrumentalisation of migration, Responsibility of the Spanish government, Regularisation of migrants, External border protection, Returns]
fallacies: [FALSE_CAUSE]
---

Speaker: [[Alessandro Ciriani]] · Group: [[ECR]] · Party: [[FdL (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 252 Alessandro Ciriani

> Alessandro Ciriani (ECR).

## Text

Signor Presidente, onorevoli colleghi, che l'immigrazione possa essere utilizzata come strumento di destabilizzazione è ovvio. Ma non è certo Ceuta ad avercelo insegnato: lo denunciamo da anni mentre venivamo accusati di alimentare paura.

Un attacco alla nostra frontiera è un attacco all'Europa e la risposta deve essere unita, forte, coesa. Attenzione però a ridurre quanto accaduto soltanto a una possibile operazione di influenza esterna, perché così si finirebbe per assolvere il governo Sanchez da responsabilità che invece sono enormi.

Le regolarizzazioni di massa hanno alimentato un evidente effetto richiamo. Gli allarmi sono stati sottovalutati e la crisi è stata gestita in modo maldestro e minimizzata, dichiarando l'emergenza soltanto quando non era più possibile negarla.

Oggi la sinistra scopre improvvisamente che l'immigrazione non è sempre una risorsa, perché senza regole, senza la capacità di decidere chi può entrare e chi invece non ne ha diritto, senza frontiere protette e, soprattutto, senza strumenti che rendano i rimpatri effettivi e rapidi, crisi come quella di Ceuta si ripeterebbero e l'Europa continuerebbe a subirle. Con buona pace di chi in quest'Aula indicava la strategia Sanchez che oggi frana sotto il peso della realtà.

## Summary
Alessandro Ciriani says it is obvious that migration can be used to destabilise, something his side has denounced for years, and that the response must be united. He warns against blaming only external influence, which would absolve the Sánchez government: mass regularisations created a pull factor and the crisis was mismanaged. Without protected borders and effective returns, such crises will recur.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He says that without protected borders and effective returns, such crises will recur.
- Quote: "senza frontiere protette e, soprattutto, senza strumenti che rendano i rimpatri effettivi e rapidi, crisi come quella di Ceuta si ripeterebbero" (translation by the agent: "without protected borders and, above all, without tools that make returns effective and rapid, crises like Ceuta's would recur")

## Entities
- [[Ceuta]]
- [[Pedro Sánchez|Sanchez]]

## Topics
- [[Instrumentalisation of migration]]
- [[Responsibility of the Spanish government]]
- [[Regularisation of migrants]]
- [[External border protection]]
- [[Returns]]

## Fallacies
- [[FALSE_CAUSE]] (borderline)
  - Quote: "Le regolarizzazioni di massa hanno alimentato un evidente effetto richiamo." (translation by the agent: "The mass regularisations fed an evident pull effect.")
  - Conclusion: The Spanish government bears responsibility for the crisis.
  - Defect: A causal link is asserted as evident without support.
