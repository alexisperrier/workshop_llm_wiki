---
type: "intervention"
kind: "answer"
speech_id: "2017094949360"
order: 240
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:07:09"
end_time: "14:07:48"
speaker: "Susanna Ceccardi"
speaker_label: "Susanna Ceccardi (PfE), risposta a una domanda \"cartellino blu\"."
group: "PfE"
party: "L (ITA)"
country: "Italy"
language: "it"
words: 86
position: not_stated
topics: [Sovereignty of Ceuta and Melilla]
fallacies: [STRAW_MAN]
---

Speaker: [[Susanna Ceccardi]] · Group: [[PfE]] · Party: [[L (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 239 Abir Al-Sahlani (question)]]

# 2026-09-15 240 Susanna Ceccardi (answer)

> Susanna Ceccardi (PfE), risposta a una domanda "cartellino blu".

## Text

Guardi, io essendo di destra, sono ontologicamente inferiore culturalmente a voi di sinistra – l'ha detto anche un collega, Bonaccini, che noi siamo inferiori, non siamo preparati: l'AfD ha vinto perché sono tutti ignoranti, lo sappiamo, in Sassonia, questo è noto.

Però, anche se sono così ignorante, so dov'è Ceuta e so anche dov'è Lampedusa: Lampedusa e Pantelleria sono più vicini all'Africa che all'Italia. Allora dovremmo cedere Lampedusa? Cediamo Pantelleria, ma sì, cediamo anche Ceuta.

Ma visto che ci siamo, cediamo anche la Spagna e l'Italia!

## Summary
Answering Abir Al-Sahlani, Susanna Ceccardi says ironically that people on the right are called culturally inferior, citing Stefano Bonaccini and the AfD vote in Saxony, and that she knows where Ceuta and Lampedusa are; she asks whether Europe should then cede Lampedusa, Pantelleria, Ceuta, Spain and Italy.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The answer is about whether Ceuta belongs to Europe, not about border protection.
- Quote: "so dov'è Ceuta e so anche dov'è Lampedusa" (translation by the agent: "I know where Ceuta is and I also know where Lampedusa is")

## Entities
- [[Stefano Bonaccini|Bonaccini]]
- [[AfD (DEU)|AfD]]
- [[Saxony|Sassonia]]
- [[Ceuta]]
- [[Lampedusa]]
- [[Pantelleria]]
- [[Italy|Italia]]
- [[Spain|Spagna]]

## Topics
- [[Sovereignty of Ceuta and Melilla]]

## Fallacies
- [[STRAW_MAN]] (clear)
  - Quote: "Allora dovremmo cedere Lampedusa? Cediamo Pantelleria, ma sì, cediamo anche Ceuta." (translation by the agent: "So should we cede Lampedusa? Let's cede Pantelleria, yes, let's cede Ceuta too.")
  - Conclusion: The question about Ceuta's location is absurd.
  - Defect: A question about geography is turned into a proposal to cede territory, which the questioner never made, and that version is then ridiculed.
