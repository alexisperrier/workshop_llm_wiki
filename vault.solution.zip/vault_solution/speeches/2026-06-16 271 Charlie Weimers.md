---
type: "intervention"
kind: "speech"
speech_id: "2017081987269"
order: 271
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:32:11"
end_time: "14:33:44"
speaker: "Charlie Weimers"
speaker_label: "Charlie Weimers, on behalf of the ECR Group."
group: "ECR"
party: "SD (SWE)"
country: "Sweden"
on_behalf_of_group: "ECR"
language: "en"
words: 169
position: supports
topics: [Returns, Return hubs, Detention of migrants, Majorities in Parliament]
fallacies: [FALSE_DILEMMA, STRAW_MAN]
---

Speaker: [[Charlie Weimers]] · Group: [[ECR]] · Party: [[SD (SWE)]] · Country: [[Sweden]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 271 Charlie Weimers

> Charlie Weimers, on behalf of the ECR Group.

## Text

Mr President, colleagues, this House has only two blocks on migration: common sense pro-Europeans and the far left.

The far left never wanted a real return regulation. The far left wanted endless appeals and unused detention. The far left wanted to ban return hubs. The far left opposed unlimited entry bans for terrorists and criminals. In short, they fought to preserve a dysfunctional, paralysed system that returns almost no one.

Why does the far left fight so hard to keep criminals, rapists and Islamists roaming freely on our streets? Whether social democrat, green or communist, they are all far left on migration. And many liberals have joined them.

Yet common sense has prevailed. We delivered. It will now be possible to build big, beautiful return hubs in third countries. We can enforce unlimited entry bans, not just for serious criminals, but low-level criminals too, and detain criminals for as long as necessary.

Illegal migrants must understand: you will never make Europe your home. The era of deportations has begun.

## Summary
Charlie Weimers says the House has only two blocks on migration, common-sense pro-Europeans and the far left, and that the far left wanted endless appeals, no detention and a ban on return hubs. He says common sense prevailed: return hubs in third countries, unlimited entry bans and detention of criminals for as long as necessary, and that the era of deportations has begun.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He celebrates the regulation as a victory of common sense.
- Quote: "Yet common sense has prevailed. We delivered."

## Entities
None.

## Topics
- [[Returns]]
- [[Return hubs]]
- [[Detention of migrants]]
- [[Majorities in Parliament]]

## Fallacies
- [[FALSE_DILEMMA]] (clear)
  - Quote: "this House has only two blocks on migration: common sense pro-Europeans and the far left"
  - Conclusion: Opponents of the regulation are the far left.
  - Defect: Only two camps are presented as exhaustive, and the division is used to label all opponents.
- [[STRAW_MAN]] (clear)
  - Quote: "Why does the far left fight so hard to keep criminals, rapists and Islamists roaming freely on our streets?"
  - Conclusion: The opponents' objections to the regulation are illegitimate.
  - Defect: Opponents are credited with wanting criminals to roam free, a position they did not hold.
