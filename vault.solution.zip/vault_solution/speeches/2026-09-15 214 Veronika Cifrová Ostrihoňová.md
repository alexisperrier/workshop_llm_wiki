---
type: "intervention"
kind: "speech"
speech_id: "2017094943112"
order: 214
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:33:54"
end_time: "13:35:06"
speaker: "Veronika Cifrová Ostrihoňová"
speaker_label: "Veronika Cifrová Ostrihoňová, on behalf of the Renew Group."
group: "Renew"
party: "PS (SVK)"
country: "Slovakia"
on_behalf_of_group: "RENEW"
language: "en"
words: 174
position: mixed
topics: [Humanitarian situation and victims, Instrumentalisation of migration, Solidarity between Member States]
fallacies: []
---

Speaker: [[Veronika Cifrová Ostrihoňová]] · Group: [[Renew]] · Party: [[PS (SVK)]] · Country: [[Slovakia]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 214 Veronika Cifrová Ostrihoňová

> Veronika Cifrová Ostrihoňová, on behalf of the Renew Group.

## Text

Madam President, colleagues, sometimes we only need to look at our own families, at where our grandparents and parents come from, to realise what migration is and that it is a part of our lives.

Ceuta was a tragedy. More than 140 people died. So, my solidarity is also with the people of Ceuta, who faced fear, unprecedented situations and unimaginable scenes. However, turning migration into a political weapon does not bring about answers. It only brings more mess. Slogans cannot replace real, serious policy. We need sustained effort and we need fair and firm management of migration.

And here, I want to contribute by improving early warning and situational awareness. In Ceuta, we saw how an online spark provoked a devastating wildfire with devastating consequences. And we already have the tools. We have the Digital Services Act that we can use and I urge all of us to use it earlier and more effectively because the people of Ceuta deserve this, but we all deserve it. We cannot afford to be unprepared again.

## Summary
Veronika Cifrová Ostrihoňová recalls that migration is part of everyone's family history, expresses solidarity with Ceuta and its more than 140 dead, and says turning migration into a political weapon brings no answers. She calls for better early warning and situational awareness, using the Digital Services Act against the online spark that set off the crossing.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: mixed
- Justification: She asks for fair and firm migration management but puts early warning and the fight against online disinformation first, not border measures.
- Quote: "We have the Digital Services Act that we can use and I urge all of us to use it earlier and more effectively"

## Entities
- [[Ceuta]]
- [[Digital Services Act]]

## Topics
- [[Humanitarian situation and victims]]
- [[Instrumentalisation of migration]]
- [[Solidarity between Member States]]

## Fallacies
None.
