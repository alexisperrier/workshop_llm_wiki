---
type: "intervention"
kind: "speech"
speech_id: "2017094949414"
order: 268
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:39:06"
end_time: "14:40:11"
speaker: "Bartłomiej Sienkiewicz"
speaker_label: "Bartłomiej Sienkiewicz (PPE)."
group: "PPE"
party: "KO (POL)"
country: "Poland"
language: "pl"
words: 116
position: supports
topics: [Instrumentalisation of migration, External border protection, Humanitarian situation and victims]
fallacies: []
---

Speaker: [[Bartłomiej Sienkiewicz]] · Group: [[PPE]] · Party: [[KO (POL)]] · Country: [[Poland]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 268 Bartłomiej Sienkiewicz

> Bartłomiej Sienkiewicz (PPE).

## Text

Panie Przewodniczący! Szanowni Koledzy i Koleżanki! Cały nasz ład prawny w każdym demokratycznym państwie Europy zbudowany jest na indywidualnym traktowaniu człowieka. Ta logika została przeniesiona na system azylowy w skali globalnej. Ale gdy do Ceuty w 48 godzin wdziera się tłum 80 tysięcy ludzi, to już nie są pojedyncze przypadki. To jest masa, którą trzeba traktować jako całość.

Więc skończmy opowiadać o niezmiennym zakazie zawracania, o niezbywalnym prawie do azylu. Szturm w takiej skali jest fizycznie niemożliwy do opanowania na gruncie prawa napisanego z myślą o pojedynczym człowieku pukającym do naszych drzwi.

Otwórzmy oczy, zanim kolejne rządy państw ościennych Europy zechcą spróbować tego samego eksperymentu, bo inaczej zostanie nam zdziwienie, dlaczego populiści wygrywają wybory w Europie.

## Summary
Bartłomiej Sienkiewicz says Europe's legal order and asylum system rest on treating each person individually, but 80,000 people storming Ceuta in 48 hours are a mass that must be treated as a whole. He calls for ending talk of non-refoulement and the inalienable right to asylum in such cases, warning that otherwise neighbouring governments will repeat the experiment and populists will win elections.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He argues that a mass storming cannot be handled under individual asylum law and calls for a firmer response.
- Quote: "Szturm w takiej skali jest fizycznie niemożliwy do opanowania na gruncie prawa napisanego z myślą o pojedynczym człowieku pukającym do naszych drzwi." (translation by the agent: "An assault on this scale is physically impossible to control under a law written for a single person knocking at our door.")

## Entities
- [[Ceuta|Ceuty]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Humanitarian situation and victims]]

## Fallacies
None.
