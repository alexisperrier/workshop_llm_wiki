---
type: "intervention"
kind: "speech"
speech_id: "2017094949434"
order: 278
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:51:49"
end_time: "14:53:01"
speaker: "Sebastian Tynkkynen"
speaker_label: "Sebastian Tynkkynen (ECR)."
group: "ECR"
party: "Perus (FIN)"
country: "Finland"
language: "en"
words: 123
position: supports
topics: [Instrumentalisation of migration, External border protection, Returns, Humanitarian situation and victims]
fallacies: [STRAW_MAN, UNSUPPORTED_ASSERTION]
---

Speaker: [[Sebastian Tynkkynen]] · Group: [[ECR]] · Party: [[Perus (FIN)]] · Country: [[Finland]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 278 Sebastian Tynkkynen

> Sebastian Tynkkynen (ECR).

## Text

Mr President, when Muslims invaded Christian countries in the seventh century, they killed, raped and enslaved. That is how these countries became Islamic.

The modern version of invasion is taking place in Europe right now. The latest example, the Islamic conquest of Ceuta, was only the tip of the iceberg.

The Commissioner said that Spain had done a good job, and the EU had passed the test. Excuse me? Tens of thousands of illegal migrants conquer the EU’s external border and it is considered a successful migration policy in Brussels?

Still not all migrants have been returned, and sexual crimes have skyrocketed.

If the EU leadership is unable to protect our borders with legislation, there is a solution to this: we need walls.

## Summary
Sebastian Tynkkynen compares the events to the Muslim conquests of the seventh century and calls Ceuta an 'Islamic conquest', the tip of the iceberg. He rejects the Commissioner's view that the EU passed the test, says sexual crimes have skyrocketed and not all migrants have been returned, and says Europe needs walls.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He says Europe needs walls.
- Quote: "If the EU leadership is unable to protect our borders with legislation, there is a solution to this: we need walls."

## Entities
- [[Ceuta]]
- [[Spain]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Returns]]
- [[Humanitarian situation and victims]]

## Fallacies
- [[STRAW_MAN]] (borderline)
  - Quote: "Tens of thousands of illegal migrants conquer the EU’s external border and it is considered a successful migration policy in Brussels?"
  - Conclusion: The EU's response to Ceuta is a failure.
  - Defect: The Commissioner's claim that the Schengen area's integrity was preserved is recast as calling the crossing a success, and that version is mocked.
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "The modern version of invasion is taking place in Europe right now."
  - Conclusion: Ceuta is part of an Islamic conquest of Europe.
  - Defect: A sweeping claim is stated without support.
