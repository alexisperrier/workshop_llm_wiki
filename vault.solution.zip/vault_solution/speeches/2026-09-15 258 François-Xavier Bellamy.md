---
type: "intervention"
kind: "speech"
speech_id: "2017094949395"
order: 258
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:28:24"
end_time: "14:29:43"
speaker: "François-Xavier Bellamy"
speaker_label: "François-Xavier Bellamy (PPE)."
group: "PPE"
party: "Les Républicains (FRA)"
country: "France"
language: "fr"
words: 224
position: supports
topics: [Humanitarian situation and victims, External border protection, Regularisation of migrants, Responsibility of the Spanish government, Migrant smuggling, Returns]
fallacies: [FALSE_CAUSE, STRAW_MAN]
---

Speaker: [[François-Xavier Bellamy]] · Group: [[PPE]] · Party: [[Les Républicains (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 258 François-Xavier Bellamy

> François-Xavier Bellamy (PPE).

## Text

Monsieur le Président, Ceuta est devenue une preuve par la souffrance de la catastrophe existentielle que représente l'immigration illégale. Plus de 140 morts, des centaines de victimes de violences dans la population de Ceuta. Un collègue nous disait ici, il faut défendre non pas des murs, mais défendre la dignité humaine. Qui ne voit aujourd'hui que quand on ne défend pas ses frontières, ce sont des vies qu'on détruit?

Mes chers collègues, je crois que cela ne vient pas de nulle part. Pedro Sánchez avait promis un grand plan de régularisation; le 30 juin, il annonce que 1 175 000 personnes ont déposé un dossier après être rentrées ou restées illégalement sur le sol européen. Le 30 juillet, 70 000 personnes rentrent à Ceuta et asphyxient la vie de toute la ville et de ses habitants.

Chers amis, nous voyons bien l'impasse dans laquelle nous a plongé l'impuissance européenne. Celui qui dit qu'il veut récompenser l'immigration illégale donne le pouvoir aux réseaux de passeurs, à ces mafias criminelles. Il est temps d'y mettre un terme. C'est ce que nous ferons avec le règlement retour qui s'appliquera dans quelques semaines seulement. Seuls Pedro Sánchez et Emmanuel Macron se sont opposés à son application. L'Europe qu'ils proposent, c'est l'Europe du passé; celle que nous construisons ensemble protégera la sécurité de tous les citoyens du continent européen.

## Summary
François-Xavier Bellamy says Ceuta proves the existential catastrophe of illegal immigration and that failing to defend borders destroys lives. He links Pedro Sánchez's regularisation plan, with 1,175,000 applications announced on 30 June, to the entry of 70,000 people into Ceuta on 30 July, says rewarding illegal immigration empowers smugglers, and presents the Return Regulation, opposed only by Sánchez and Macron, as the answer.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He says not defending borders destroys lives and presents returns as the answer.
- Quote: "quand on ne défend pas ses frontières, ce sont des vies qu'on détruit" (translation by the agent: "when you do not defend your borders, it is lives you destroy")

## Entities
- [[Ceuta]]
- [[Pedro Sánchez]]
- [[Return Regulation|règlement retour]]
- [[Emmanuel Macron]]

## Topics
- [[Humanitarian situation and victims]]
- [[External border protection]]
- [[Regularisation of migrants]]
- [[Responsibility of the Spanish government]]
- [[Migrant smuggling]]
- [[Returns]]

## Fallacies
- [[FALSE_CAUSE]] (clear)
  - Quote: "Pedro Sánchez avait promis un grand plan de régularisation; le 30 juin, il annonce que 1 175 000 personnes ont déposé un dossier après être rentrées ou restées illégalement sur le sol européen. Le 30 juillet, 70 000 personnes rentrent à Ceuta" (translation by the agent: "Pedro Sánchez had promised a big regularisation plan; on 30 June he announces that 1,175,000 people have applied after entering or staying illegally on European soil. On 30 July, 70,000 people enter Ceuta")
  - Conclusion: The regularisation caused the crossing into Ceuta.
  - Defect: The causal link rests only on the sequence of two dates.
- [[STRAW_MAN]] (borderline)
  - Quote: "Un collègue nous disait ici, il faut défendre non pas des murs, mais défendre la dignité humaine. Qui ne voit aujourd'hui que quand on ne défend pas ses frontières, ce sont des vies qu'on détruit?" (translation by the agent: "A colleague told us here that we must defend not walls but human dignity. Who does not see today that when you do not defend your borders, it is lives you destroy?")
  - Conclusion: Borders must be defended.
  - Defect: A colleague's point about defending dignity rather than a fence is recast as a refusal to defend borders, then rebutted.
