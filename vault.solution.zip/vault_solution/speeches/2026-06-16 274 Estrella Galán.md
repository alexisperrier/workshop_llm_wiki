---
type: "intervention"
kind: "speech"
speech_id: "2017081987276"
order: 274
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:36:32"
end_time: "14:39:02"
speaker: "Estrella Galán"
speaker_label: "Estrella Galán, en nombre del Grupo The Left."
group: "The Left"
party: "SMR (ESP)"
country: "Spain"
on_behalf_of_group: "THE_LEFT"
language: "es"
words: 362
position: opposes
topics: [Detention of migrants, Return hubs, Pact on Migration and Asylum, Humanitarian situation and victims, Majorities in Parliament]
fallacies: []
---

Speaker: [[Estrella Galán]] · Group: [[The Left]] · Party: [[SMR (ESP)]] · Country: [[Spain]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 274 Estrella Galán

> Estrella Galán, en nombre del Grupo The Left.

## Text

Señor presidente, señor comisario, este Parlamento está a punto de aprobar un Reglamento que permite encerrar a niñas y niños sin haber cometido ningún delito hasta treinta meses y, en algunos casos, de forma indefinida.

Lo llaman Reglamento sobre el Retorno, pero en realidad es el remate de una triple traición. La primera traición fue a los principios. El Pacto sobre Migración y Asilo nació para construir un programa de solidaridad común entre los Estados miembros, pero se ha convertido en el esqueleto perfecto sobre el que montar una maquinaria de deportaciones masivas. Chao a la solidaridad.

La segunda traición fue a los valores. Han pasado de hablar de acogida y de protección para hablar exclusivamente en este Parlamento y en la Comisión de detenciones y de expulsión. Han normalizado acuerdos con Gobiernos que no respetan los derechos humanos. Han externalizado responsabilidades y fronteras. Este Reglamento permite construir centros en terceros países fuera del territorio de la Unión que no respetan los derechos humanos, Guantánamos europeos donde deportar personas fuera de cualquier control judicial efectivo. Y están llegando al punto de sentarse con los talibanes para que formen parte de este sistema que se ha montado aquí, con los talibanes, que son terroristas. ¿Dónde quedan nuestros valores?

La tercera traición ha sido política. La derecha europea ha decidido asumir el marco ideológico de la ultraderecha. Nadie les votó para eso, señores del Partido Popular Europeo, nadie, estoy segura. Han sido secuestrados ideológicamente por la extrema derecha y este Reglamento es el resultado: un ICE europeo para identificar, para detener y para expulsar al estilo de Trump. Ya no es la extrema derecha la que se adapta a Europa, ahora es Europa la que se está adaptando a los ultras.

Lo que vamos a votar no es un Reglamento inocente. No lo es. Es un balance sobre qué queda del proyecto europeo. Porque Europa no nació para levantar una maquinaria de expulsión, ni para distinguir entre qué personas merecen derechos y cuáles pueden ser desechadas. Numerosas instituciones, incluida la ONU, han cuestionado esta norma y, por eso, lo decimos alto y claro: no vamos a parar hasta derogar este Reglamento que es cruel.

## Summary
Estrella Galán says the regulation allows children to be detained for up to 30 months, sometimes indefinitely, and calls it a triple betrayal: of the Pact's solidarity principles, of values through deals with rights-violating governments and 'European Guantánamos', and politically, as the EPP adopts the far right's framework. She calls it a European ICE in Trump's style and vows to repeal it.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: opposes
- Justification: She calls the regulation cruel and vows to repeal it.
- Quote: "no vamos a parar hasta derogar este Reglamento que es cruel" (translation by the agent: "we will not stop until we repeal this Regulation, which is cruel")

## Entities
- [[Return Regulation|Reglamento sobre el Retorno]]
- [[Pact on Migration and Asylum|Pacto sobre Migración y Asilo]]
- [[European Commission|la Comisión]]
- [[Taliban|talibanes]]
- [[PPE|Partido Popular Europeo]]
- [[U.S. Immigration and Customs Enforcement|ICE]]
- [[Donald Trump|Trump]]
- [[United Nations|ONU]]

## Topics
- [[Detention of migrants]]
- [[Return hubs]]
- [[Pact on Migration and Asylum]]
- [[Humanitarian situation and victims]]
- [[Majorities in Parliament]]

## Fallacies
None.
