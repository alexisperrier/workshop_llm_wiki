---
type: "intervention"
kind: "written"
speech_id: "2017096449364"
order: 289
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
speaker: "Rihards Kols"
speaker_label: "Rihards Kols (ECR), in writing."
group: "ECR"
party: "TB-LNNK (LVA)"
country: "Latvia"
language: "en"
words: 185
position: supports
topics: [Instrumentalisation of migration, External border protection, Returns, Humanitarian situation and victims, Solidarity between Member States]
fallacies: []
---

Speaker: [[Rihards Kols]] · Group: [[ECR]] · Party: [[TB-LNNK (LVA)]] · Country: [[Latvia]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-09-15 289 Rihards Kols (written)

> Rihards Kols (ECR), in writing.

## Text

In under 48 hours in late July, over 50,000 people crossed from Morocco into Ceuta. That is not a migration wave. It is instrumentalisation - a hybrid attack using human beings as leverage against a Member State's border, the same playbook Belarus ran against Poland, Lithuania and Finland.The tragedy of July, including the loss of 141 lives at sea, must be met with both humanity and strategic clarity. Those who organise, facilitate or exploit mass irregular crossings bear responsibility for using vulnerable people as instruments of pressure.The response cannot be another round of declarations followed by institutional hesitation. Spain must use all available EU emergency assistance and operational support. Frontex must be reinforced, able to deploy rapidly and equipped to support Member States facing engineered pressure at the external border.At the same time, the EU needs functioning return and readmission arrangements for those with no right to remain, in full respect of international law. Solidarity cannot mean that some Member States secure the Union’s borders while others debate whether borders still matter.A border that can be politically breached is a security vulnerability for every European.

## Summary
In a written statement, Rihards Kols says over 50,000 crossings in 48 hours were instrumentalisation, the playbook Belarus used against Poland, Lithuania and Finland. He calls for EU emergency support to Spain, a reinforced and rapidly deployable Frontex, and functioning return and readmission arrangements in respect of international law.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He calls for a reinforced Frontex and functioning returns.
- Quote: "Frontex must be reinforced, able to deploy rapidly and equipped to support Member States facing engineered pressure at the external border."

## Entities
- [[Morocco]]
- [[Ceuta]]
- [[Belarus]]
- [[Poland]]
- [[Lithuania]]
- [[Finland]]
- [[Spain]]
- [[Frontex]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Returns]]
- [[Humanitarian situation and victims]]
- [[Solidarity between Member States]]

## Fallacies
None.
