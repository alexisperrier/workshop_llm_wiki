---
type: "intervention"
kind: "question"
speech_id: "2017094949351"
order: 235
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:02:22"
end_time: "14:03:08"
speaker: "András László"
speaker_label: "András László (PfE), kékkártyás kérdés."
group: "PfE"
party: "Fidesz-KDNP (HUN)"
country: "Hungary"
language: "hu"
words: 85
position: not_stated
topics: [Majorities in Parliament]
fallacies: []
---

Speaker: [[András László]] · Group: [[PfE]] · Party: [[Fidesz-KDNP (HUN)]] · Country: [[Hungary]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 234 Lena Düpont]]

# 2026-09-15 235 András László (question)

> András László (PfE), kékkártyás kérdés.

## Text

Nem tudom, hogy paródia vagy szarkazmus szólt e Önből, amikor arról beszélt, hogy mennyi mindent ért el az Európai Unió a migráció elleni küzdelemben. Szeretném mondani, hogy 2024-ben az Európai Néppárt vezette Bizottság európai néppártos migrációs biztosa volt az, aki megbüntette és büntetést kért Magyarországra azért, mert megállítjuk az illegális migránsokat. Tíz évig csináltuk ezt. A Néppárt és a nagykoalíció volt az, aki kritizálta Magyarországot, és továbbra is napi egymillió euró büntetést fizetünk emiatt. Egyetért azzal, hogy ezt azonnal, mielőbb vissza kell vonni Magyarország ellen?

## Summary
In a blue-card question to Lena Düpont, András László says the EPP-led Commission fined Hungary for stopping illegal migrants, which it still pays at one million euros a day, and asks whether she agrees the fine should be withdrawn.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about Hungary's fine, not about Ceuta.
- Quote: "továbbra is napi egymillió euró büntetést fizetünk emiatt" (translation by the agent: "we continue to pay a fine of one million euros a day because of this")

## Entities
- [[PPE|Európai Néppárt]]
- [[European Commission|Bizottság]]
- [[Hungary|Magyarországra]]

## Topics
- [[Majorities in Parliament]]

## Fallacies
None.
