---
type: "intervention"
kind: "answer"
speech_id: "2017094949399"
order: 260
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:30:37"
end_time: "14:31:05"
speaker: "François-Xavier Bellamy"
speaker_label: "François-Xavier Bellamy (PPE), réponse carton bleu."
group: "PPE"
party: "Les Républicains (FRA)"
country: "France"
language: "fr"
words: 90
position: not_stated
topics: [Regularisation of migrants, Sovereignty of Ceuta and Melilla]
fallacies: [UNSUPPORTED_ASSERTION]
---

Speaker: [[François-Xavier Bellamy]] · Group: [[PPE]] · Party: [[Les Républicains (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 259 Alvise Pérez (question)]]

# 2026-09-15 260 François-Xavier Bellamy (answer)

> François-Xavier Bellamy (PPE), réponse carton bleu.

## Text

Il n'y a qu'une seule réponse à apporter à cette stratégie: nous avons le devoir de protéger notre état de droit. Et l'état de droit, c'est le fait qu'on ne change pas la population par l'immigration illégale. Personne n'est dupe de la manœuvre qui est en train de se jouer. Si nous parlons d'immigration, nous parlons bien de sécurité, nous parlons bien de protection de l'identité de nos pays. Et nous devons le redire aujourd'hui avec tous les habitants de Ceuta: Ceuta es España, Ceuta es Europa, Ceuta se defiende.

## Summary
Answering Alvise Pérez, François-Xavier Bellamy says the rule of law means not changing the population through illegal immigration, that immigration is about security and national identity, and ends with 'Ceuta es España, Ceuta es Europa, Ceuta se defiende'.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The answer is about regularisation and identity, not the EU's border response.
- Quote: "nous avons le devoir de protéger notre état de droit" (translation by the agent: "we have the duty to protect our rule of law")

## Entities
- [[Ceuta]]
- [[Spain|España]]

## Topics
- [[Regularisation of migrants]]
- [[Sovereignty of Ceuta and Melilla]]

## Fallacies
- [[UNSUPPORTED_ASSERTION]] (borderline)
  - Quote: "l'état de droit, c'est le fait qu'on ne change pas la population par l'immigration illégale" (translation by the agent: "the rule of law means that you do not change the population through illegal immigration")
  - Conclusion: The regularisation is an attack on the rule of law.
  - Defect: The claim that the population is being changed is stated without support.
