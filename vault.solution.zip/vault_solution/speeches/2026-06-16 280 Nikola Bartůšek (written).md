---
type: "intervention"
kind: "written"
speech_id: "2017083047159"
order: 280
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
speaker: "Nikola Bartůšek"
speaker_label: "Nikola Bartůšek (NI), in writing."
group: "NI"
country: "Czechia"
language: "en"
words: 174
position: supports
topics: [Returns]
fallacies: []
---

Speaker: [[Nikola Bartůšek]] · Group: [[NI]] · Country: [[Czechia]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-06-16 280 Nikola Bartůšek (written)

> Nikola Bartůšek (NI), in writing.

## Text

For a safer and more secure Europe, a functioning asylum and migration system is a must.Every year, hundreds of thousands of people receive a final decision stating that they have no legal right to remain in the European Union. Yet a large proportion never leave. This is not only a failure of enforcement, it is a failure to protect our citizens.For too long, Europe has sent the wrong message, that even after a final negative decision, it is often possible to stay indefinitely.Illegally.That situation has fuelled illegal migration, encouraged abuse of the system, and undermined public confidence in our ability to control our borders.This regulation is a necessary correction.Let us be clear. A sovereign Europe must be able to decide who has the right to stay on its territory and who does not.Respect for fundamental rights and respect for the rule of law are not opposites. They go hand in hand.Our citizens expect us to protect Europe's borders, uphold our laws, and ensure that migration is managed, not ignored. It is time to deliver.

## Summary
In a written statement, Nikola Bartůšek says many people with a final negative decision never leave, which has fuelled illegal migration and abuse of the system. He calls the regulation a necessary correction, says a sovereign Europe must decide who stays, and that fundamental rights and the rule of law go hand in hand.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He calls the regulation a necessary correction.
- Quote: "This regulation is a necessary correction."

## Entities
None.

## Topics
- [[Returns]]

## Fallacies
None.
