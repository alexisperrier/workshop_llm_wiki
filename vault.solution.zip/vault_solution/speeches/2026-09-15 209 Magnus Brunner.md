---
type: "intervention"
kind: "speech"
speech_id: "2017094943095"
order: 209
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:14:17"
end_time: "13:24:19"
speaker: "Magnus Brunner"
speaker_label: "Magnus Brunner, Member of the Commission."
language: "en"
words: 1168
position: supports
topics: [Instrumentalisation of migration, External border protection, Returns, Migrant smuggling, Pact on Migration and Asylum, EU-Morocco relations, Humanitarian situation and victims, Schengen and internal border controls, Solidarity between Member States]
fallacies: []
---

Speaker: [[Magnus Brunner]] · Role: Member of the Commission
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 209 Magnus Brunner

> Magnus Brunner, Member of the Commission.

## Text

Madam President, Minister, Honourable Members, the Spanish city of Ceuta has just over 80 000 inhabitants. In the last two days of July, almost the same amount of people entered illegally from the other side of the border. This was unprecedented, of course. It severely tested the resilience of the people of Ceuta, and I want to assure them of our respect and our sympathy for the challenges they are facing. I also want to express my deepest condolences to the families and friends of those who lost their lives in the attempt to get to Ceuta. This tragic loss of life confirms again what we actually already know – smugglers kill people, and we must do everything we can to stop them.

This was a stress test for our Union, for our system and for our resilience. But most of the people who entered Ceuta illegally went back to Morocco within a matter of hours, and – this is important – nobody entered the Schengen area. Its integrity was preserved. This was the result of the action taken by the Spanish authorities and also the cooperation with Morocco. However, there are many more challenges which are still ahead of us.

Firstly, thousands remain in Ceuta, including more than 2 000 unaccompanied minors. This brings high pressure and also public order challenges on a territory of less than 20 km². A solution must therefore be found as a matter of urgency. For this, our priority is clear: all those who entered illegally and have no right to stay must swiftly return to Morocco. Morocco has made the commitment, which we of course very much welcome, to take back all migrants that arrived illegally to Ceuta. Secondly, we need to step up our efforts to prevent this from happening again.

Before setting out the necessary next steps, let us also recall what our new approach to migration policy has actually achieved already. Building on the Pact on Migration and Asylum, we have opened a new chapter with fair but also firm rules on the screening of people arriving illegally, the border procedure, new return rules, safe countries reforms and other things. We also have an assertive migration diplomacy and stronger external borders. So altogether we have put our European house in order, and the results actually show that it works.

There is a significant decrease in illegal arrivals and asylum applications across the European Union. In the last two years, illegal migration has decreased by more than 50 %. This year alone, we are seeing a further reduction by more than another third already. As a result of all that, asylum applications are following the same trend. In 2025, they were down by 20 %. There are a lot of examples across the European Union where the numbers are at a historic low. Our returns system is of course working much better. Effective return rates are now close to 30 %. This is not enough, but we are working on that and it's definitely getting better. This means that last year around 30 000 more people returned than the year before.

Europe has made significant progress in addressing illegal migration and in getting control back, but the events and the images from Ceuta show that we must double down on our efforts. Both the smugglers and illegal migrants must understand that our Union will step up to defend itself. Most of all, our citizens must be reassured that things are under control, so restoring control and providing support to Spain have been key objectives from day one of the crisis. I have been in close contact with Spain since the very first day, and tomorrow I will be in Madrid again for discussions with ministers Torres, Grande-Marlaska and Saiz. I also had a very useful exchange with the Mayor-President of Ceuta, Juan Jesús Vivas, last week, and we have now set up a coordination mechanism with Spanish authorities and EU agencies for regular exchanges to assist Spain there as well.

EU support has also become very concrete. Last week, after Spain's request in late August, the Commission granted EUR 114.7 million in emergency assistance. This will reinforce border surveillance and protection, border security infrastructure, as well as the deployment of additional staff and equipment. It will also serve to set up facilities for screening, assistance for unaccompanied minors in the city and to support returns from Ceuta.

Furthermore, Frontex, Europol and the Agency For Asylum are also going to increase their operational support and presence, as requested by Spain in late August. Of course, we will not and cannot stop here. We will continue insisting on the full implementation of the Pact and, in addition, we will work on key areas set out by President von der Leyen. First of all, to prevent illegal migration, migration diplomacy is key. There, I think we will reinforce our comprehensive approach using incentives, using leverages also including funding, including trade. Visa policy is very important there. And when it comes to Morocco, we are committed to continuing to work together on the returns of those remaining in Ceuta.

More efforts, of course, have to be made when it comes to illegal departures, when it comes to fighting smuggling, ensuring effective returns and readmission. In addition, we have been actively coordinating with major online platforms to combat disinformation in relation to the events in Ceuta.

The second important point is that we will reinforce the external borders with a stronger Frontex to make it more agile and faster in anticipating and responding to events. A third point, we will improve early warning and situational awareness with the better monitoring of what happens online, especially because the mobilisation happens very fast. A strengthened Frontex will need to work on this too.

The fourth point, we will continue fighting against smugglers. We made a lot of progress already with the Global Alliance to Counter Migrant Smuggling, and now it is time to agree on new EU rules. So I call on you all to speed up the work on the anti-smuggling directive tabled already three years ago. It's really time to get that done. The last point, we will step up on returns. This is important with the new Return Regulation, which will be in force soon. There is also the revision of the Frontex mandate will be key.

Let me be clear. Ceuta's borders and every Member States borders are European borders. The Commission is definitely ready to do everything possible to support Member States in protecting those borders. We need to learn our lessons from Syria to close gaps, control our borders, preserve the Schengen area. Our work needs to continue to implement the Pact rules. Cooperation with our neighbours is also important, as is always defending our interests.

We will also reinforce our toolbox so that we can deal with similar events more effectively and swiftly, and there I count on the Parliament's support for the work ahead of us. Thank you.

## Summary
Commissioner Brunner says almost 80,000 people entered Ceuta illegally at the end of July, that most went back to Morocco within hours and that nobody entered the Schengen area; thousands remain, including over 2,000 unaccompanied minors, who must return to Morocco. He presents falling arrivals as proof that the Pact works, announces EUR 114.7 million in emergency aid, and sets out next steps: migration diplomacy, a stronger Frontex, early warning, the anti-smuggling directive and the Return Regulation.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He calls for reinforcing the external borders with a stronger Frontex, alongside returns, migration diplomacy and the fight against smugglers.
- Quote: "we will reinforce the external borders with a stronger Frontex to make it more agile and faster in anticipating and responding to events"

## Entities
- [[Ceuta]]
- [[Morocco]]
- [[Schengen Area|Schengen area]]
- [[Pact on Migration and Asylum]]
- [[Spain]]
- [[Madrid]]
- [[Ángel Víctor Torres|Torres]]
- [[Fernando Grande-Marlaska|Grande-Marlaska]]
- [[Elma Saiz|Saiz]]
- [[Juan Jesús Vivas]]
- [[European Commission|the Commission]]
- [[Frontex]]
- [[Europol]]
- [[European Union Agency for Asylum|Agency For Asylum]]
- [[Ursula von der Leyen|President von der Leyen]]
- [[Global Alliance to Counter Migrant Smuggling]]
- [[Anti-smuggling directive|anti-smuggling directive]]
- [[Return Regulation]]
- [[Syria]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Returns]]
- [[Migrant smuggling]]
- [[Pact on Migration and Asylum]]
- [[EU-Morocco relations]]
- [[Humanitarian situation and victims]]
- [[Schengen and internal border controls]]
- [[Solidarity between Member States]]

## Fallacies
None.
