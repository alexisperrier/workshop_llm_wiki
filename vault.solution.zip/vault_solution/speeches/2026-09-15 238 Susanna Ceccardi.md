---
type: "intervention"
kind: "speech"
speech_id: "2017094949357"
order: 238
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:05:20"
end_time: "14:06:30"
speaker: "Susanna Ceccardi"
speaker_label: "Susanna Ceccardi (PfE)."
group: "PfE"
party: "L (ITA)"
country: "Italy"
language: "it"
words: 156
position: supports
topics: [Instrumentalisation of migration, EU-Morocco relations, External border protection]
fallacies: [FALSE_CAUSE, UNSUPPORTED_ASSERTION]
---

Speaker: [[Susanna Ceccardi]] · Group: [[PfE]] · Party: [[L (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 238 Susanna Ceccardi

> Susanna Ceccardi (PfE).

## Text

Signor Presidente, onorevoli colleghi, Ceuta è stata invasa; l'Europa è stata invasa. Come pensate che fossero le invasioni islamiche del passato? Assediavano le città del Mediterraneo e pian piano cercavano l'espansione: hanno attaccato Ceuta con migliaia di uomini, hanno attaccato l'Europa. Questa non è immigrazione: questa è invasione e come tale va combattuta.

Re Mohammed VI, prima dell'invasione a Ceuta del 15 agosto, ha liberato migliaia di criminali dalle carceri marocchine. Dove pensate che siano finiti quei criminali? Dove pensate che siano finiti tutti i criminali che sono scappati anche dalle carceri tunisine dopo le primavere arabe?

Sono finiti qua, in Europa: basta guardare un po fuori, nelle nostre città e nelle nostre periferie. Da dove sono venuti questi criminali che stuprano, uccidono, rapinano e mettono veramente sotto assedio le nostre città?

Lo diceva Oriana Fallaci, una grande scrittrice italiana che è morta vent'anni fa, il 15 settembre: "Wake up Occidente! Sveglia Occidente, perché sarà troppo...

## Summary
Susanna Ceccardi says Ceuta and Europe have been invaded and compares the events to past Islamic invasions of the Mediterranean. She claims King Mohammed VI released thousands of criminals from Moroccan prisons before the crossing and links them to crime in European cities, quoting Oriana Fallaci.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She calls for the 'invasion' to be fought.
- Quote: "Questa non è immigrazione: questa è invasione e come tale va combattuta." (translation by the agent: "This is not immigration: this is invasion and as such it must be fought.")

## Entities
- [[Ceuta]]
- [[Mohammed VI|Re Mohammed VI]]
- [[Arab Spring|primavere arabe]]
- [[Oriana Fallaci]]

## Topics
- [[Instrumentalisation of migration]]
- [[EU-Morocco relations]]
- [[External border protection]]

## Fallacies
- [[FALSE_CAUSE]] (borderline)
  - Quote: "Sono finiti qua, in Europa: basta guardare un po fuori, nelle nostre città e nelle nostre periferie." (translation by the agent: "They ended up here, in Europe: just look outside a little, in our cities and our suburbs.")
  - Conclusion: Crime in European cities comes from the crossing and from released prisoners.
  - Defect: A causal link between released prisoners and crime in Europe is suggested through rhetorical questions, without support.
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "Re Mohammed VI, prima dell'invasione a Ceuta del 15 agosto, ha liberato migliaia di criminali dalle carceri marocchine." (translation by the agent: "King Mohammed VI, before the invasion of Ceuta on 15 August, released thousands of criminals from Moroccan prisons.")
  - Conclusion: The crossing was a planned attack.
  - Defect: A strong factual claim is stated without a source.
