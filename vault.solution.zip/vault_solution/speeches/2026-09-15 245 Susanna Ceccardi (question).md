---
type: "intervention"
kind: "question"
speech_id: "2017094949370"
order: 245
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:13:33"
end_time: "14:14:15"
speaker: "Susanna Ceccardi"
speaker_label: "Susanna Ceccardi (PfE), domanda \"cartellino blu\"."
group: "PfE"
party: "L (ITA)"
country: "Italy"
language: "it"
words: 102
position: not_stated
topics: [Sovereignty of Ceuta and Melilla]
fallacies: [AD_HOMINEM]
---

Speaker: [[Susanna Ceccardi]] · Group: [[PfE]] · Party: [[L (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 244 Ilaria Salis]]

# 2026-09-15 245 Susanna Ceccardi (question)

> Susanna Ceccardi (PfE), domanda "cartellino blu".

## Text

Che bello! Non mi aspettavo che avrebbe accettato questa domanda "cartellino blu". Sono proprio contenta: insomma, quindi ci dice che il colonialismo ha occupato abusivamente Ceuta.

Insomma, lei di occupazioni abusive se ne intende parecchio, e però, non credo proprio che sia un'occupazione abusiva: Ceuta è Europa da centinaia di anni, così come lo è la Sicilia, così come è la Spagna, la Spagna moresca, che ha ricacciato gli islamici che avevano conquistato, tra il Settecento e l'Ottocento, quelle terre.

Allora, la storia, cara Ilaria Salis, non la fa lei. La storia è scritta: quella è Europa e ce la dobbiamo riprendere!

## Summary
In a blue-card question to Ilaria Salis, Susanna Ceccardi rejects the claim that Ceuta is a colonial occupation, says Ceuta has been European for centuries like Sicily and Spain, and that Europe must take it back.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The exchange is about Ceuta's history, not about border protection.
- Quote: "Ceuta è Europa da centinaia di anni, così come lo è la Sicilia" (translation by the agent: "Ceuta has been Europe for hundreds of years, as has Sicily")

## Entities
- [[Ceuta]]
- [[Sicily|Sicilia]]
- [[Spain|Spagna]]
- [[Ilaria Salis]]

## Topics
- [[Sovereignty of Ceuta and Melilla]]

## Fallacies
- [[AD_HOMINEM]] (clear)
  - Quote: "Insomma, lei di occupazioni abusive se ne intende parecchio" (translation by the agent: "Well, you know a lot about illegal occupations")
  - Conclusion: Salis's claim that Ceuta is a colonial remnant is wrong.
  - Defect: The claim is answered with an allusion to the speaker's personal record instead of an argument about Ceuta.
