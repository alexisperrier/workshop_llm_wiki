---
type: "intervention"
kind: "answer"
speech_id: "2017094949353"
order: 236
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:03:10"
end_time: "14:03:46"
speaker: "Lena Düpont"
speaker_label: "Lena Düpont (PPE), Antwort auf eine Frage nach dem Verfahren der „blauen Karte“."
group: "PPE"
party: "CDU (DEU)"
country: "Germany"
language: "de"
words: 79
position: not_stated
topics: [Majorities in Parliament]
fallacies: [AD_HOMINEM]
---

Speaker: [[Lena Düpont]] · Group: [[PPE]] · Party: [[CDU (DEU)]] · Country: [[Germany]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 235 András László (question)]]

# 2026-09-15 236 Lena Düpont (answer)

> Lena Düpont (PPE), Antwort auf eine Frage nach dem Verfahren der „blauen Karte“.

## Text

Erlauben Sie, dass ich auf Deutsch antworte? Erstens: Ungarn ist für sehr viele Dinge in den letzten Jahren zu Recht kritisiert worden. Alle Berichte der Europäischen Union im Bereich Rechtsstaatlichkeit haben eine eindeutige, eine klare Sprache gesprochen. Zweitens: Wir könnten auf einer anderen Ebene möglicherweise diskutieren, nicht zu einer Einigung kommen, aber möglicherweise diskutieren, wenn nicht Sie und Ihre ehemalige Fraktion genau diejenigen gewesen wären, die jegliche Lösung bei einer gemeinsamen europäischen Asyl- und Migrationspolitik von vornherein unterwandert hätten.

## Summary
Answering András László in German, Lena Düpont says Hungary has rightly been criticised in the EU's rule-of-law reports, and that his former group undermined every common European solution on asylum and migration from the start.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The answer is about Hungary, not about the EU's response to Ceuta.
- Quote: "Ungarn ist für sehr viele Dinge in den letzten Jahren zu Recht kritisiert worden." (translation by the agent: "Hungary has rightly been criticised for very many things in recent years.")

## Entities
- [[Hungary|Ungarn]]

## Topics
- [[Majorities in Parliament]]

## Fallacies
- [[AD_HOMINEM]] (borderline)
  - Quote: "wenn nicht Sie und Ihre ehemalige Fraktion genau diejenigen gewesen wären, die jegliche Lösung bei einer gemeinsamen europäischen Asyl- und Migrationspolitik von vornherein unterwandert hätten" (translation by the agent: "if you and your former group had not been precisely the ones who undermined any solution on a common European asylum and migration policy from the start")
  - Conclusion: The questioner's request to withdraw Hungary's fine does not deserve discussion.
  - Defect: The request is set aside by pointing to the questioner's group's past conduct; the rule-of-law argument given first keeps it borderline.
