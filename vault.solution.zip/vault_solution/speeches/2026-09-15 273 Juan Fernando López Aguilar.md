---
type: "intervention"
kind: "speech"
speech_id: "2017094949424"
order: 273
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:45:25"
end_time: "14:46:42"
speaker: "Juan Fernando López Aguilar"
speaker_label: "Juan Fernando López Aguilar (S&D)."
group: "S&D"
party: "PSOE (ESP)"
country: "Spain"
language: "es"
words: 214
position: opposes
topics: [Solidarity between Member States, Pact on Migration and Asylum, Humanitarian situation and victims, Schengen and internal border controls, Responsibility of the Spanish government]
fallacies: []
---

Speaker: [[Juan Fernando López Aguilar]] · Group: [[S&D]] · Party: [[PSOE (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 273 Juan Fernando López Aguilar

> Juan Fernando López Aguilar (S&D).

## Text

Señor presidente, señor comisario Brunner, ya lo ha escuchado usted, España ha sido solidaria con cada frontera exterior de la Unión bajo presión, desde los bálticos hasta Lampedusa, y merece la misma solidaridad y unidad, no menos, ante la crisis de Ceuta.

En ella las autoridades españolas están respondiendo respetando la Constitución española, la Ley de Extranjería, las leyes europeas del Pacto sobre Migración y Asilo, con todos sus procedimientos y garantías, pero también el Derecho internacional humanitario, que obliga a rescatar vidas, y lamenta, por tanto, y deplora las 140 víctimas mortales, además de proteger a las personas más vulnerables: menores no acompañados.

El malestar de la ciudadanía ceutí es muy entendible. No lo es en absoluto la explotación del odio que incita a la caza de migrantes uno a uno. Por tanto, no caben soluciones ilegales —como suspender las reglas del Código de Fronteras Schengen unilateralmente o no digamos intentar imponérselas a otro país—, ni tampoco directamente delictivas, como la lesión de los derechos humanos.

Si quieren ayudar a Ceuta, aténganse a la ley que permite la redistribución de las menores no acompañadas en las comunidades autónomas gobernadas por el Partido Popular y VOX, porque eso es cumplir la ley y eso es ser parte de la solución y no del problema.

## Summary
Juan Fernando López Aguilar says Spain has shown solidarity with every external border under pressure and deserves the same. Spanish authorities are applying the Constitution, the Aliens Act, the Pact and international humanitarian law, protecting unaccompanied minors; he rejects illegal solutions such as unilaterally suspending the Schengen Borders Code and asks regions governed by the PP and VOX to take in minors.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: He defends the legal response and solidarity and rejects illegal border measures.
- Quote: "no caben soluciones ilegales —como suspender las reglas del Código de Fronteras Schengen unilateralmente" (translation by the agent: "there is no room for illegal solutions, such as unilaterally suspending the rules of the Schengen Borders Code")

## Entities
- [[Magnus Brunner|señor comisario Brunner]]
- [[Spain|España]]
- [[Lampedusa]]
- [[Ceuta]]
- [[Constitution of Spain|Constitución española]]
- [[Spanish Aliens Act|Ley de Extranjería]]
- [[Pact on Migration and Asylum|Pacto sobre Migración y Asilo]]
- [[Schengen Borders Code|Código de Fronteras Schengen]]
- [[PP (ESP)|Partido Popular]]
- [[VOX (ESP)|VOX]]

## Topics
- [[Solidarity between Member States]]
- [[Pact on Migration and Asylum]]
- [[Humanitarian situation and victims]]
- [[Schengen and internal border controls]]
- [[Responsibility of the Spanish government]]

## Fallacies
None.
