---
type: "intervention"
kind: "speech"
speech_id: "2017094943123"
order: 219
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:42:44"
end_time: "13:44:36"
speaker: "Dolors Montserrat"
speaker_label: "Dolors Montserrat (PPE)."
group: "PPE"
party: "PP (ESP)"
country: "Spain"
language: "es"
words: 292
position: supports
topics: [Responsibility of the Spanish government, Instrumentalisation of migration, Sovereignty of Ceuta and Melilla, External border protection, Returns, Pact on Migration and Asylum, EU-Morocco relations, Humanitarian situation and victims]
fallacies: []
---

Speaker: [[Dolors Montserrat]] · Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 219 Dolors Montserrat

> Dolors Montserrat (PPE).

## Text

Señora presidenta, señorías, aparquen la demagogia y las excusas. Hoy y siempre, debemos estar con los ceutíes. Han sufrido muchísimo.

Los hechos son irrebatibles: más de cien fallecidos, más de ochenta mil irregulares invadiendo Ceuta violando una frontera europea. Sí, una guerra híbrida de manual.

Pedro Sánchez lo sabía: la policía alertó, los servicios de inteligencia enviaron informes y el presidente Juan Vivas llamó durante días al Gobierno hasta que le pidieron por favor que no molestase más y no llamase más.

Repito: Sánchez lo sabía y se fue de vacaciones veinticinco días. Se trata de una irresponsabilidad que le convierte en cómplice y culpable. Cuarenta y ocho días después, la crisis no se ha resuelto. Los ceutíes siguen pagando el fracaso de Sánchez en sus propias carnes: más de doce mil personas siguen vagando por las calles, hay enfrentamientos diarios con la policía, abusos sexuales, niños que no pueden asistir al colegio, mujeres que no salen solas a la calle.

La respuesta de Sánchez: silencio. La nuestra: recuperar la normalidad ya, proteger nuestras fronteras y retornar a todos los irregulares —adultos y menores—.

Señorías, Ceuta no es la última frontera de Europa. Es la primera. Y señora Iratxe: sí, el pacto migratorio —la mejor herramienta para defender nuestra soberanía, nuestra integridad territorial y, sobre todo, los retornos—.

Marruecos es responsable también por acción o por omisión, y como socio europeo debe responder con respeto, legalidad y reciprocidad con la Unión Europea.

Pero no nos engañemos. La seguridad en la frontera sur europea no empieza en Rabat, empieza en Ceuta, que siempre será española y europea. Por eso hoy decimos bien alto Ceuta no se abandona, no se negocia, no se vende. Y Ceuta se defiende siempre: desde Europa y desde España.

## Summary
Dolors Montserrat calls the events a textbook hybrid war and says Pedro Sánchez knew, as police, intelligence services and Juan Vivas had warned, but went on holiday, which makes him complicit. She lists the consequences for the people of Ceuta, calls for protecting borders and returning all irregular migrants, adults and minors, defends the Pact as the best tool, and says Morocco is also responsible.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She calls for protecting the borders and returning all irregular migrants.
- Quote: "recuperar la normalidad ya, proteger nuestras fronteras y retornar a todos los irregulares —adultos y menores—" (translation by the agent: "restore normality now, protect our borders and return all irregular migrants, adults and minors")

## Entities
- [[Ceuta]]
- [[Pedro Sánchez]]
- [[Juan Jesús Vivas|Juan Vivas]]
- [[Government of Spain|Gobierno]]
- [[Iratxe García Pérez|señora Iratxe]]
- [[Pact on Migration and Asylum|pacto migratorio]]
- [[Morocco|Marruecos]]
- [[Rabat]]

## Topics
- [[Responsibility of the Spanish government]]
- [[Instrumentalisation of migration]]
- [[Sovereignty of Ceuta and Melilla]]
- [[External border protection]]
- [[Returns]]
- [[Pact on Migration and Asylum]]
- [[EU-Morocco relations]]
- [[Humanitarian situation and victims]]

## Fallacies
None.
