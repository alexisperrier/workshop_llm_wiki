---
type: "intervention"
kind: "answer"
speech_id: "2017094949389"
order: 255
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:25:02"
end_time: "14:25:42"
speaker: "Malik Azmani"
speaker_label: "Malik Azmani (Renew), “blauwe kaart”-antwoord."
group: "Renew"
party: "VVD (NLD)"
country: "Netherlands"
language: "nl"
words: 96
position: not_stated
topics: [Returns, Return hubs]
fallacies: []
---

Speaker: [[Malik Azmani]] · Group: [[Renew]] · Party: [[VVD (NLD)]] · Country: [[Netherlands]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 254 Tineke Strik (question)]]

# 2026-09-15 255 Malik Azmani (answer)

> Malik Azmani (Renew), “blauwe kaart”-antwoord.

## Text

Het is een illusie om te veronderstellen dat we migratie kunnen oplossen zonder samenwerking met landen waar mensen vandaan komen, landen waar mensen doorheen reizen. Het is een illusie om te denken dat we niet met hen kunnen onderhandelen, om ervoor te zorgen dat er afspraken worden gemaakt om ervoor te zorgen dat we controle krijgen op migratie. Het heeft niks met blackmailing te maken. Het heeft met realpolitiek te maken. Als we echt controle willen hebben over migratie en deze vele menselijke drama's willen voorkomen, dan moeten we afspraken kunnen maken met de desbetreffende landen.

## Summary
Answering Tineke Strik, Malik Azmani says it is an illusion to think migration can be managed without agreements with countries of origin and transit, and that this is realpolitik, not blackmail.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The answer is about cooperation with third countries.
- Quote: "Het heeft niks met blackmailing te maken. Het heeft met realpolitiek te maken." (translation by the agent: "It has nothing to do with blackmailing. It has to do with realpolitik.")

## Entities
None.

## Topics
- [[Returns]]
- [[Return hubs]]

## Fallacies
None.
