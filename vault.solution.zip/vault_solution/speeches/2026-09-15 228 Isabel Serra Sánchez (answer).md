---
type: "intervention"
kind: "answer"
speech_id: "2017094949347"
order: 228
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:54:16"
end_time: "13:54:55"
speaker: "Isabel Serra Sánchez"
speaker_label: "Isabel Serra Sánchez (The Left), respuesta de «tarjeta azul»."
group: "The Left"
party: "PODEMOS (ESP)"
country: "Spain"
language: "es"
words: 149
position: not_stated
topics: [Humanitarian situation and victims]
fallacies: [AD_HOMINEM]
---

Speaker: [[Isabel Serra Sánchez]] · Group: [[The Left]] · Party: [[PODEMOS (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 227 Diego Solier (question)]]

# 2026-09-15 228 Isabel Serra Sánchez (answer)

> Isabel Serra Sánchez (The Left), respuesta de «tarjeta azul».

## Text

(Inicio de la intervención fuera de micrófono) ... ustedes que nunca les han importado las mujeres, que están en contra de los derechos de las mujeres, que están en contra de todas las políticas que protejan los derechos de las mujeres, es realmente infame.

Lo que pasa —y lo que han dicho los datos— en Ceuta es que no son las personas migrantes las que están agrediendo sexualmente. Por supuesto que hay una situación de crisis humanitaria, por supuesto que hay una situación de inseguridad, no solamente para los ceutíes, también para las personas migrantes.

¿Sabe quiénes son las mujeres que están sufriendo la violencia sexual? Las mujeres migrantes, precisamente por lo que están haciendo ustedes —la derecha y la extrema derecha— de no hacer la acogida y dejarles en esa situación, porque les interesa, porque están muy contentos con la situación que está viviendo la gente en Ceuta.

## Summary
Answering Diego Solier, Isabel Serra Sánchez says the right has never cared about women, that the data show it is not migrants committing sexual assaults, and that migrant women are the main victims because the right refuses to organise reception.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The answer is about sexual violence and reception, not the EU's response.
- Quote: "¿Sabe quiénes son las mujeres que están sufriendo la violencia sexual? Las mujeres migrantes" (translation by the agent: "Do you know who the women suffering sexual violence are? Migrant women")

## Entities
- [[Ceuta]]

## Topics
- [[Humanitarian situation and victims]]

## Fallacies
- [[AD_HOMINEM]] (clear)
  - Quote: "ustedes que nunca les han importado las mujeres, que están en contra de los derechos de las mujeres" (translation by the agent: "you who have never cared about women, who are against women's rights")
  - Conclusion: The question about women's safety in Ceuta is illegitimate.
  - Defect: The question is dismissed by attacking the questioners' motives before any argument is given.
