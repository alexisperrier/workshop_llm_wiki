---
type: "intervention"
kind: "written"
speech_id: "2017096449353"
order: 285
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
speaker: "Nikola Bartůšek"
speaker_label: "Nikola Bartůšek (ECR), in writing."
group: "ECR"
country: "Czechia"
language: "en"
words: 194
position: supports
topics: [Instrumentalisation of migration, External border protection, Regularisation of migrants, Migrant smuggling]
fallacies: []
---

Speaker: [[Nikola Bartůšek]] · Group: [[ECR]] · Country: [[Czechia]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-09-15 285 Nikola Bartůšek (written)

> Nikola Bartůšek (ECR), in writing.

## Text

The recent events in Ceuta demonstrated once again that illegal migration can be instrumentalised as a tool of pressure against the EU and its Member States. When tens of thousands of migrants crossed the EU’s external border within days, Europe was facing not only a migration challenge, but also a serious security challenge.In response, I asked the Commission four simple questions: whether Frontex would be deployed, how the Commission would address policies that may encourage illegal migration, whether EU funding should be linked to the effective protection of external borders, and what concrete measures would be taken to prevent similar situations in the future.Unfortunately, the Commission’s response contained very few concrete answers. Instead, it focused on general statements about solidarity, overall migration trends and additional financial support for Spain.European citizens expect more. They expect effective protection of the EU’s external borders. We must also be willing to examine whether policies that legalize the status of illegally staying migrants create incentives for further illegal migration and strengthen the business model of people smugglers.Europe cannot afford to reward failures. It must demonstrate that it is capable of protecting its borders and responding decisively to hybrid threats.

## Summary
In a written statement, Nikola Bartůšek says Ceuta showed illegal migration being instrumentalised as a tool of pressure and that the Commission's answers to his four questions were vague. He calls for effective external border protection and for examining whether legalisation policies create incentives for smugglers.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He asks for effective protection of the external borders.
- Quote: "They expect effective protection of the EU’s external borders." (translation by the agent: "They expect effective protection of the EU's external borders.")

## Entities
- [[Ceuta]]
- [[European Commission|Commission]]
- [[Frontex]]
- [[Spain]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Regularisation of migrants]]
- [[Migrant smuggling]]

## Fallacies
None.
