---
type: "intervention"
kind: "question"
speech_id: "2017094949380"
order: 250
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:18:37"
end_time: "14:19:55"
speaker: "Sandro Ruotolo"
speaker_label: "Sandro Ruotolo (S&D)."
group: "S&D"
party: "PD (ITA)"
country: "Italy"
language: "it"
words: 161
position: opposes
topics: [Solidarity between Member States, Schengen and internal border controls, Instrumentalisation of migration, Humanitarian situation and victims]
fallacies: []
---

Speaker: [[Sandro Ruotolo]] · Group: [[S&D]] · Party: [[PD (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 247 Javier Zarzalejos]]

# 2026-09-15 250 Sandro Ruotolo (question)

> Sandro Ruotolo (S&D).

## Text

Signor Presidente, onorevoli colleghi, a Ceuta abbiamo visto cosa accade quando l'Europa dimentica di essere comunità: la Spagna si è trovata di fronte a un'emergenza senza precedenti. C'è stata una regia? Noi pensiamo di sì: a Ceuta c'è stato un attacco ibrido.

Sono in tanti a voler l'Europa divisa. Lo stiamo vedendo qui, in quest'Aula: davanti a una crisi simile, sarebbe dovuta scattare immediatamente la solidarietà. E invece, si sono alzati muri dentro l'Europa. L'Italia ha reintrodotto i controlli con la Spagna e Madrid è stata costretta a reintrodurre i controlli con l'Italia. Proprio il contrario di Europa.

E allora mi rivolgo alla presidente Meloni: che facciamo? Invochiamo la solidarietà per Lampedusa e la neghiamo per Ceuta? Troppo comodo. La mancanza di solidarietà rende più debole l'Europa. Per questo la mia solidarietà va alla Spagna, al governo di Pedro Sanchez.

Hoy somos todos españoles. Ho sentito parole terribili, come clandestini, invasori, marocchini. No, sono esseri umani e noi dobbiamo restare umani.

## Summary
Sandro Ruotolo says Ceuta suffered a hybrid attack and that instead of solidarity, walls went up inside Europe: Italy reintroduced controls with Spain and Madrid had to respond. He asks Meloni how she can invoke solidarity for Lampedusa and deny it for Ceuta, expresses solidarity with Spain and the Sánchez government, and rejects words like 'invaders'.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: He makes solidarity, not walls, the answer.
- Quote: "La mancanza di solidarietà rende più debole l'Europa." (translation by the agent: "The lack of solidarity makes Europe weaker.")

## Entities
- [[Ceuta]]
- [[Spain|Spagna]]
- [[Italy|L'Italia]]
- [[Madrid]]
- [[Giorgia Meloni|presidente Meloni]]
- [[Lampedusa]]
- [[Pedro Sánchez|Pedro Sanchez]]

## Topics
- [[Solidarity between Member States]]
- [[Schengen and internal border controls]]
- [[Instrumentalisation of migration]]
- [[Humanitarian situation and victims]]

## Fallacies
None.
