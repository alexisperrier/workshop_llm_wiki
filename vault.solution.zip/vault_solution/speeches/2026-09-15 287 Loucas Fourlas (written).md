---
type: "intervention"
kind: "written"
speech_id: "2017096133627"
order: 287
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
speaker: "Loucas Fourlas"
speaker_label: "Λουκάς Φουρλάς (PPE), γραπτώς."
group: "PPE"
party: "DI.SY. (CYP)"
country: "Cyprus"
language: "el"
words: 135
position: supports
topics: [Instrumentalisation of migration, External border protection, Migrant smuggling, Returns, Humanitarian situation and victims]
fallacies: []
---

Speaker: [[Loucas Fourlas]] · Group: [[PPE]] · Party: [[DI.SY. (CYP)]] · Country: [[Cyprus]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-09-15 287 Loucas Fourlas (written)

> Λουκάς Φουρλάς (PPE), γραπτώς.

## Text

Αγαπητοί συνάδελφοι,Η κρίση της Θέουτα δυστυχώς εγείρει για άλλη μια φορά θέματα που αφορούν την ασφάλεια, τη σταθερότητα, αλλά και την αξιοπιστία ολόκληρης της Ευρωπαϊκής Ένωσης. Η εργαλειοποίηση της μετανάστευσης αποτελεί σοβαρή υβριδική απειλή, την οποία βεβαίως αντιμετωπίζουν και άλλες περιοχές της Ευρώπης. Η Ευρωπαϊκή Ένωση δεν μπορεί να παραμένει παρατηρητής όταν τα εξωτερικά της σύνορα απειλούνται. Χρειαζόμαστε μια συντονισμένη ευρωπαϊκή απάντηση, με ενισχυμένη παρουσία της Frontex, αποτελεσματική συνεργασία με τις χώρες προέλευσης και διέλευσης, αντιμετώπιση των δικτύων διακινητών και εφαρμογή των ευρωπαϊκών κανόνων για τις επιστροφές.Φυσικά, η προστασία των συνόρων πρέπει να συμβαδίζει με τον σεβασμό του διεθνούς δικαίου και των θεμελιωδών δικαιωμάτων. Η Ευρωπαϊκή Ένωση οφείλει να δείξει ότι προστατεύει πραγματικά τα σύνορά της, στηρίζει τα κράτη μέλη της και δεν πρόκειται να επιτρέψει την εργαλειοποίηση ανθρώπων για άσκηση πολιτικής πίεσης. Σας ευχαριστώ.

## Summary
In a written statement, Loucas Fourlas calls the instrumentalisation of migration a serious hybrid threat and says the EU cannot remain a spectator when its external borders are threatened. He calls for a coordinated response with more Frontex, cooperation with countries of origin and transit, action against smugglers and application of the return rules, in respect of international law.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He calls for a coordinated response with a reinforced Frontex.
- Quote: "Χρειαζόμαστε μια συντονισμένη ευρωπαϊκή απάντηση, με ενισχυμένη παρουσία της Frontex" (translation by the agent: "We need a coordinated European response, with a reinforced presence of Frontex")

## Entities
- [[Ceuta|Θέουτα]]
- [[Frontex]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Migrant smuggling]]
- [[Returns]]
- [[Humanitarian situation and victims]]

## Fallacies
None.
