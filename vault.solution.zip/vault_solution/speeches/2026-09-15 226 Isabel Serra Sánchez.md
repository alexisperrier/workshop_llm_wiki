---
type: "intervention"
kind: "speech"
speech_id: "2017094943136"
order: 226
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:52:41"
end_time: "13:53:48"
speaker: "Isabel Serra Sánchez"
speaker_label: "Isabel Serra Sánchez (The Left)."
group: "The Left"
party: "PODEMOS (ESP)"
country: "Spain"
language: "es"
words: 194
position: opposes
topics: [EU-Morocco relations, Instrumentalisation of migration, Responsibility of the Spanish government, Humanitarian situation and victims, External border protection]
fallacies: [UNSUPPORTED_ASSERTION]
---

Speaker: [[Isabel Serra Sánchez]] · Group: [[The Left]] · Party: [[PODEMOS (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 226 Isabel Serra Sánchez

> Isabel Serra Sánchez (The Left).

## Text

Señor presidente, señorías, dejen de tratar de engañar a la gente y digan la verdad. ¿Quién está detrás de lo sucedido en Ceuta? Marruecos, la dictadura marroquí y sus socios Trump y Netanyahu. Hay que decirlo en este Parlamento que está entregado a esos genocidas.

¿Por qué pueden chantajear a España? Porque todos los Gobiernos, tanto del Partido Popular como del Partido Socialista, han sido siempre aliados de Marruecos —por cierto, en contra del Sáhara Occidental—. Y ¿por qué tienen tanto poder? Porque la Unión Europea le da millonadas a Marruecos para gestionar las fronteras y ejecutar su política migratoria criminal.

Quienes huyen de la pobreza y de la violencia no son invasores, son víctimas de ese sistema colonial, racista y capitalista que saquea a sus países y después los criminaliza y los ahoga.

Por último, señores de la extrema derecha, a ustedes nunca les ha importado Ceuta. Solo quieren convertirla en su laboratorio de odio. Llaman a cazar inmigrantes y luego hay personas que se dedican a hacer pogromos para quemar tiendas y para disparar a niños. Han aprendido perfectamente lo que les ha pedido su amigo y su amo Netanyahu. Un aplauso.

## Summary
Isabel Serra Sánchez says Morocco and its partners Trump and Netanyahu are behind Ceuta, and that Spain can be blackmailed because PP and PSOE governments have always been Morocco's allies, against Western Sahara, while the EU pays Morocco to run its 'criminal' migration policy. She says migrants are victims, not invaders, and accuses the far right of turning Ceuta into a laboratory of hatred.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She rejects EU border outsourcing to Morocco and treats migrants as victims, not invaders.
- Quote: "Quienes huyen de la pobreza y de la violencia no son invasores, son víctimas" (translation by the agent: "Those fleeing poverty and violence are not invaders, they are victims")

## Entities
- [[Ceuta]]
- [[Morocco|Marruecos]]
- [[Donald Trump|Trump]]
- [[Benjamin Netanyahu|Netanyahu]]
- [[Spain|España]]
- [[PP (ESP)|Partido Popular]]
- [[PSOE (ESP)|Partido Socialista]]
- [[Western Sahara|Sáhara Occidental]]

## Topics
- [[EU-Morocco relations]]
- [[Instrumentalisation of migration]]
- [[Responsibility of the Spanish government]]
- [[Humanitarian situation and victims]]
- [[External border protection]]

## Fallacies
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "¿Quién está detrás de lo sucedido en Ceuta? Marruecos, la dictadura marroquí y sus socios Trump y Netanyahu." (translation by the agent: "Who is behind what happened in Ceuta? Morocco, the Moroccan dictatorship and its partners Trump and Netanyahu.")
  - Conclusion: Foreign powers engineered the crossing.
  - Defect: The role of Trump and Netanyahu is asserted without support.
