---
type: "intervention"
kind: "question"
speech_id: "2017094949359"
order: 239
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:06:46"
end_time: "14:07:09"
speaker: "Abir Al-Sahlani"
speaker_label: "Abir Al-Sahlani (Renew), blue-card question."
group: "Renew"
party: "C (SWE)"
country: "Sweden"
language: "en"
words: 49
position: not_stated
topics: []
fallacies: []
---

Speaker: [[Abir Al-Sahlani]] · Group: [[Renew]] · Party: [[C (SWE)]] · Country: [[Sweden]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 238 Susanna Ceccardi]]

# 2026-09-15 239 Abir Al-Sahlani (question)

> Abir Al-Sahlani (Renew), blue-card question.

## Text

Colleague, thank you for taking my question. I have just a question of knowledge. Do you know where Ceuta is? Because you said that migrants had invaded Europe. Do you have any idea where Ceuta is geographically? And what is the difference between being Europe or the European Union?

## Summary
In a blue-card question to Susanna Ceccardi, Abir Al-Sahlani asks whether she knows where Ceuta is geographically, and what the difference is between Europe and the European Union.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about geography, not the EU's response.
- Quote: "Do you have any idea where Ceuta is geographically?"

## Entities
- [[Ceuta]]

## Topics
None.

## Fallacies
None.
