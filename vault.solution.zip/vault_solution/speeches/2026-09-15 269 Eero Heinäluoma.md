---
type: "intervention"
kind: "speech"
speech_id: "2017094949416"
order: 269
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:40:16"
end_time: "14:41:27"
speaker: "Eero Heinäluoma"
speaker_label: "Eero Heinäluoma (S&D)."
group: "S&D"
party: "SDP (FIN)"
country: "Finland"
language: "fi"
words: 92
position: supports
topics: [Instrumentalisation of migration, External border protection, Solidarity between Member States]
fallacies: []
---

Speaker: [[Eero Heinäluoma]] · Group: [[S&D]] · Party: [[SDP (FIN)]] · Country: [[Finland]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 269 Eero Heinäluoma

> Eero Heinäluoma (S&D).

## Text

Arvoisa puhemies, tulen maasta, joka on sekin kohdannut välineellistettyä maahantuloa.

Suuri naapurimme Venäjä on useampaan kertaan ohjannut ihmisiä kaukaa omien rajojensa ulkopuolelta tulemaan Suomen rajoille. Näiden operaatioiden tarkoitus on käynyt selväksi. Se on sekaannuksen aiheuttaminen, sisäisten kiistojen lietsominen ja levottomuuden lietsominen.

Suomessa olemme tyytyväisiä, että Euroopan unioni on ymmärtänyt tilanteen ja antanut Suomelle täyden tuen rajavalvonnassa.

Kun nyt Espanjan Ceutaan kohdistuu paljon isompi maahantuloyritys, on selvää, että espanjalaiset ansaitsevat meidän kaikkien tuen. Ei syyttelyä, ei syyn näkemistä Espanjassa, joka on maahantuloyrityksen kohteena.

Rajojen valvontaa voidaan tehdä myös yhdessä. Olkaamme siis Espanjan apuna.

## Summary
Eero Heinäluoma says Finland has faced instrumentalised migration organised by Russia to cause confusion and internal disputes, and is grateful for the EU's full support for its border surveillance. Spain now deserves everyone's support, without blame, and border surveillance can be done together.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He calls for joint border surveillance to help Spain.
- Quote: "Rajojen valvontaa voidaan tehdä myös yhdessä. Olkaamme siis Espanjan apuna." (translation by the agent: "Border surveillance can also be done together. So let us help Spain.")

## Entities
- [[Russia|Venäjä]]
- [[Finland|Suomen]]
- [[Spain|Espanjan]]
- [[Ceuta|Ceutaan]]

## Topics
- [[Instrumentalisation of migration]]
- [[External border protection]]
- [[Solidarity between Member States]]

## Fallacies
None.
