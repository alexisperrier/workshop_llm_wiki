---
type: "intervention"
kind: "speech"
speech_id: "2017094943105"
order: 211
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:26:55"
end_time: "13:29:50"
speaker: "Iratxe García Pérez"
speaker_label: "Iratxe García Pérez, en nombre del Grupo S&D."
group: "S&D"
party: "PSOE (ESP)"
country: "Spain"
on_behalf_of_group: "S_D"
language: "es"
words: 383
position: mixed
topics: [Solidarity between Member States, Humanitarian situation and victims, Sovereignty of Ceuta and Melilla, Responsibility of the Spanish government, Schengen and internal border controls, Instrumentalisation of migration, Returns]
fallacies: [STRAW_MAN]
---

Speaker: [[Iratxe García Pérez]] · Group: [[S&D]] · Party: [[PSOE (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 211 Iratxe García Pérez

> Iratxe García Pérez, en nombre del Grupo S&D.

## Text

Señora presidenta, quiero comenzar agradeciendo al Consejo y al Comisario por su aportación constructiva a este debate, no así la posición de un Partido Popular Europeo que lleva más de un mes manoseando Ceuta con el único objetivo de atacar al Gobierno de España.

Quiero comenzar mi intervención recordando a las más de 150 personas que perdieron la vida en Ceuta y a sus familias, porque detrás de cada vida hay una historia y hay un dolor.

Hoy también quiero decir algo muy claro: Ceuta no está sola, Ceuta es España, Ceuta es Europa. Y cuando una frontera está bajo presión, Europa debe responder con solidaridad, no con división.

Por eso resulta tan difícil escuchar lecciones de algunos, lecciones de quienes suspenden Schengen con España. ¿Qué lecciones puede dar la señora Meloni sobre gestión de fronteras? ¿Qué lecciones puede dar sobre humanidad después de que Europa se volcara con Italia en la crisis de Lampedusa?

Europa también estuvo con Polonia y Lituania frente a la instrumentalización de la migración por el régimen de Lukashenko. La solidaridad europea no puede depender de quién gobierna y ni de qué país sufre la crisis.

Quiero ser igualmente clara con el Partido Popular y con VOX: pedir expulsiones que incumplan la Ley del Menor, la Ley de Extranjería y la legislación europea e internacional es violar el Estado de Derecho. Hablar de «invasores» o de «invasión» solo alimenta la desinformación y la xenofobia. Y ya sabemos lo que ocurre cuando se alimenta la desinformación y la xenofobia: unos alimentan estas crisis y otros recogen los resultados.

Si de verdad les importa Ceuta, participen en el reparto de menores en las comunidades autónomas donde gobiernan. Europa debe estar con Ceuta, con Frontex, Europol y la Agencia de Asilo, y con todos los recursos financieros necesarios.

Frente al odio y al miedo, la sociedad ceutí nos ha demostrado con sus valores la convivencia y la paz.

Si para defender Europa nos piden que nos convirtamos en bárbaros que pisotean y destrozan los derechos de quien no reza como nosotros o quien no tiene nuestro color de piel, no cuenten con nosotros. Nosotros defenderemos la Europa que cuida y protege a sus ciudadanos, la Europa que no se arrodilla ante los más poderosos y la Europa que respeta la humanidad.

## Summary
Iratxe García Pérez accuses the EPP of exploiting Ceuta to attack the Spanish government, remembers the dead and says Ceuta is Spain and Europe. She criticises Meloni for suspending Schengen with Spain, warns the PP and VOX that expulsions breaking the law violate the rule of law, and calls for the distribution of minors among regions and for EU support through Frontex, Europol and the Asylum Agency.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: mixed
- Justification: She accepts operational support from Frontex but makes solidarity and respect for the law, not border protection, the core of the response.
- Quote: "cuando una frontera está bajo presión, Europa debe responder con solidaridad, no con división" (translation by the agent: "when a border is under pressure, Europe must respond with solidarity, not division")

## Entities
- [[PPE|Partido Popular Europeo]]
- [[Government of Spain|Gobierno de España]]
- [[Ceuta]]
- [[Spain|España]]
- [[Schengen Area|Schengen]]
- [[Giorgia Meloni|señora Meloni]]
- [[Lampedusa migration crisis (2023)|crisis de Lampedusa]]
- [[Italy|Italia]]
- [[Poland|Polonia]]
- [[Lithuania|Lituania]]
- [[Alexander Lukashenko|Lukashenko]]
- [[PP (ESP)|Partido Popular]]
- [[VOX (ESP)|VOX]]
- [[Spanish Minors Act|Ley del Menor]]
- [[Spanish Aliens Act|Ley de Extranjería]]
- [[Frontex]]
- [[Europol]]
- [[European Union Agency for Asylum|Agencia de Asilo]]

## Topics
- [[Solidarity between Member States]]
- [[Humanitarian situation and victims]]
- [[Sovereignty of Ceuta and Melilla]]
- [[Responsibility of the Spanish government]]
- [[Schengen and internal border controls]]
- [[Instrumentalisation of migration]]
- [[Returns]]

## Fallacies
- [[STRAW_MAN]] (borderline)
  - Quote: "Si para defender Europa nos piden que nos convirtamos en bárbaros que pisotean y destrozan los derechos de quien no reza como nosotros" (translation by the agent: "If to defend Europe they ask us to become barbarians who trample and destroy the rights of those who do not pray as we do")
  - Conclusion: Her group will not take part in the opponents' approach to the crisis.
  - Defect: The opponents' demands (returns, border protection) are recast as a demand to become barbarians trampling rights by religion and skin colour, a position no one stated, which is then rejected.
