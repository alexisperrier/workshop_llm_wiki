---
type: "intervention"
kind: "speech"
speech_id: "2017094943121"
order: 218
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:40:38"
end_time: "13:42:33"
speaker: "Magnus Brunner"
speaker_label: "Magnus Brunner, Member of the Commission."
language: "en"
words: 250
position: supports
topics: [Pact on Migration and Asylum, Returns, Schengen and internal border controls, External border protection, EU-Morocco relations]
fallacies: []
---

Speaker: [[Magnus Brunner]] · Role: Member of the Commission
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 218 Magnus Brunner

> Magnus Brunner, Member of the Commission.

## Text

Madam President, Minister, ladies and gentlemen, honourable Members, I think what we really have to keep in mind is that our new approach, on which we agreed in the last months and years, our new approach to managing migration and asylum has helped decrease the illegal arrivals. I think this is in the centre of our discussion also. This is a real success we achieved altogether.

Yet, of course, Ceuta and the events of Ceuta show how quickly the situation can change and also how fast pressure can build up. I think we all agree that we need to act on our borders. We need to act also beyond with migration diplomacy, with our partners, with our neighbours, promoting our interests – yes, our European interests – in a smart way with all our tools we have.

We need also to act, of course, on our own rules: the pact, the Return Regulation, the safe countries, the entry/exit system. Of course, a lot of things to do and all these should deploy actually their full potential in the coming months to preserve and reinforce the Schengen area, this is all I think about that. The Schengen area is one of the biggest achievements of the European Union and, of course, we have to do everything to preserve it and to reinforce it.

We face demanding times ahead of us, yes, but we have the tools and also we have the determination to bring what European citizens actually expect from us.

## Summary
In a short reply, Commissioner Brunner says the new approach to migration and asylum has decreased illegal arrivals, but Ceuta shows how fast pressure can build. He calls for action on the borders, migration diplomacy with neighbours, and full use of the Pact, the Return Regulation, the safe countries rules and the Entry/Exit System to preserve and reinforce the Schengen area.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He says we need to act on our borders and on the EU's own rules to preserve Schengen.
- Quote: "I think we all agree that we need to act on our borders."

## Entities
- [[Ceuta]]
- [[Pact on Migration and Asylum|the pact]]
- [[Return Regulation]]
- [[Entry-Exit System|entry/exit system]]
- [[Schengen Area|Schengen area]]

## Topics
- [[Pact on Migration and Asylum]]
- [[Returns]]
- [[Schengen and internal border controls]]
- [[External border protection]]
- [[EU-Morocco relations]]

## Fallacies
None.
