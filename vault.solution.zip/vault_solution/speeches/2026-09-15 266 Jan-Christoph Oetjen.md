---
type: "intervention"
kind: "speech"
speech_id: "2017094949410"
order: 266
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:36:19"
end_time: "14:37:32"
speaker: "Jan-Christoph Oetjen"
speaker_label: "Jan-Christoph Oetjen (Renew)."
group: "Renew"
party: "FDP (DEU)"
country: "Germany"
language: "de"
words: 167
position: mixed
topics: [Responsibility of the Spanish government, Solidarity between Member States, Schengen and internal border controls, Pact on Migration and Asylum, External border protection]
fallacies: []
---

Speaker: [[Jan-Christoph Oetjen]] · Group: [[Renew]] · Party: [[FDP (DEU)]] · Country: [[Germany]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 266 Jan-Christoph Oetjen

> Jan-Christoph Oetjen (Renew).

## Text

Herr Präsident! Lieber Herr Kommissar! Ich möchte als Erstes einmal sagen, dass es völlig inakzeptabel ist, dass Zehntausende von Menschen einfach so eine Grenze überrennen und auf europäisches Gebiet eindringen. Ich finde, dass wir ein Licht darauf werfen müssen, wie das tatsächlich entstanden ist.

Spanien hat aus meiner Sicht zu zögerlich gehandelt. Und ich finde, das darf man kritisieren, und das muss man vielleicht sogar kritisieren. Das ändert nichts daran, dass unsere Antwort natürlich Solidarität mit Spanien sein muss in dieser schwierigen Lage. Aber was ist passiert? Andere Mitgliedstaaten haben das gleich politisch ausgeschlachtet. Italien hat völlig unsinnige Grenzkontrollen auf den Weg gebracht. Dabei weiß ja eigentlich jeder, dass Ceuta einen Sonderstatus hat und die Leute gar nicht einfach so nach Europa kommen können. Die Antwort auf so eine Krise muss aber immer noch eine europäische sein. Wir müssen den Pakt umsetzen. Wir müssen Frontex stärken, dass sie proaktiver handeln können – und dann wird das auch besser, und wir können klarer reagieren in einer solchen Krisensituation.

## Summary
Jan-Christoph Oetjen says it is unacceptable that tens of thousands overran a border and that Spain acted too hesitantly, which may be criticised, but that the answer must be solidarity with Spain. He criticises Italy's senseless border controls, given Ceuta's special status, and calls for a European answer: implementing the Pact and strengthening Frontex so it can act more proactively.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: mixed
- Justification: He supports a stronger Frontex and the Pact, within a European response based on solidarity.
- Quote: "Wir müssen den Pakt umsetzen. Wir müssen Frontex stärken, dass sie proaktiver handeln können" (translation by the agent: "We must implement the Pact. We must strengthen Frontex so that they can act more proactively")

## Entities
- [[Spain|Spanien]]
- [[Italy|Italien]]
- [[Ceuta]]
- [[Pact on Migration and Asylum|Pakt]]
- [[Frontex]]

## Topics
- [[Responsibility of the Spanish government]]
- [[Solidarity between Member States]]
- [[Schengen and internal border controls]]
- [[Pact on Migration and Asylum]]
- [[External border protection]]

## Fallacies
None.
