---
type: "intervention"
kind: "written"
speech_id: "2017096133628"
order: 288
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
speaker: "Tomasz Froelich"
speaker_label: "Tomasz Froelich (ESN), schriftlich."
group: "ESN"
party: "AfD (DEU)"
country: "Germany"
language: "de"
words: 207
position: mixed
topics: [Instrumentalisation of migration, EU-Morocco relations, Responsibility of the Spanish government, Regularisation of migrants]
fallacies: [STRAW_MAN]
---

Speaker: [[Tomasz Froelich]] · Group: [[ESN]] · Party: [[AfD (DEU)]] · Country: [[Germany]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-09-15 288 Tomasz Froelich (written)

> Tomasz Froelich (ESN), schriftlich.

## Text

85.000 Migranten in zwei Tagen - was in Ceuta geschah, war keine organische Migrationsbewegung, sondern ein koordinierter hybrider Angriff, hinter dem wohl auch Marokko steckt. Schon in der Vergangenheit, insbesondere 2021, hat Rabat Migrationsströme als politisches Druckmittel gegen Madrid eingesetzt, etwa in der Westsahara-Frage - damals stürmten etwa 12.000 Migranten Ceuta. Diesmal könnte die energiepolitische Annäherung Spaniens an Marokkos regionalen Rivalen Algerien ein Auslöser gewesen sein. Vor dem Hintergrund der Tatsache, dass Marokko mehrere formale Abkommen und Partnerschaften mit der EU hat, stellt sich die Frage, ob Marokko hier auf eigene Faust gehandelt hat. Natürlich begünstigt auch Spaniens desaströse Migrationspolitik einen solchen hybriden Angriff. Denn wer, wie Pedro Sánchez, grenzenlose Migration propagiert, kann sich kaum dagegen wehren, wenn gegen ihn die Migrationswaffe gerichtet wird. Da Marokkos Erpressung durch Migration potentiell auch uns gefährdet, müssen wir den Druck auf Rabat erhöhen, um solche hybriden Angriffe künftig zu unterbinden: Marokko erhält von der EU im Schnitt rund 200–250 Millionen Euro pro Jahr an bilateralen Zuschüssen, Budgethilfen - 233 Millionen Euro allein 2025 -, und Global-Gateway-Mittel. Hinzu kommen jährlich variable EIB-Darlehen in oft dreistelliger Millionenhöhe. Ein ziemlich hoher Preis dafür, dass man im Gegenzug mit der Migrationswaffe erpresst wird. Diese Mittel müssen gestrichen, zumindest aber an striktere Konditionen geknüpft werden!

## Summary
In a written statement, Tomasz Froelich says the arrival of 85,000 migrants in two days was a coordinated hybrid attack probably backed by Morocco, as in 2021 over Western Sahara, possibly triggered by Spain's rapprochement with Algeria. He blames Sánchez's migration policy and calls for cutting EU funds to Morocco, or at least making them strictly conditional.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: mixed
- Justification: His main answer is pressure on Morocco through EU funding, not border measures.
- Quote: "Diese Mittel müssen gestrichen, zumindest aber an striktere Konditionen geknüpft werden!" (translation by the agent: "These funds must be cut, or at least tied to stricter conditions!")

## Entities
- [[Ceuta]]
- [[Morocco|Marokko]]
- [[Rabat]]
- [[Government of Spain|Madrid]]
- [[Western Sahara|Westsahara]]
- [[Ceuta border crisis (2021)|2021]]
- [[Spain|Spaniens]]
- [[Algeria|Algerien]]
- [[Pedro Sánchez]]
- [[Global Gateway|Global-Gateway]]
- [[European Investment Bank|EIB]]

## Topics
- [[Instrumentalisation of migration]]
- [[EU-Morocco relations]]
- [[Responsibility of the Spanish government]]
- [[Regularisation of migrants]]

## Fallacies
- [[STRAW_MAN]] (borderline)
  - Quote: "wer, wie Pedro Sánchez, grenzenlose Migration propagiert" (translation by the agent: "whoever, like Pedro Sánchez, promotes borderless migration")
  - Conclusion: Spain's policy invited the attack.
  - Defect: The Spanish government's policy is recast as promoting borderless migration, an exaggerated version that is then used against it.
