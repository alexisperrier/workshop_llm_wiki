---
type: "intervention"
kind: "question"
speech_id: "2017094949355"
order: 237
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:03:51"
end_time: "14:05:05"
speaker: "Birgit Sippel"
speaker_label: "Birgit Sippel (S&D)."
group: "S&D"
party: "SPD (DEU)"
country: "Germany"
language: "de"
words: 119
position: opposes
topics: [Humanitarian situation and victims, Solidarity between Member States, Schengen and internal border controls, Instrumentalisation of migration]
fallacies: []
---

Speaker: [[Birgit Sippel]] · Group: [[S&D]] · Party: [[SPD (DEU)]] · Country: [[Germany]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 234 Lena Düpont]]

# 2026-09-15 237 Birgit Sippel (question)

> Birgit Sippel (S&D).

## Text

Herr Präsident! Ceuta: Über 140 Menschen haben bei dieser Tragödie ihr Leben verloren. Zugleich wird Europa auf die Probe gestellt: Falschinformationen, Manipulation und auch Gewalt sind menschenverachtende Versuche, unser Fundament, unseren gesellschaftlichen Zusammenhalt zu zerstören und uns zu schwächen. Reflexartige Schuldzuweisungen, sinnlose Grenzkontrollen gießen zusätzlich Öl ins Feuer und untergraben das Vertrauen unserer Bürgerinnen und Bürger. Und nichts davon bietet reale Antworten auf Herausforderungen.

Unsere Botschaft kann nur Solidarität sein – mit Mitgliedstaaten, mit Menschen und insbesondere mit Kindern. Und ganz klar: Wir müssen Asylrecht umsetzen, Schengen bewahren, unsere Demokratie und Grundrechte verteidigen. Genau das stärkt unsere Gesellschaft und unterscheidet uns klar von allen, die aus Eigennutz ein schwaches Europa wollen. Spielen wir denen nicht weiter in die Hände.

## Summary
Birgit Sippel says over 140 people died in Ceuta and that disinformation, manipulation and violence aim to weaken Europe. She calls blame and senseless border controls fuel on the fire, and says the message must be solidarity with Member States, people and children, applying asylum law and preserving Schengen.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: opposes
- Justification: She rejects border controls and blame and makes solidarity and asylum law the answer.
- Quote: "Unsere Botschaft kann nur Solidarität sein – mit Mitgliedstaaten, mit Menschen und insbesondere mit Kindern." (translation by the agent: "Our message can only be solidarity – with Member States, with people and especially with children.")

## Entities
- [[Ceuta]]
- [[Schengen Area|Schengen]]

## Topics
- [[Humanitarian situation and victims]]
- [[Solidarity between Member States]]
- [[Schengen and internal border controls]]
- [[Instrumentalisation of migration]]

## Fallacies
None.
