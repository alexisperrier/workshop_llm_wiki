---
type: "intervention"
kind: "question"
speech_id: "2017094949376"
order: 248
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:17:01"
end_time: "14:17:47"
speaker: "Anna Strolenberg"
speaker_label: "Anna Strolenberg (Verts/ALE), blue-card question."
group: "Verts-ALE"
party: "Volt (NLD)"
country: "Netherlands"
language: "en"
words: 125
position: not_stated
topics: [Solidarity between Member States]
fallacies: []
---

Speaker: [[Anna Strolenberg]] · Group: [[Verts-ALE]] · Party: [[Volt (NLD)]] · Country: [[Netherlands]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Blue-card question on: [[2026-09-15 247 Javier Zarzalejos]]

# 2026-09-15 248 Anna Strolenberg (question)

> Anna Strolenberg (Verts/ALE), blue-card question.

## Text

Mr President, this debate calls for a coordinated response after what happened in Ceuta. And we didn't actually see this, did we? We saw leaders wanting to close their borders for Spain and being angry at what happened, instead of showing solidarity for the people that arrived. This is the exact opposite of solidarity.

Now we see that this debate is being turned into a Spanish debate. You're the Chair of the LIBE Committee. Shouldn't you focus on European solidarity? Because we know that we are vulnerable exactly because of this. Autocratic leaders can toy with us; they know we can be divided. And you're also not standing up for European solidarity. So why aren't you angry at the countries not standing up for you?

## Summary
In a blue-card question to Javier Zarzalejos, Anna Strolenberg says leaders wanted to close borders to Spain instead of showing solidarity, and asks him, as Chair of the LIBE Committee, why he turns the debate into a Spanish one and is not angry at the countries not standing up for Spain.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The question is about solidarity, not border protection.
- Quote: "So why aren't you angry at the countries not standing up for you?"

## Entities
- [[Ceuta]]
- [[Spain]]
- [[LIBE Committee]]

## Topics
- [[Solidarity between Member States]]

## Fallacies
None.
