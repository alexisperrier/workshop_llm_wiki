---
type: "intervention"
kind: "speech"
speech_id: "2017081987262"
order: 268
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:24:28"
end_time: "14:27:03"
speaker: "François-Xavier Bellamy"
speaker_label: "François-Xavier Bellamy, au nom du groupe PPE."
group: "PPE"
party: "Les Républicains (FRA)"
country: "France"
on_behalf_of_group: "PPE"
language: "fr"
words: 451
position: supports
topics: [Returns, Detention of migrants, Return hubs, Migrant smuggling, Majorities in Parliament]
fallacies: [FALSE_DILEMMA, UNSUPPORTED_ASSERTION]
---

Speaker: [[François-Xavier Bellamy]] · Group: [[PPE]] · Party: [[Les Républicains (FRA)]] · Country: [[France]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 268 François-Xavier Bellamy

> François-Xavier Bellamy, au nom du groupe PPE.

## Text

Monsieur le Président, chers collègues, nous y sommes. Demain aura lieu le vote final sur le règlement retour. C'est la fin de plusieurs décennies d'impuissance face à l'immigration illégale et de huit longues années de blocage dans la révision de la directive retour, qui disparaîtra enfin dans quelques jours. Le droit ne protégeait que celui qui avait enfreint la loi. Désormais, nous remettons la règle à l'endroit. Quand moins de 20 % des décisions de retour en Europe sont mises en œuvre aujourd'hui, 100 % pourront l'être demain. Pas dans deux ans comme certains le voulaient, demain.

Demain, nos États retrouveront la possibilité d'expulser. Les délais de rétention seront augmentés sans limite pour les individus qui représentent un danger. Nos policiers et nos gendarmes auront enfin la base légale nécessaire pour lutter contre les passeurs. Un crime, un délit vaudra une interdiction d'entrée. Les recours ne serviront plus à retarder l'expulsion et les centres de retour mettront fin au chantage des régimes qui empêchent le retour de leurs ressortissants. Demain, il sera clair qu'on ne peut s'établir en Europe que si on y a été légalement autorisé. Rien d'exceptionnel là-dedans, simplement le retour à la règle. Nous rendons le pouvoir à nos démocraties et aux citoyens de nos pays la maîtrise de leurs frontières.

Mais il semble que certains voudraient encore interdire ce retour à la normale. Quand la discussion a buté sur cette opposition fondamentale, nous avons assumé nos responsabilités. Et c'est à partir du texte que j'ai proposé, au nom du PPE, que nous voterons demain. Et nous sommes fiers de cela, fiers de ce résultat historique qui montre que, oui, l'Europe peut changer. Que, quand les électeurs le veulent, la politique peut et doit agir pour apporter les résultats concrets dont nos pays ont tant besoin.

Je voudrais remercier tous les élus qui ont rendu possible ce changement. Vous remercier, Monsieur le Commissaire, Lieber Magnus, pour le travail que tu as fait au sein de la Commission. Remercier le Conseil et les gouvernements européens qui, presque tous, veulent tout mettre en œuvre pour appliquer ce nouveau règlement retour. Demain, chers collègues, c'est la seule question qui sera posée à chacun d'entre nous ici, qui veut vraiment rompre avec la faillite actuelle de l'Europe face à l'immigration illégale, cette faillite qui a causé tant de drames? Qui veut vraiment protéger l'état de droit et sortir de l'état de non-droit, qui voit nos États et nos juridictions impuissantes? Qui refuse que le droit d'asile soit détourné comme il l'est aujourd'hui partout? Qui croit que l'Europe peut être fidèle aux principes de la démocratie en répondant aujourd'hui à l'attente si forte des citoyens de nos pays? Chacun est devant ce choix.

## Summary
François-Xavier Bellamy says the vote ends decades of powerlessness on illegal immigration and eight years of blocked revision of the Return Directive. He lists the changes: expulsions, unlimited detention for dangerous individuals, entry bans after a crime, non-suspensive appeals and return centres; he says the final text is based on the one he proposed for the EPP, and frames the vote as a choice to end Europe's failure.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He says the EPP is proud of this historic result and calls for a vote in favour.
- Quote: "nous sommes fiers de cela, fiers de ce résultat historique qui montre que, oui, l'Europe peut changer" (translation by the agent: "we are proud of it, proud of this historic result which shows that, yes, Europe can change")

## Entities
- [[Return Regulation|règlement retour]]
- [[Return Directive|directive retour]]
- [[PPE]]
- [[Magnus Brunner|Lieber Magnus]]
- [[European Commission|la Commission]]
- [[Council of the European Union|le Conseil]]

## Topics
- [[Returns]]
- [[Detention of migrants]]
- [[Return hubs]]
- [[Migrant smuggling]]
- [[Majorities in Parliament]]

## Fallacies
- [[FALSE_DILEMMA]] (borderline)
  - Quote: "Qui veut vraiment rompre avec la faillite actuelle de l'Europe face à l'immigration illégale, cette faillite qui a causé tant de drames?" (translation by the agent: "Who really wants to break with Europe's current failure on illegal immigration, this failure that has caused so many tragedies?")
  - Conclusion: Members must vote for the regulation.
  - Defect: The vote is framed as a choice between this text and keeping the failure, leaving out other reforms; as rhetorical questions it stays borderline.
- [[UNSUPPORTED_ASSERTION]] (clear)
  - Quote: "Le droit ne protégeait que celui qui avait enfreint la loi." (translation by the agent: "The law only protected the one who had broken the law.")
  - Conclusion: The old return rules had to be replaced.
  - Defect: A sweeping claim about the existing law is stated without support.
