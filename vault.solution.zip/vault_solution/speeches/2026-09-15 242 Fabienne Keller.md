---
type: "intervention"
kind: "speech"
speech_id: "2017094949364"
order: 242
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:09:14"
end_time: "14:10:25"
speaker: "Fabienne Keller"
speaker_label: "Fabienne Keller (Renew)."
group: "Renew"
party: "Ren (FRA)"
country: "France"
language: "fr"
words: 161
position: mixed
topics: [Solidarity between Member States, Humanitarian situation and victims, Schengen and internal border controls, Instrumentalisation of migration]
fallacies: []
---

Speaker: [[Fabienne Keller]] · Group: [[Renew]] · Party: [[Ren (FRA)]] · Country: [[France]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 242 Fabienne Keller

> Fabienne Keller (Renew).

## Text

Monsieur le Président, Monsieur le Commissaire, chers collègues, la crise de Ceuta met en lumière une fracture européenne qui ne devrait pas exister. Face à de telles crises, nous devrions adopter une réponse européenne unie, ferme et solidaire.

Avant toute chose, la Commission, Monsieur le Commissaire, doit mener une enquête indépendante, transparente, pour faire toute la lumière sur les responsabilités et l'usage de la désinformation des réseaux sociaux.

Ensuite, nous devons continuer de soutenir l'Espagne financièrement et de manière opérationnelle sur le terrain avec deux priorités absolues: la protection des 1 500 mineurs non accompagnés actuellement bloqués là-bas, et le soutien aux habitants de Ceuta.

Face au défi migratoire, ne tombons pas dans la facilité de la division et du repli national. Les contrôles disproportionnés, inefficaces, imposés par l'Italie à l'Espagne doivent être levés. Lorsque l'Italie a été confrontée à la crise migratoire de Lampedusa en 2023, toute l'Europe était à ses côtés. Préservons, chers amis, notre unité. Agissons en responsabilité.

## Summary
Fabienne Keller calls for a united, firm and solidary European response, starting with an independent Commission investigation into responsibilities and social-media disinformation. She asks for continued financial and operational support to Spain, focused on the 1,500 unaccompanied minors and the residents, and demands that Italy lift its disproportionate controls on Spain, recalling European support for Italy at Lampedusa in 2023.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: mixed
- Justification: She wants a firm European response, but centred on solidarity, an investigation and the protection of minors rather than on border reinforcement.
- Quote: "nous devrions adopter une réponse européenne unie, ferme et solidaire" (translation by the agent: "we should adopt a united, firm and solidary European response")

## Entities
- [[Ceuta]]
- [[European Commission|la Commission]]
- [[Spain|l'Espagne]]
- [[Italy|l'Italie]]
- [[Lampedusa migration crisis (2023)|crise migratoire de Lampedusa en 2023]]

## Topics
- [[Solidarity between Member States]]
- [[Humanitarian situation and victims]]
- [[Schengen and internal border controls]]
- [[Instrumentalisation of migration]]

## Fallacies
None.
