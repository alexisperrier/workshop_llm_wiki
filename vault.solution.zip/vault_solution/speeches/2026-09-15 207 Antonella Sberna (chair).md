---
type: "intervention"
kind: "chair"
speech_id: "2017094943089"
order: 207
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "13:09:27"
end_time: "13:10:00"
speaker: "Antonella Sberna"
speaker_label: "Presidente."
group: "ECR"
party: "FdL (ITA)"
country: "Italy"
language: "it"
words: 35
topics: []
fallacies: []
---

Speaker: [[Antonella Sberna]] · Group: [[ECR]] · Party: [[FdL (ITA)]] · Country: [[Italy]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 207 Antonella Sberna (chair)

> Presidente.

## Text

L'ordine del giorno reca le dichiarazioni del Consiglio e della Commissione sui recenti attacchi ibridi e la strumentalizzazione dei migranti a Ceuta e necessità di una risposta coordinata per proteggere le frontiere esterne dell'UE (2026/2870(RSP))

## Summary
The chair opens the debate on the Council and Commission statements on the hybrid attacks and instrumentalisation of migrants in Ceuta.

## Entities
- [[Ceuta]]

## Topics
None.

## Fallacies
None.
