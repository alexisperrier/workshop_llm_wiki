---
type: "intervention"
kind: "speech"
speech_id: "2017094949420"
order: 271
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:42:39"
end_time: "14:44:00"
speaker: "Abir Al-Sahlani"
speaker_label: "Abir Al-Sahlani (Renew)."
group: "Renew"
party: "C (SWE)"
country: "Sweden"
language: "en"
words: 158
position: mixed
topics: [External border protection, Instrumentalisation of migration, Migrant smuggling, Humanitarian situation and victims, Schengen and internal border controls, Solidarity between Member States]
fallacies: []
---

Speaker: [[Abir Al-Sahlani]] · Group: [[Renew]] · Party: [[C (SWE)]] · Country: [[Sweden]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 271 Abir Al-Sahlani

> Abir Al-Sahlani (Renew).

## Text

Mr President, dear colleagues, what happened in Ceuta is serious. Europe must protect its borders, investigate this instrumentalisation, strengthen Frontex and dismantle the smugglers' networks. But why does every debate in this House about migration bring out the absolute worst in us, in our Union, in this House?

Migrants are not the enemies. They are victimised twice over, once by the smugglers and once by us in these kinds of debates. Europe can be firm without being cruel. We can be firm, but without being naive. Europe can be humane without losing our strength.

We already learned this lesson from Belarus, when they used migrants against the Polish borders. And we know that the answer is not fragmentation, nor is it suspension of the Schengen regime or fear and racism. We can defend our borders without losing our moral compass. Secure borders, European solidarity, human dignity: those are not contradictions. Those are the very strengths of our Union.

## Summary
Abir Al-Sahlani says Europe must protect its borders, investigate the instrumentalisation, strengthen Frontex and dismantle smugglers' networks, but asks why migration debates bring out the worst in Parliament. She says migrants are victimised twice, by smugglers and by such debates, recalls the lesson of Belarus against Poland, and rejects fragmentation, Schengen suspension, fear and racism.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: mixed
- Justification: She supports protecting the borders and a stronger Frontex, combined with solidarity and human dignity.
- Quote: "Secure borders, European solidarity, human dignity: those are not contradictions."

## Entities
- [[Ceuta]]
- [[Frontex]]
- [[Belarus]]
- [[Schengen Area|Schengen]]

## Topics
- [[External border protection]]
- [[Instrumentalisation of migration]]
- [[Migrant smuggling]]
- [[Humanitarian situation and victims]]
- [[Schengen and internal border controls]]
- [[Solidarity between Member States]]

## Fallacies
None.
