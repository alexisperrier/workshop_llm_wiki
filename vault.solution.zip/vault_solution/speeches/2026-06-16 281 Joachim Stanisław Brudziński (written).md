---
type: "intervention"
kind: "written"
speech_id: "2017084930529"
order: 281
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
speaker: "Joachim Stanisław Brudziński"
speaker_label: "Joachim Stanisław Brudziński (ECR), na piśmie."
group: "ECR"
party: "PiS (POL)"
country: "Poland"
language: "pl"
words: 197
position: supports
topics: [Returns, External border protection, Solidarity between Member States]
fallacies: []
---

Speaker: [[Joachim Stanisław Brudziński]] · Group: [[ECR]] · Party: [[PiS (POL)]] · Country: [[Poland]]
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-06-16 281 Joachim Stanisław Brudziński (written)

> Joachim Stanisław Brudziński (ECR), na piśmie.

## Text

Rozporządzenie powrotowe, czyli wspólny system powrotów obywateli państw trzecich nielegalnie przebywających w Unii – to temat dzisiejszej debaty, bardzo potrzebnej i to od dawna. Trudno dłużej udawać, że dotychczasowy system działa, trudno bez końca tuszować to co się dzieje na ulicach wielu miast Europy – gdzie po prostu giną ludzie – trudno zamiatać pod dywan narastające problemy które prowokują nielegalni migranci. I dlatego jest dzisiaj ta debata. Dlatego głosowanie na ten temat ma wysłać jasny sygnał: trzeba nazywać rzeczy po imieniu, trzeba uruchomić system powrotów nielegalnych – podkreślam nielegalnych migrantów do ich macierzystych państw. Do tej pory głównie udawano, że ten system działa, że można - zgodnie z prawem zresztą – odsyłać nielegalnych migrantów skąd przybyli. Ale wiemy jak ten system funkcjonował i funkcjonuje – jak by go nie w ogóle nie było. Gdyby działał, to nie było by dzisiaj tej debaty. Każde państwo musi mieć prawo do kontroli własnych granic. Nie ma mowy o przymusowych relokacjach w obszarze Unii. Agencja Frontex musi odzyskać prawo do tego, do czego została powołana: do ochrony naszych granic zewnętrznych. Trzeba skończyć z bezprawiem, a Ci którzy nielegalnie dostali się na teren Unii muszą mieć świadomość, że ich też obowiązuje prawo.

## Summary
In a written statement, Joachim Stanisław Brudziński says it is hard to pretend the current return system works, and that the vote must send a clear signal to return illegal migrants to their countries. He says every state must control its borders, rejects forced relocations, and wants Frontex to return to protecting the external borders.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He calls for launching an effective system of returns.
- Quote: "trzeba uruchomić system powrotów nielegalnych – podkreślam nielegalnych migrantów do ich macierzystych państw" (translation by the agent: "the system of returns of illegal – I stress illegal – migrants to their home countries must be launched")

## Entities
- [[Return Regulation|Rozporządzenie powrotowe]]
- [[Frontex]]

## Topics
- [[Returns]]
- [[External border protection]]
- [[Solidarity between Member States]]

## Fallacies
None.
