---
type: "intervention"
kind: "written"
speech_id: "2017096133634"
order: 290
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
speaker: "Emil Radev"
speaker_label: "Емил Радев (PPE), в писмена форма."
group: "PPE"
party: "GERB (BGR)"
country: "Bulgaria"
language: "bg"
words: 179
position: supports
topics: [External border protection, Pact on Migration and Asylum, Returns, Instrumentalisation of migration, Schengen and internal border controls]
fallacies: []
---

Speaker: [[Emil Radev]] · Group: [[PPE]] · Party: [[GERB (BGR)]] · Country: [[Bulgaria]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Written statement (Rule 178): not spoken in the chamber.

# 2026-09-15 290 Emil Radev (written)

> Емил Радев (PPE), в писмена форма.

## Text

Случилото се в Сеута не е само испански проблем. Когато под натиск е външна граница на една държава членка, под натиск е границата на целия Европейски съюз.Като представител на България, държава, която охранява една от най-чувствителните външни граници на ЕС, добре знам каква отговорност е това. Европа вече разбра и колко бързо миграционният натиск може да се промени и да бъде използван като инструмент за хибридна атака.Именно затова ЕНП последователно настоява да си върнем контрола върху миграцията. Нашата група бе двигател на реформата на европейската миграционна политика и през цялото време настоявахме за по-силни външни граници, укрепване на Frontex, пълно прилагане на новия Пакт за миграцията, особено мерките за бързи гранични процедури и ефективно връщане на хората без право на престой. Сеута показа защо тези решения не могат да останат само на хартия.Нуждаем се и от европейски механизъм за бърза реакция, включително при инструментализиране на миграцията, по-добро ранно предупреждение и реално сътрудничество с държавите на произход и транзит.Защитата на Шенген започва от защитата на външната граница. Ако искаме Европа без вътрешни граници, трябва да можем надеждно да пазим външните.

## Summary
In a written statement, Emil Radev says pressure on one Member State's external border is pressure on the whole EU, as Bulgaria knows. He says the EPP drove the migration reform, and calls for stronger external borders, a stronger Frontex, full implementation of the Pact with fast border procedures and returns, and a rapid response mechanism against instrumentalisation.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He says the protection of Schengen begins with the protection of the external border.
- Quote: "Защитата на Шенген започва от защитата на външната граница." (translation by the agent: "The protection of Schengen begins with the protection of the external border.")

## Entities
- [[Ceuta|Сеута]]
- [[Bulgaria|България]]
- [[PPE|ЕНП]]
- [[Frontex]]
- [[Pact on Migration and Asylum|Пакт за миграцията]]
- [[Schengen Area|Шенген]]

## Topics
- [[External border protection]]
- [[Pact on Migration and Asylum]]
- [[Returns]]
- [[Instrumentalisation of migration]]
- [[Schengen and internal border controls]]

## Fallacies
None.
