---
type: "intervention"
kind: "speech"
speech_id: "2017094949422"
order: 272
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:44:04"
end_time: "14:45:19"
speaker: "Ana Miguel Pedro"
speaker_label: "Ana Miguel Pedro (PPE)."
group: "PPE"
party: "CDS-PP (PRT)"
country: "Portugal"
language: "pt"
words: 182
position: supports
topics: [Responsibility of the Spanish government, Regularisation of migrants, EU-Morocco relations, Sovereignty of Ceuta and Melilla, External border protection, Solidarity between Member States]
fallacies: []
---

Speaker: [[Ana Miguel Pedro]] · Group: [[PPE]] · Party: [[CDS-PP (PRT)]] · Country: [[Portugal]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 272 Ana Miguel Pedro

> Ana Miguel Pedro (PPE).

## Text

Senhor Presidente, três dias antes, o presidente de Ceuta fez aquilo que Sanchez não fez: cumpriu o seu dever. E a resposta que recebeu foi de que não voltasse a ligar. Pode consentir‑se que o Estado terceiro decida, em função da sua conveniência política, quando abre ou fecha a pressão sobre uma fronteira externa da Europa? Oitenta mil pessoas não aparecem junto a uma fronteira por geração espontânea. Estará Sanchez mais preocupado em explicar aquilo que Marrocos não fez do que em explicar aquilo que o seu governo não fez? Porquê? Pode o governo espanhol avançar unilateralmente com uma regularização extraordinária, ignorar o efeito chamada e depois exigir solidariedade aos restantes Estados‑Membros?

Um governo que enfraquece deliberadamente a credibilidade da sua própria fronteira abre uma brecha na fronteira de toda a Europa. Pode a negligência ser nacional e a fatura europeia? Que governo é este que olha para os cidadãos de Ceuta e lhes diz: «habituem-se»? E qual é o plano para a próxima vez, quando Marrocos voltar a testar a soberania espanhola e a fronteira externa da Europa? Eu respondo: nenhum.

## Summary
Ana Miguel Pedro says the president of Ceuta did his duty three days before but was told not to call again, and that 80,000 people do not appear at a border spontaneously. She asks whether Spain can carry out a unilateral regularisation, ignore the pull factor and then demand solidarity, says a government that weakens its own border opens a breach for all of Europe, and that there is no plan for the next time Morocco tests the border.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She says a government that weakens its own border opens a breach in Europe's border.
- Quote: "Um governo que enfraquece deliberadamente a credibilidade da sua própria fronteira abre uma brecha na fronteira de toda a Europa." (translation by the agent: "A government that deliberately weakens the credibility of its own border opens a breach in the border of all of Europe.")

## Entities
- [[Ceuta]]
- [[Pedro Sánchez|Sanchez]]
- [[Morocco|Marrocos]]
- [[Government of Spain|governo espanhol]]

## Topics
- [[Responsibility of the Spanish government]]
- [[Regularisation of migrants]]
- [[EU-Morocco relations]]
- [[Sovereignty of Ceuta and Melilla]]
- [[External border protection]]
- [[Solidarity between Member States]]

## Fallacies
None.
