---
type: "intervention"
kind: "speech"
speech_id: "2017081987280"
order: 276
debate_id: "CRE-10-2026-06-16-ITM-011"
date: "2026-06-16"
start_time: "14:40:35"
end_time: "14:42:21"
speaker: "Magnus Brunner"
speaker_label: "Magnus Brunner, Member of the Commission."
language: "en"
words: 267
position: supports
topics: [Returns]
fallacies: []
---

Speaker: [[Magnus Brunner]] · Role: Member of the Commission
Debate: [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)]]

# 2026-06-16 276 Magnus Brunner

> Magnus Brunner, Member of the Commission.

## Text

Mr President, honourable Members, first of all, thanks very much for the debate.

To make that clear, it has nothing to do with politically being left or right. It has to do with pragmatism, and it is clear that for our migration and asylum systems to work, we need fast returns, effective returns of irregular migrants.

The new return regulation, in my view, does exactly this and gives us control over who can stay in the European Union and who needs to leave the European Union, while, of course, respecting human rights, people's rights, international law, of course – that is also in the regulation.

This is, I think, what the citizens in Europe expect, and this is what we are delivering. I think it's a really important part of the new chapter I was talking about and the new chapter we were working on.

Also, third countries have to play a role, of course. They also have an obligation to re-admit their citizens. And that's why we want to focus on the external dimension more in the next months. We should definitely use all our leverage that we have as a European Union, be it visa, be it trade, be it also financial tools, for example. And we should also develop new ones, definitely.

I think all together we should keep this momentum. There is no time to waste. So as soon as the regulation will be adopted, I will start working very closely with the Member States to apply the new rules.

So thank you very much for the debate again and all the best.

## Summary
In his closing remarks, Commissioner Brunner says the regulation is about pragmatism, not left or right: it gives the EU control over who stays and who leaves while respecting human rights and international law. He says third countries must readmit their citizens, that the EU should use visa, trade and financial leverage, and that he will work with Member States to apply the rules quickly.

## Position
- Question: Should Parliament adopt the Return Regulation in the version put to the vote?
- Position: supports
- Justification: He says the regulation delivers what citizens expect.
- Quote: "This is, I think, what the citizens in Europe expect, and this is what we are delivering."

## Entities
- [[Return Regulation|return regulation]]

## Topics
- [[Returns]]

## Fallacies
None.
