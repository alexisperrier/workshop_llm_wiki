---
type: "intervention"
kind: "speech"
speech_id: "2017094949374"
order: 247
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:14:55"
end_time: "14:16:40"
speaker: "Javier Zarzalejos"
speaker_label: "Javier Zarzalejos (PPE)."
group: "PPE"
party: "PP (ESP)"
country: "Spain"
language: "es"
words: 234
position: supports
topics: [Sovereignty of Ceuta and Melilla, Responsibility of the Spanish government, Pact on Migration and Asylum, Instrumentalisation of migration, EU-Morocco relations, External border protection, Humanitarian situation and victims]
fallacies: [HASTY_GENERALIZATION]
---

Speaker: [[Javier Zarzalejos]] · Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 247 Javier Zarzalejos

> Javier Zarzalejos (PPE).

## Text

Señor presidente, la verdad es que discutir sobre los hechos es delirante. Y hemos visto un ejemplo de delirio al negar la condición europea de Ceuta y Melilla. Ceuta y Melilla son españolas y lo van a seguir siendo.

Señor comisario, permítame algunas verdades incómodas: la frontera sur es hoy el eslabón débil en Europa. El Gobierno español no ha hecho absolutamente nada para la aplicación eficaz del Pacto sobre Migración y Asilo como demuestra lo ocurrido. La invasión de Ceuta no solo es un problema migratorio, es un ataque híbrido a la integridad territorial de España, como afirmó, por cierto, el presidente del Gobierno, el señor Sánchez.

Marruecos ni ha colaborado ni colaborará, señor comisario. No puede colaborar Marruecos cuando ni siquiera está autorizando que se repatrien los cuerpos de 140 víctimas que están siendo enterradas en el cementerio musulmán de Sidi Embarek, porque Marruecos no permite la repatriación de los cadáveres.

La situación es tan absurda y tan grotesca que después de que Marruecos deje entrar 80 000 personas en Ceuta, ¿a quién llama y a quién convoca el Gobierno de España? Al embajador de Italia. El hecho de que 70 000 personas hayan regresado a Marruecos no significa que Marruecos colabore, significa que Marruecos controla la frontera.

Por tanto, estamos ante una prueba crucial para la Unión Europea. Y no estamos en momentos para que Europa pierda credibilidad ante sus ciudadanos.

## Summary
Javier Zarzalejos says denying that Ceuta and Melilla are European is delirious, that the southern border is Europe's weak link and that the Spanish government has done nothing to implement the Pact. He calls the events a hybrid attack on Spain's territorial integrity, says Morocco does not cooperate and is not even allowing the repatriation of the bodies of 140 victims, and mocks the government for summoning Italy's ambassador.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: He presents the southern border as Europe's weak link and the crisis as an attack to be met.
- Quote: "la frontera sur es hoy el eslabón débil en Europa" (translation by the agent: "the southern border is today the weak link in Europe")

## Entities
- [[Ceuta]]
- [[Melilla]]
- [[Government of Spain|Gobierno español]]
- [[Pact on Migration and Asylum|Pacto sobre Migración y Asilo]]
- [[Spain|España]]
- [[Pedro Sánchez|señor Sánchez]]
- [[Morocco|Marruecos]]
- [[Sidi Embarek cemetery|cementerio musulmán de Sidi Embarek]]
- [[Italy|Italia]]

## Topics
- [[Sovereignty of Ceuta and Melilla]]
- [[Responsibility of the Spanish government]]
- [[Pact on Migration and Asylum]]
- [[Instrumentalisation of migration]]
- [[EU-Morocco relations]]
- [[External border protection]]
- [[Humanitarian situation and victims]]

## Fallacies
- [[HASTY_GENERALIZATION]] (borderline)
  - Quote: "El Gobierno español no ha hecho absolutamente nada para la aplicación eficaz del Pacto sobre Migración y Asilo como demuestra lo ocurrido." (translation by the agent: "The Spanish government has done absolutely nothing for the effective application of the Pact on Migration and Asylum, as what happened shows.")
  - Conclusion: The Spanish government has failed to apply the Pact.
  - Defect: A general claim of total inaction is drawn from a single event.
