---
type: "intervention"
kind: "speech"
speech_id: "2017094949408"
order: 265
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:35:07"
end_time: "14:36:15"
speaker: "Jadwiga Wiśniewska"
speaker_label: "Jadwiga Wiśniewska (ECR)."
group: "ECR"
party: "PiS (POL)"
country: "Poland"
language: "pl"
words: 115
position: supports
topics: [External border protection, Returns, Migrant smuggling, Solidarity between Member States, Regularisation of migrants, Schengen and internal border controls]
fallacies: [HASTY_GENERALIZATION]
---

Speaker: [[Jadwiga Wiśniewska]] · Group: [[ECR]] · Party: [[PiS (POL)]] · Country: [[Poland]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]

# 2026-09-15 265 Jadwiga Wiśniewska

> Jadwiga Wiśniewska (ECR).

## Text

Panie Przewodniczący! To, co wydarzyło się w Ceucie, to ostateczny dowód na fiasko obłąkańczej lewicowej polityki migracyjnej. Inwazja ponad 90 tysięcy nielegalnych migrantów zmieniła życie mieszkańców w koszmar. Przestępczość wzrosła o 600%. Napady, gwałty, rabunki i rozboje stały się codziennością. Ludzie boją się wychodzić z domów. Ostrzegaliśmy przed tym.

Gdy rząd Prawa i Sprawiedliwości skutecznie odpierał ataki migrantów na granicy z Białorusią, był zawzięcie atakowany. A dziś 22 kraje członkowskie zapowiadają przywrócenie kontroli granicznej. Dziś widać, kto miał rację. Europa zbyt długo ulegała lewicowemu szaleństwu.

Dlatego mówię „tak” dla szczelnych granic, skutecznych deportacji, walki z przemytnikami ludzi. „Nie” dla przymusowych relokacji, lewackich rządów i legalizacji milionów nielegalnych migrantów. Strefa Schengen nie może umrzeć w Ceucie.

## Summary
Jadwiga Wiśniewska calls Ceuta the final proof of the failure of 'insane' left-wing migration policy, citing an invasion of over 90,000 and a 600% rise in crime. She says Poland's PiS government was attacked for repelling migrants on the Belarus border and that 22 Member States now announce border controls, and says yes to sealed borders, deportations and the fight against smugglers, no to forced relocations and legalisations.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: supports
- Justification: She calls for sealed borders, effective deportations and the fight against smugglers.
- Quote: "mówię „tak” dla szczelnych granic, skutecznych deportacji, walki z przemytnikami ludzi" (translation by the agent: "I say yes to sealed borders, effective deportations, the fight against smugglers")

## Entities
- [[Ceuta|Ceucie]]
- [[PiS (POL)|Prawa i Sprawiedliwości]]
- [[Belarus|Białorusią]]
- [[Schengen Area|Strefa Schengen]]

## Topics
- [[External border protection]]
- [[Returns]]
- [[Migrant smuggling]]
- [[Solidarity between Member States]]
- [[Regularisation of migrants]]
- [[Schengen and internal border controls]]

## Fallacies
- [[HASTY_GENERALIZATION]] (clear)
  - Quote: "To, co wydarzyło się w Ceucie, to ostateczny dowód na fiasko obłąkańczej lewicowej polityki migracyjnej." (translation by the agent: "What happened in Ceuta is the final proof of the failure of insane left-wing migration policy.")
  - Conclusion: Left-wing migration policy has failed.
  - Defect: A general conclusion about a whole policy is drawn from a single case.
