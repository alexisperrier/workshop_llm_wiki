---
type: "intervention"
kind: "answer"
speech_id: "2017094949378"
order: 249
debate_id: "CRE-10-2026-09-15-ITM-007"
date: "2026-09-15"
start_time: "14:17:50"
end_time: "14:18:35"
speaker: "Javier Zarzalejos"
speaker_label: "Javier Zarzalejos (PPE), respuesta de «tarjeta azul»."
group: "PPE"
party: "PP (ESP)"
country: "Spain"
language: "es"
words: 110
position: not_stated
topics: [Solidarity between Member States, Returns]
fallacies: []
---

Speaker: [[Javier Zarzalejos]] · Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]
Debate: [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders]]
Replies to: [[2026-09-15 248 Anna Strolenberg (question)]]

# 2026-09-15 249 Javier Zarzalejos (answer)

> Javier Zarzalejos (PPE), respuesta de «tarjeta azul».

## Text

Si usted repasa las declaraciones que yo he hecho como presidente de LIBE, se dará cuenta de que siempre he puesto en valor la solidaridad europea, con un ordenamiento jurídico como el que hemos adoptado —que por cierto, el Gobierno de España votó en contra del Reglamento sobre el retorno, una de las piezas esenciales—, en segundo lugar, con la financiación que la Unión Europea ha ofrecido y, en tercer lugar, con la oferta que el comisario ha hecho reiteradamente para el despliegue de Frontex.

Por tanto, no ha fallado la solidaridad europea. Lo que pasa es que esa solidaridad no se ha ofrecido, o no se ha aceptado realmente.

## Summary
Answering Anna Strolenberg, Javier Zarzalejos says that as LIBE chair he has always valued European solidarity, through the legislation adopted, EU funding and the Commissioner's repeated offer of Frontex, and that the Spanish government voted against the Return Regulation. Solidarity did not fail; it was not accepted.

## Position
- Question: Should the EU respond to the events in Ceuta mainly by strengthening the protection of its external borders?
- Position: not stated
- Justification: The answer is about whether European solidarity failed.
- Quote: "no ha fallado la solidaridad europea" (translation by the agent: "European solidarity has not failed")

## Entities
- [[LIBE Committee|LIBE]]
- [[Government of Spain|Gobierno de España]]
- [[Return Regulation|Reglamento sobre el retorno]]
- [[Frontex]]

## Topics
- [[Solidarity between Member States]]
- [[Returns]]

## Fallacies
None.
