---
type: "group"
group_id: "6561"
label: "NI"
name: "Non-attached Members"
aliases: ["Non-attached Members", "non-inscrits"]
---

# NI

Non-attached Members: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- [[2026-09-15 232 Alvise Pérez|Alvise Pérez]] complains about insults in the chamber; [[2026-09-15 259 Alvise Pérez (question)|Alvise Pérez]] calls the regularisation an electoral coup.
- [[2026-09-15 276 Malika Sorel|Malika Sorel]] relays the president of Ceuta's demands: Frontex, money, the return of all arrivals and trade leverage on Morocco.

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- The only NI contribution is the written statement [[2026-06-16 280 Nikola Bartůšek (written)|Nikola Bartůšek]], which calls the regulation a necessary correction.
