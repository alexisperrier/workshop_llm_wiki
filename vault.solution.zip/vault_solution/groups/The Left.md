---
type: "group"
group_id: "7036"
label: "The Left"
name: "The Left - GUE/NGL"
aliases: ["The Left - GUE/NGL", "GUE/NGL", "The Left group"]
---

# The Left

The Left - GUE/NGL: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- The Left speakers blame Morocco and its foreign backers ([[2026-09-15 216 Estrella Galán|Estrella Galán]], [[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]], [[2026-09-15 267 Pernando Barrena Arza|Pernando Barrena Arza]]) and EU funding of Morocco ([[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]], [[2026-09-15 267 Pernando Barrena Arza|Pernando Barrena Arza]]).
- They reject the 'invasion' framing and treat migrants as victims ([[2026-09-15 226 Isabel Serra Sánchez|Isabel Serra Sánchez]], [[2026-09-15 228 Isabel Serra Sánchez (answer)|Isabel Serra Sánchez]]); [[2026-09-15 244 Ilaria Salis|Ilaria Salis]] and [[2026-09-15 246 Ilaria Salis (answer)|Ilaria Salis]] call Ceuta a colonial remnant.
- They ask for legal routes and transfers of vulnerable people ([[2026-09-15 216 Estrella Galán|Estrella Galán]]) and stand with the Spanish government ([[2026-09-15 257 Konstantinos Arvanitis|Konstantinos Arvanitis]]).

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 274 Estrella Galán|Estrella Galán]] calls the regulation a triple betrayal and vows to repeal it.
