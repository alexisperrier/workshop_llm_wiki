---
type: "group"
group_id: "7028"
label: "Verts/ALE"
name: "The Greens/European Free Alliance"
aliases: ["The Greens/European Free Alliance", "Verts/ALE", "Greens/EFA", "the Greens"]
---

# Verts-ALE

The Greens/European Free Alliance: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- Greens speakers centre the 141 dead and human dignity and reject the 'invasion' framing as playing into the instrumentalisers' hands ([[2026-09-15 215 Erik Marquardt|Erik Marquardt]], [[2026-09-15 243 Tineke Strik|Tineke Strik]]).
- They say the promised solidarity failed as leaders closed borders and blamed Spain ([[2026-09-15 243 Tineke Strik|Tineke Strik]], [[2026-09-15 280 Anna Strolenberg|Anna Strolenberg]]), and accuse the right of racism ([[2026-09-15 256 Ana Miranda Paz|Ana Miranda Paz]]).
- [[2026-09-15 254 Tineke Strik (question)|Tineke Strik]] questions the rapporteur of the return rules on return hubs.

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 273 Mélissa Camara|Mélissa Camara]] calls for a vote against the regulation, describing the Italian centre in Albania and the absence of rights monitoring.
