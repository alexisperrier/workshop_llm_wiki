---
type: "group"
group_id: "7035"
label: "Renew"
name: "Renew Europe"
aliases: ["Renew Europe"]
---

# Renew

Renew Europe: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- Renew speakers accept firm border management, a more proactive Frontex and returns within the law ([[2026-09-15 224 Oihane Agirregoitia Martínez|Oihane Agirregoitia Martínez]], [[2026-09-15 253 Malik Azmani|Malik Azmani]], [[2026-09-15 266 Jan-Christoph Oetjen|Jan-Christoph Oetjen]], [[2026-09-15 271 Abir Al-Sahlani|Abir Al-Sahlani]]).
- They ask for facts and an independent inquiry into disinformation ([[2026-09-15 214 Veronika Cifrová Ostrihoňová|Veronika Cifrová Ostrihoňová]], [[2026-09-15 242 Fabienne Keller|Fabienne Keller]], [[2026-09-15 253 Malik Azmani|Malik Azmani]]) and for protection of the unaccompanied minors ([[2026-09-15 242 Fabienne Keller|Fabienne Keller]], [[2026-09-15 253 Malik Azmani|Malik Azmani]]).
- They criticise Italy's internal border controls and ask for European unity ([[2026-09-15 242 Fabienne Keller|Fabienne Keller]], [[2026-09-15 266 Jan-Christoph Oetjen|Jan-Christoph Oetjen]], [[2026-09-15 271 Abir Al-Sahlani|Abir Al-Sahlani]]).

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- The group is divided: the rapporteur [[2026-06-16 266 Malik Azmani|Malik Azmani]] defends the regulation as balanced and lawful ([[2026-06-16 277 Malik Azmani|Malik Azmani]]), [[2026-06-16 272 Fabienne Keller|Fabienne Keller]] opposes it for families with children, and [[2026-06-16 283 Katri Kulmuni (written)|Katri Kulmuni]] supports its goals with reservations.
