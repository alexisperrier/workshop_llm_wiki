---
type: "group"
group_id: "7018"
label: "PPE"
name: "Group of the European People's Party (Christian Democrats)"
aliases: ["Group of the European People's Party (Christian Democrats)", "EPP", "EPP Group", "European People's Party", "Partido Popular Europeo", "Európai Néppárt", "ЕНП"]
---

# PPE

Group of the European People's Party (Christian Democrats): political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- The PPE speakers frame Ceuta as a hybrid attack on Spain's territorial integrity: 'Ceuta is Spain, Ceuta is Europe' ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 234 Lena Düpont|Lena Düpont]], [[2026-09-15 247 Javier Zarzalejos|Javier Zarzalejos]]).
- They hold Pedro Sánchez's government responsible for ignoring warnings, carrying out mass regularisations and failing to apply the Pact ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 258 François-Xavier Bellamy|François-Xavier Bellamy]], [[2026-09-15 272 Ana Miguel Pedro|Ana Miguel Pedro]], [[2026-09-15 277 Juan Ignacio Zoido Álvarez|Juan Ignacio Zoido Álvarez]]).
- Their answer is a stronger Frontex, an emergency mechanism, full implementation of the Pact and returns, including of minors ([[2026-09-15 210 Jeroen Lenaers|Jeroen Lenaers]], [[2026-09-15 219 Dolors Montserrat|Dolors Montserrat]], [[2026-09-15 290 Emil Radev (written)|Emil Radev]]).
- [[2026-09-15 268 Bartłomiej Sienkiewicz|Bartłomiej Sienkiewicz]] argues that a mass storming cannot be handled under individual asylum law; [[2026-09-15 274 Alma Ezcurra Almansa|Alma Ezcurra Almansa]] calls it aggression and asks for the same response as to Belarus.

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 268 François-Xavier Bellamy|François-Xavier Bellamy]] presents the regulation as ending decades of powerlessness and says the final text is based on the one he proposed for the EPP.
