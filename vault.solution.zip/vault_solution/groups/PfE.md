---
type: "group"
group_id: "7150"
label: "PfE"
name: "Patriots"
aliases: ["Patriots", "Patriots for Europe", "Patrióták"]
---

# PfE

Patriots: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- PfE speakers call the events an invasion, territorial ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]]) or Islamic ([[2026-09-15 238 Susanna Ceccardi|Susanna Ceccardi]]), and blame the Spanish socialist government ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]], [[2026-09-15 222 Kinga Gál|Kinga Gál]], [[2026-09-15 264 Anna Bryłka|Anna Bryłka]], [[2026-09-15 279 Silvia Sardone|Silvia Sardone]]).
- They demand sanctions on Morocco ([[2026-09-15 212 Jorge Buxadé Villalba|Jorge Buxadé Villalba]]), restoring and sealing the border and expelling illegal migrants ([[2026-09-15 251 Fabrice Leggeri|Fabrice Leggeri]], [[2026-09-15 264 Anna Bryłka|Anna Bryłka]]), and Spain's exclusion from Schengen ([[2026-09-15 264 Anna Bryłka|Anna Bryłka]]).
- [[2026-09-15 235 András László (question)|András László]] uses a blue card to attack the EPP over Hungary's fine.

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 270 Fabrice Leggeri|Fabrice Leggeri]] welcomes 24-month detention, non-suspensive appeals and return hubs, and says the vote shows what the right of the House can achieve together.
