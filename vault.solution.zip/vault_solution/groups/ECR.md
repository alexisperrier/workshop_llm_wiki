---
type: "group"
group_id: "7037"
label: "ECR"
name: "European Conservatives and Reformists"
aliases: ["European Conservatives and Reformists", "ECR Group"]
---

# ECR

European Conservatives and Reformists: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- ECR speakers describe insecurity and crime in Ceuta and blame the Sánchez government and its regularisations ([[2026-09-15 213 Diego Solier|Diego Solier]], [[2026-09-15 241 Nora Junco García|Nora Junco García]], [[2026-09-15 252 Alessandro Ciriani|Alessandro Ciriani]], [[2026-09-15 262 Nicolas Bay (question)|Nicolas Bay]], [[2026-09-15 270 Marion Maréchal|Marion Maréchal]]).
- They call for defending the southern border, sealed borders or walls, and deportations ([[2026-09-15 213 Diego Solier|Diego Solier]], [[2026-09-15 265 Jadwiga Wiśniewska|Jadwiga Wiśniewska]], [[2026-09-15 278 Sebastian Tynkkynen|Sebastian Tynkkynen]]), and for a reinforced Frontex ([[2026-09-15 289 Rihards Kols (written)|Rihards Kols]]).
- [[2026-09-15 223 Assita Kanko|Assita Kanko]] asks the EPP to work with the groups on its right; [[2026-09-15 270 Marion Maréchal|Marion Maréchal]] praises Italy for closing its border to Spain.
- Several written statements stress instrumentalisation and the failure of EU funds to Morocco ([[2026-09-15 285 Nikola Bartůšek (written)|Nikola Bartůšek]], [[2026-09-15 286 Joachim Stanisław Brudziński (written)|Joachim Stanisław Brudziński]], [[2026-09-15 289 Rihards Kols (written)|Rihards Kols]]).

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- ECR speakers welcome return hubs, unlimited entry bans and detention ([[2026-06-16 271 Charlie Weimers|Charlie Weimers]], [[2026-06-16 282 Mariusz Kamiński (written)|Mariusz Kamiński]]), and reject relocation ([[2026-06-16 281 Joachim Stanisław Brudziński (written)|Joachim Stanisław Brudziński]], [[2026-06-16 282 Mariusz Kamiński (written)|Mariusz Kamiński]]); [[2026-06-16 285 Ivaylo Valchev (written)|Ivaylo Valchev]] blames the left for the delay.
