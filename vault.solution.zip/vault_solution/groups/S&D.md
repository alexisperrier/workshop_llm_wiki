---
type: "group"
group_id: "7038"
label: "S&D"
name: "Group of the Progressive Alliance of Socialists and Democrats in the European Parliament"
aliases: ["Group of the Progressive Alliance of Socialists and Democrats in the European Parliament", "Socialists and Democrats", "S&D Group"]
---

# S&D

Group of the Progressive Alliance of Socialists and Democrats in the European Parliament: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- S&D speakers mourn the dead, say Ceuta is Spain and Europe, and accuse the PPE and the right of exploiting the crisis ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]], [[2026-09-15 237 Birgit Sippel (question)|Birgit Sippel]], [[2026-09-15 261 Murielle Laurent|Murielle Laurent]]).
- They defend the Spanish government's response within the law and ask for European solidarity, which they say was lacking ([[2026-09-15 221 Ana Catarina Mendes|Ana Catarina Mendes]], [[2026-09-15 261 Murielle Laurent|Murielle Laurent]], [[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]).
- They condemn Italy's border controls on Spain ([[2026-09-15 211 Iratxe García Pérez|Iratxe García Pérez]], [[2026-09-15 250 Sandro Ruotolo (question)|Sandro Ruotolo]], [[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]) and ask for protection of the unaccompanied minors ([[2026-09-15 261 Murielle Laurent|Murielle Laurent]], [[2026-09-15 273 Juan Fernando López Aguilar|Juan Fernando López Aguilar]]).
- [[2026-09-15 269 Eero Heinäluoma|Eero Heinäluoma]], from Finland, calls for joint border surveillance and support for Spain without blame; [[2026-09-15 263 Murielle Laurent (answer)|Murielle Laurent]] defends the regularisations.

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 269 Murielle Laurent|Murielle Laurent]] accepts a return policy in principle but opposes the text for allowing detention of minors and families, returns to unsafe countries and return hubs.
