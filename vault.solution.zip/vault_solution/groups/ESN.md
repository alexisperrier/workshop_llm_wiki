---
type: "group"
group_id: "7151"
label: "ESN"
name: "Sovereignists"
aliases: ["Sovereignists", "Europe of Sovereign Nations"]
---

# ESN

Sovereignists: political group of the European Parliament.

## In the debates

### [[The recent hybrid attacks and instrumentalisation of migrants in Ceuta and the need for a coordinated response to protect the EU’s external borders|Ceuta (15 September 2026)]]

- ESN speakers describe Ceuta as a slum hit by crime and blame Sánchez's policy ([[2026-09-15 217 Mary Khan|Mary Khan]], [[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]]).
- They want Morocco's EU funds cut or repaid ([[2026-09-15 217 Mary Khan|Mary Khan]], [[2026-09-15 288 Tomasz Froelich (written)|Tomasz Froelich]]), physical barriers financed ([[2026-09-15 229 Roberto Vannacci|Roberto Vannacci]], [[2026-09-15 231 Roberto Vannacci (answer)|Roberto Vannacci]]) and borders physically protected ([[2026-09-15 291 Marcin Sypniewski (written)|Marcin Sypniewski]]).

### [[Common system for the return of third-country nationals staying illegally in the Union (Return Regulation)|Return Regulation (16 June 2026)]]

- [[2026-06-16 275 Mary Khan|Mary Khan]] calls the regulation a turning point and [[2026-06-16 284 Marcin Sypniewski (written)|Marcin Sypniewski]] supports its detention and entry-ban rules.
