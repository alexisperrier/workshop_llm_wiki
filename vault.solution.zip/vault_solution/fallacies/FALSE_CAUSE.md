---
type: fallacy
control_code: false
aliases: []
---
# FALSE_CAUSE

Source: fallacy_detection_codebook.md (draft v0.1).

A causal link is asserted from mere sequence or correlation, or a single cause is given for an outcome with several causes, and the conclusion depends on it.
