---
type: fallacy
control_code: false
aliases: []
---
# AD_HOMINEM

Source: fallacy_detection_codebook.md (draft v0.1).

A claim or position is rejected **because of** an attack on the character, motives, identity or affiliation of a person or group, instead of on the argument. An insult alone, with no argument being rejected, is not enough.
