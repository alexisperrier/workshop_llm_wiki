---
type: fallacy
control_code: false
aliases: []
---
# STRAW_MAN

Source: fallacy_detection_codebook.md (draft v0.1).

The speaker attributes to an identifiable opponent a position they did not hold, or an exaggerated version of it, **and then rebuts that version**.
