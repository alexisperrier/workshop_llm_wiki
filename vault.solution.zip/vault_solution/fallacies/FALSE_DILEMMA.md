---
type: fallacy
control_code: false
aliases: []
---
# FALSE_DILEMMA

Source: fallacy_detection_codebook.md (draft v0.1).

Only two options are presented as exhaustive when obvious alternatives exist, **and** the choice is used to support a conclusion.
