---
type: fallacy
control_code: true
aliases: []
---
# UNSUPPORTED_ASSERTION

Source: fallacy_detection_codebook.md (draft v0.1).

A strong claim stated without support.

**This is a control code, not a fallacy.** It exists so that sweeping claims are not labelled `HASTY_GENERALIZATION` by default.
