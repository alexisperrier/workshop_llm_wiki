---
type: fallacy
control_code: false
aliases: []
---
# SLIPPERY_SLOPE

Source: fallacy_detection_codebook.md (draft v0.1).

A measure is opposed because it will set off a chain of increasingly bad consequences, with the intermediate steps asserted rather than supported.
