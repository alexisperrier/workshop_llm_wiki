---
type: fallacy
control_code: false
aliases: []
---
# HASTY_GENERALIZATION

Source: fallacy_detection_codebook.md (draft v0.1).

A general claim is drawn **from one or a few cases cited in the text**. A sweeping claim with no cited case is not this code: use `UNSUPPORTED_ASSERTION`.
