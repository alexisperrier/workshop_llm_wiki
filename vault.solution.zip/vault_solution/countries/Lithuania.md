---
type: country
aliases: ["LTU", "Lituania"]
---
# Lithuania

EU Member State on the Baltic Sea.
