---
type: "country"
code: "FIN"
aliases: ["FIN", "Suomen", "Finlandia"]
---

# Finland
