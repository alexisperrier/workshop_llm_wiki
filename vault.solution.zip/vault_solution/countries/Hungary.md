---
type: "country"
code: "HUN"
aliases: ["HUN", "Magyarországnak", "Magyarországra", "Ungarn"]
---

# Hungary
