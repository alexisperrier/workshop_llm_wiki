---
type: country
aliases: ["MAR", "Marruecos", "Marokko", "Marrocos", "Reino de Marruecos", "le Maroc", "Marokkaanse", "Maroka", "Marokiem"]
---
# Morocco

Country in North Africa bordering the Spanish cities of Ceuta and Melilla.
