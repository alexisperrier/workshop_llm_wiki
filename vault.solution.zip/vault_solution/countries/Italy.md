---
type: "country"
code: "ITA"
aliases: ["ITA", "Italia", "l'Italie", "L'Italia", "Italien", "gouvernement italien", "italien"]
---

# Italy
