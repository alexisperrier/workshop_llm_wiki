---
type: "country"
code: "BEL"
aliases: ["BEL", "Bélgica"]
---

# Belgium
