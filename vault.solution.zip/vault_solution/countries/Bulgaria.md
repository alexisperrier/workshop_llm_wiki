---
type: "country"
code: "BGR"
aliases: ["BGR", "България"]
---

# Bulgaria
