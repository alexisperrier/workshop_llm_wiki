---
type: country
aliases: ["DZA", "Algerien", "algérien"]
---
# Algeria

Country in North Africa.
