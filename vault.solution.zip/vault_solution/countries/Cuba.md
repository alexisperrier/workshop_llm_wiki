---
type: country
aliases: ["CUB"]
---
# Cuba

Country in the Caribbean.
