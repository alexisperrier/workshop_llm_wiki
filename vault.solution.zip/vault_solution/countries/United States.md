---
type: country
aliases: ["USA", "Estados Unidos", "États-Unis"]
---
# United States

Country in North America.
