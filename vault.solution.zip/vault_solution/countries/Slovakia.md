---
type: "country"
code: "SVK"
aliases: ["SVK"]
---

# Slovakia
