---
type: "country"
code: "DEU"
aliases: ["DEU", "Alemania", "Deutschland"]
---

# Germany
