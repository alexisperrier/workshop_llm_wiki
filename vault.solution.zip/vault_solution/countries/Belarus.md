---
type: country
aliases: ["BLR", "Białorusią", "Bielorrusia", "białoruski"]
---
# Belarus

Country in Eastern Europe bordering Poland, Lithuania and Latvia.
