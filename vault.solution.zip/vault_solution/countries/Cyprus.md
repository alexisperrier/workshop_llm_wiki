---
type: "country"
code: "CYP"
aliases: ["CYP"]
---

# Cyprus
