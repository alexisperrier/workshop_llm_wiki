---
type: "country"
code: "CZE"
aliases: ["CZE"]
---

# Czechia
