---
type: "country"
code: "GRC"
aliases: ["GRC", "Ελλάδα"]
---

# Greece
