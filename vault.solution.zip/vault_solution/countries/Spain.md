---
type: "country"
code: "ESP"
aliases: ["ESP", "España", "Espagne", "Spanien", "Spaniens", "Spanyolország", "spagnolo", "Spagna", "l'Espagne", "Ισπανία", "Hiszpania", "Espanjan"]
---

# Spain
