---
type: country
aliases: ["RUS", "russi", "Venäjä"]
---
# Russia

Country in Eastern Europe and Asia.
