---
type: "country"
code: "POL"
aliases: ["POL", "Polonia", "Polska"]
---

# Poland
