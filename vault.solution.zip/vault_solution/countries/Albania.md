---
type: country
aliases: ["ALB", "Albanie"]
---
# Albania

Country in the Western Balkans.
