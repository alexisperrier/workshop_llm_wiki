---
type: "country"
code: "LVA"
aliases: ["LVA"]
---

# Latvia
