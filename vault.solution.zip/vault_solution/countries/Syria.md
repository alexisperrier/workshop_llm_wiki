---
type: country
aliases: ["SYR"]
---
# Syria

Country in the Middle East.
