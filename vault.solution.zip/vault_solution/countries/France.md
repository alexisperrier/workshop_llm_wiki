---
type: "country"
code: "FRA"
aliases: ["FRA", "Francia"]
---

# France
