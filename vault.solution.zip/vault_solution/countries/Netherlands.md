---
type: "country"
code: "NLD"
aliases: ["NLD"]
---

# Netherlands
