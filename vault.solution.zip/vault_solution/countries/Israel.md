---
type: country
aliases: ["ISR"]
---
# Israel

Country in the Middle East.
