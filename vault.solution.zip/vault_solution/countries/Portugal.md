---
type: "country"
code: "PRT"
aliases: ["PRT"]
---

# Portugal
