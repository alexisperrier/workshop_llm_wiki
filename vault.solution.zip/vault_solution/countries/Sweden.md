---
type: "country"
code: "SWE"
aliases: ["SWE"]
---

# Sweden
