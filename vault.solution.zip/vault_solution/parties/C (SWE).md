---
type: "party"
party_id: "6716"
label: "C"
name: "C"
country: "Sweden"
aliases: ["C"]
---

Country: [[Sweden]] · Group: [[Renew]]

# C (SWE)

National party: C.
