---
type: "party"
party_id: "6702"
label: "PiS"
name: "PiS"
country: "Poland"
aliases: ["PiS", "Prawa i Sprawiedliwości"]
---

Country: [[Poland]] · Group: [[ECR]]

# PiS (POL)

National party: PiS.
