---
type: "party"
party_id: "6774"
label: "FDP"
name: "FDP"
country: "Germany"
aliases: ["FDP"]
---

Country: [[Germany]] · Group: [[Renew]]

# FDP (DEU)

National party: FDP.
