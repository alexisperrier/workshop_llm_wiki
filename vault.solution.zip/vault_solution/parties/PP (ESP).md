---
type: "party"
party_id: "6666"
label: "PP"
name: "PP"
country: "Spain"
aliases: ["PP", "Partido Popular"]
---

Country: [[Spain]] · Group: [[PPE]]

# PP (ESP)

National party: PP.
