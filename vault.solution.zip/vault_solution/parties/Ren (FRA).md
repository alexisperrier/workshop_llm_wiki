---
type: "party"
party_id: "6935"
label: "Ren"
name: "Renaissance"
country: "France"
aliases: ["Ren", "Renaissance"]
---

Country: [[France]] · Group: [[Renew]]

# Ren (FRA)

National party: Renaissance.
