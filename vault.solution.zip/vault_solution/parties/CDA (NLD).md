---
type: "party"
party_id: "6697"
label: "CDA"
name: "CDA"
country: "Netherlands"
aliases: ["CDA"]
---

Country: [[Netherlands]] · Group: [[PPE]]

# CDA (NLD)

National party: CDA.
