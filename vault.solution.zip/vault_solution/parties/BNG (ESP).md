---
type: "party"
party_id: "6844"
label: "BNG"
name: "BNG"
country: "Spain"
aliases: ["BNG"]
---

Country: [[Spain]] · Group: [[Verts-ALE]]

# BNG (ESP)

National party: BNG.
