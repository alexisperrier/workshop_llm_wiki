---
type: "party"
party_id: "6831"
label: "FdL"
name: "Fratelli d'Italia"
country: "Italy"
aliases: ["FdL", "Fratelli d'Italia"]
---

Country: [[Italy]] · Group: [[ECR]]

# FdL (ITA)

National party: Fratelli d'Italia.
