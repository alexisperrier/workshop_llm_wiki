---
type: "party"
party_id: "6773"
label: "GRÜNE."
name: "GRÜNE."
country: "Germany"
aliases: ["GRÜNE."]
---

Country: [[Germany]] · Group: [[Verts-ALE]]

# GRÜNE. (DEU)

National party: GRÜNE..
