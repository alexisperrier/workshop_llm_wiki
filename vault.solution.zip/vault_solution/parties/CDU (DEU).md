---
type: "party"
party_id: "6771"
label: "CDU"
name: "CDU"
country: "Germany"
aliases: ["CDU"]
---

Country: [[Germany]] · Group: [[PPE]]

# CDU (DEU)

National party: CDU.
