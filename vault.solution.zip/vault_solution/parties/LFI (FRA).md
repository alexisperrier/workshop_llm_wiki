---
type: "party"
party_id: "6878"
label: "LFI"
name: "La France Insoumise"
country: "France"
aliases: ["LFI", "La France Insoumise"]
---

Country: [[France]] · Group: [[The Left]]

# LFI (FRA)

National party: La France Insoumise.
