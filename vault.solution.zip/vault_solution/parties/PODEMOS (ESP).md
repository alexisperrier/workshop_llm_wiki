---
type: "party"
party_id: "6811"
label: "PODEMOS"
name: "PODEMOS"
country: "Spain"
aliases: ["PODEMOS"]
---

Country: [[Spain]] · Group: [[The Left]]

# PODEMOS (ESP)

National party: PODEMOS.
