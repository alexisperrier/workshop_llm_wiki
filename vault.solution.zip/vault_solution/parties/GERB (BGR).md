---
type: "party"
party_id: "6761"
label: "GERB"
name: "GERB"
country: "Bulgaria"
aliases: ["GERB"]
---

Country: [[Bulgaria]] · Group: [[PPE]]

# GERB (BGR)

National party: GERB.
