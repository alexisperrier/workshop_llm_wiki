---
type: "party"
party_id: "7026"
label: "PdF"
name: "PdF"
country: "Germany"
aliases: ["PdF"]
---

Country: [[Germany]] · Group: [[Renew]]

# PdF (DEU)

National party: PdF.
