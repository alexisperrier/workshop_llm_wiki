---
type: "party"
party_id: "6670"
label: "Perus"
name: "Perus"
country: "Finland"
aliases: ["Perus"]
---

Country: [[Finland]] · Group: [[ECR]]

# Perus (FIN)

National party: Perus.
