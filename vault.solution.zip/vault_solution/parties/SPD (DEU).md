---
type: "party"
party_id: "6772"
label: "SPD"
name: "SPD"
country: "Germany"
aliases: ["SPD"]
---

Country: [[Germany]] · Group: [[S&D]]

# SPD (DEU)

National party: SPD.
