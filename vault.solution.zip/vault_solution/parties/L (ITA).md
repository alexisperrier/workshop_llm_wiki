---
type: "party"
party_id: "6870"
label: "L"
name: "Lega"
country: "Italy"
aliases: ["L", "Lega"]
---

Country: [[Italy]] · Group: [[PfE]]

# L (ITA)

National party: Lega.
