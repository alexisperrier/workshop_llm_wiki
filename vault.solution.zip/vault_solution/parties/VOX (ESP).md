---
type: "party"
party_id: "6871"
label: "VOX"
name: "VOX"
country: "Spain"
aliases: ["VOX"]
---

Country: [[Spain]] · Group: [[PfE]]

# VOX (ESP)

National party: VOX.
