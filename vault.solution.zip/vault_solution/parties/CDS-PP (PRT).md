---
type: "party"
party_id: "6879"
label: "CDS-PP"
name: "CDS-PP"
country: "Portugal"
aliases: ["CDS-PP"]
---

Country: [[Portugal]] · Group: [[PPE]]

# CDS-PP (PRT)

National party: CDS-PP.
