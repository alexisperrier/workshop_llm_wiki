---
type: "party"
party_id: "6725"
label: "KESK"
name: "KESK"
country: "Finland"
aliases: ["KESK"]
---

Country: [[Finland]] · Group: [[Renew]]

# KESK (FIN)

National party: KESK.
