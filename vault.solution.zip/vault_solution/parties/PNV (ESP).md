---
type: "party"
party_id: "6820"
label: "PNV"
name: "PNV"
country: "Spain"
aliases: ["PNV"]
---

Country: [[Spain]] · Group: [[Renew]]

# PNV (ESP)

National party: PNV.
