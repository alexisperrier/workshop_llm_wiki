---
type: "party"
party_id: "6802"
label: "AfD"
name: "AfD"
country: "Germany"
aliases: ["AfD"]
---

Country: [[Germany]] · Group: [[ESN]]

# AfD (DEU)

National party: AfD.
