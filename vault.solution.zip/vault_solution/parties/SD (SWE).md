---
type: "party"
party_id: "6810"
label: "SD"
name: "SD"
country: "Sweden"
aliases: ["SD"]
---

Country: [[Sweden]] · Group: [[ECR]]

# SD (SWE)

National party: SD.
