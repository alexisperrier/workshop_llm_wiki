---
type: "party"
party_id: "6953"
label: "Les Écologistes"
name: "Les Écologistes"
country: "France"
aliases: ["Les Écologistes"]
---

Country: [[France]] · Group: [[Verts-ALE]]

# Les Écologistes (FRA)

National party: Les Écologistes.
