---
type: "party"
party_id: "6667"
label: "PSOE"
name: "PSOE"
country: "Spain"
aliases: ["PSOE", "Partido Socialista"]
---

Country: [[Spain]] · Group: [[S&D]]

# PSOE (ESP)

National party: PSOE.
