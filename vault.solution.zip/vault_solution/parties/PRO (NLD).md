---
type: "party"
party_id: "8001"
label: "PRO"
name: "PRO"
country: "Netherlands"
aliases: ["PRO"]
---

Country: [[Netherlands]] · Group: [[Verts-ALE]]

# PRO (NLD)

National party: PRO.
