---
type: "party"
party_id: "7979"
label: "KO"
name: "KO"
country: "Poland"
aliases: ["KO"]
---

Country: [[Poland]] · Group: [[PPE]]

# KO (POL)

National party: KO.
