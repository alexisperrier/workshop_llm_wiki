---
type: "party"
party_id: "6848"
label: "RN"
name: "Rassemblement"
country: "France"
aliases: ["RN", "Rassemblement"]
---

Country: [[France]] · Group: [[PfE]]

# RN (FRA)

National party: Rassemblement.
