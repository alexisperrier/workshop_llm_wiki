---
type: "party"
party_id: "6812"
label: "EH BILDU"
name: "EH BILDU"
country: "Spain"
aliases: ["EH BILDU"]
---

Country: [[Spain]] · Group: [[The Left]]

# EH BILDU (ESP)

National party: EH BILDU.
