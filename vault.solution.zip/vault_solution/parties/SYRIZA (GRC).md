---
type: "party"
party_id: "6731"
label: "SYRIZA"
name: "SYRIZA"
country: "Greece"
aliases: ["SYRIZA"]
---

Country: [[Greece]] · Group: [[The Left]]

# SYRIZA (GRC)

National party: SYRIZA.
