---
type: "party"
party_id: "6706"
label: "PS"
name: "PS"
country: "Portugal"
aliases: ["PS"]
---

Country: [[Portugal]] · Group: [[S&D]]

# PS (PRT)

National party: PS.
