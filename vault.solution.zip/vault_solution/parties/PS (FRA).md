---
type: "party"
party_id: "6728"
label: "PS"
name: "PS"
country: "France"
aliases: ["PS"]
---

Country: [[France]] · Group: [[S&D]]

# PS (FRA)

National party: PS.
