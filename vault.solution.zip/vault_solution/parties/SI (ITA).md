---
type: "party"
party_id: "8000"
label: "SI"
name: "SI"
country: "Italy"
aliases: ["SI"]
---

Country: [[Italy]] · Group: [[The Left]]

# SI (ITA)

National party: SI.
