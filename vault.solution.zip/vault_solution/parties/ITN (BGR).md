---
type: "party"
party_id: "6931"
label: "ITN"
name: "ITN"
country: "Bulgaria"
aliases: ["ITN"]
---

Country: [[Bulgaria]] · Group: [[ECR]]

# ITN (BGR)

National party: ITN.
