---
type: "party"
party_id: "6874"
label: "PS"
name: "Progresívne Slovensko"
country: "Slovakia"
aliases: ["PS", "Progresívne Slovensko"]
---

Country: [[Slovakia]] · Group: [[Renew]]

# PS (SVK)

National party: Progresívne Slovensko.
