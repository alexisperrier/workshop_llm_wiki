---
type: "party"
party_id: "6856"
label: "Konfederacja"
name: "Konfederacja"
country: "Poland"
aliases: ["Konfederacja"]
---

Country: [[Poland]] · Group: [[ESN]] · Group: [[PfE]]

# Konfederacja (POL)

National party: Konfederacja.
