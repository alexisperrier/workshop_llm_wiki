---
type: "party"
party_id: "7993"
label: "FN"
name: "FN"
country: "Italy"
aliases: ["FN"]
---

Country: [[Italy]] · Group: [[ESN]]

# FN (ITA)

National party: FN.
