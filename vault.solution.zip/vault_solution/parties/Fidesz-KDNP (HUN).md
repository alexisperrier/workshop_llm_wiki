---
type: "party"
party_id: "6737"
label: "Fidesz-KDNP"
name: "Fidesz-KDNP"
country: "Hungary"
aliases: ["Fidesz-KDNP"]
---

Country: [[Hungary]] · Group: [[PfE]]

# Fidesz-KDNP (HUN)

National party: Fidesz-KDNP.
