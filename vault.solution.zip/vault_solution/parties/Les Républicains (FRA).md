---
type: "party"
party_id: "6827"
label: "Les Républicains"
name: "Les Républicains"
country: "France"
aliases: ["Les Républicains"]
---

Country: [[France]] · Group: [[PPE]]

# Les Républicains (FRA)

National party: Les Républicains.
