---
type: "party"
party_id: "6816"
label: "PSC-PSOE"
name: "Partit dels Socialistes de Catalunya (PSC-PSOE)"
country: "Spain"
aliases: ["PSC-PSOE", "Partit dels Socialistes de Catalunya (PSC-PSOE)"]
---

Country: [[Spain]] · Group: [[S&D]]

# PSC-PSOE (ESP)

National party: Partit dels Socialistes de Catalunya (PSC-PSOE).
