---
type: "party"
party_id: "6691"
label: "VVD"
name: "VVD"
country: "Netherlands"
aliases: ["VVD"]
---

Country: [[Netherlands]] · Group: [[Renew]]

# VVD (NLD)

National party: VVD.
