---
type: "party"
party_id: "7009"
label: "SALF"
name: "SALF"
country: "Spain"
aliases: ["SALF"]
---

Country: [[Spain]] · Group: [[NI]]

# SALF (ESP)

National party: SALF.
