---
type: "party"
party_id: "6764"
label: "DI.SY."
name: "DI.SY."
country: "Cyprus"
aliases: ["DI.SY."]
---

Country: [[Cyprus]] · Group: [[PPE]]

# DI.SY. (CYP)

National party: DI.SY..
