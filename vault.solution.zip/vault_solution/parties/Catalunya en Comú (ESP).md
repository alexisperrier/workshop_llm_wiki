---
type: "party"
party_id: "6784"
label: "Catalunya en Comú"
name: "Comuns"
country: "Spain"
aliases: ["Catalunya en Comú", "Comuns"]
---

Country: [[Spain]] · Group: [[Verts-ALE]]

# Catalunya en Comú (ESP)

National party: Comuns.
