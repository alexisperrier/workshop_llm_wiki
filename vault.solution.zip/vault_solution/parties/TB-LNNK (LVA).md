---
type: "party"
party_id: "6685"
label: "TB/LNNK"
name: "TB/LNNK"
country: "Latvia"
aliases: ["TB/LNNK"]
---

Country: [[Latvia]] · Group: [[ECR]]

# TB-LNNK (LVA)

National party: TB/LNNK.
