---
type: "party"
party_id: "6754"
label: "N-VA"
name: "N-VA"
country: "Belgium"
aliases: ["N-VA"]
---

Country: [[Belgium]] · Group: [[ECR]]

# N-VA (BEL)

National party: N-VA.
