---
type: "party"
party_id: "6638"
label: "Volt"
name: "Volt"
country: "Netherlands"
aliases: ["Volt"]
---

Country: [[Netherlands]] · Group: [[Verts-ALE]]

# Volt (NLD)

National party: Volt.
