---
type: "party"
party_id: "6672"
label: "SDP"
name: "SDP"
country: "Finland"
aliases: ["SDP"]
---

Country: [[Finland]] · Group: [[S&D]]

# SDP (FIN)

National party: SDP.
