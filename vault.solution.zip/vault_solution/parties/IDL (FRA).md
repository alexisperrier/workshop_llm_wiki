---
type: "party"
party_id: "7876"
label: "IDL"
name: "Identité Libertés"
country: "France"
aliases: ["IDL", "Identité Libertés"]
---

Country: [[France]] · Group: [[ECR]]

# IDL (FRA)

National party: Identité Libertés.
