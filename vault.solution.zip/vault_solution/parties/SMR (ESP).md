---
type: "party"
party_id: "6949"
label: "SMR"
name: "SMR"
country: "Spain"
aliases: ["SMR"]
---

Country: [[Spain]] · Group: [[The Left]]

# SMR (ESP)

National party: SMR.
