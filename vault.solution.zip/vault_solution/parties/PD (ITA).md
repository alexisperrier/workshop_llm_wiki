---
type: "party"
party_id: "6675"
label: "PD"
name: "PD"
country: "Italy"
aliases: ["PD"]
---

Country: [[Italy]] · Group: [[S&D]]

# PD (ITA)

National party: PD.
