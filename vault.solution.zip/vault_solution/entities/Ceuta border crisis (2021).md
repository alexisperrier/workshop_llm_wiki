---
type: event
aliases: ["en el año 2021", "2021"]
---
# Ceuta border crisis (2021)

The mass crossing of about 10,000 to 12,000 people from Morocco into Ceuta in May 2021.
