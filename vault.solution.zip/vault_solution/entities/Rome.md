---
type: place
aliases: ["Roma"]
---
# Rome

Capital of Italy.
