---
type: law
aliases: ["Código de Fronteras Schengen"]
---
# Schengen Borders Code

The EU regulation that sets the rules on border controls at the external borders and on the temporary reintroduction of internal border controls.
