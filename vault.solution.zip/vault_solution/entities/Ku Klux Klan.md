---
type: organisation
aliases: []
---
# Ku Klux Klan

American white supremacist organisation.
