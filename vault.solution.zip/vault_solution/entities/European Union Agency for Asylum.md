---
type: organisation
aliases: ["EUAA", "EU Asylum Agency", "Agency For Asylum", "Agencia de Asilo"]
---
# European Union Agency for Asylum

The EU agency that supports Member States in applying asylum law.
