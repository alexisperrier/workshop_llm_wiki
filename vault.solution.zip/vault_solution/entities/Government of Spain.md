---
type: organisation
aliases: ["the Spanish government", "Gobierno de España", "Spanish Government", "Gobierno", "governo espanhol", "Gobierno español", "le gouvernement espagnol"]
---
# Government of Spain

The national government of Spain.
