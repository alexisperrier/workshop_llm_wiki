---
type: place
aliases: ["Schengen", "Schengen area", "Schengen-Raum", "espaço Schengen", "l'espace Schengen", "strefy Schengen", "Strefa Schengen", "Шенген"]
---
# Schengen Area

The area of European countries that have abolished controls at their common internal borders.
