---
type: place
aliases: ["Ormuz"]
---
# Strait of Hormuz

The strait between Iran and Oman, a major route for oil shipping.
