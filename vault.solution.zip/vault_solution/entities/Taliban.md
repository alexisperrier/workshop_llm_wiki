---
type: organisation
aliases: ["talibanes"]
---
# Taliban

The Islamist movement that governs Afghanistan.
