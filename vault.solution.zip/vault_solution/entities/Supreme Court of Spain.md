---
type: organisation
aliases: ["Tribunal Supremo"]
---
# Supreme Court of Spain

The highest court of Spain.
