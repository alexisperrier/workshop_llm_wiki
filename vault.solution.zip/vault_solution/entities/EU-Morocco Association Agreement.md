---
type: law
aliases: ["Acuerdo de Asociación con Marruecos"]
---
# EU-Morocco Association Agreement

The agreement that governs the relations between the European Union and Morocco.
