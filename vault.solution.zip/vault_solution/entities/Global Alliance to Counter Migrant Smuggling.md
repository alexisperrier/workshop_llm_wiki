---
type: organisation
aliases: []
---
# Global Alliance to Counter Migrant Smuggling

International alliance launched by the European Commission in 2023 against migrant smuggling.
