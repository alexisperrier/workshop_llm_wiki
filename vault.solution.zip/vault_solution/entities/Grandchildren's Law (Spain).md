---
type: law
aliases: ["Ley de Nietos"]
---
# Grandchildren's Law (Spain)

The provision of Spain's Democratic Memory Law allowing descendants of Spanish exiles to obtain Spanish nationality.
