---
type: place
aliases: ["Sicilia"]
---
# Sicily

Italian island in the Mediterranean.
