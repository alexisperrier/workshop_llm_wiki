---
type: organisation
aliases: []
---
# Europol

The European Union Agency for Law Enforcement Cooperation.
