---
type: place
aliases: ["Sassonia"]
---
# Saxony

Federal state of Germany.
