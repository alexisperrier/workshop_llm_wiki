---
type: place
aliases: ["Berlín"]
---
# Berlin

Capital of Germany.
