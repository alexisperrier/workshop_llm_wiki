---
type: law
aliases: ["list of safe third countries", "pays tiers sûrs"]
---
# Safe Third Country Regulation

EU rules on the concept of safe third countries in asylum procedures.
