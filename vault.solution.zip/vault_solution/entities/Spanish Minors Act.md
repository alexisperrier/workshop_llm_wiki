---
type: law
aliases: ["Ley del Menor"]
---
# Spanish Minors Act

Spain's law on the legal protection of minors.
