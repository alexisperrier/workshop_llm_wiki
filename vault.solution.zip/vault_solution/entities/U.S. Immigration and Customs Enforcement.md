---
type: organisation
aliases: ["ICE"]
---
# U.S. Immigration and Customs Enforcement

The United States federal agency in charge of immigration enforcement.
