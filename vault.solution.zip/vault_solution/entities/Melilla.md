---
type: place
aliases: []
---
# Melilla

Spanish autonomous city on the North African coast, bordering Morocco.
