---
type: place
aliases: ["Sáhara Occidental", "Westsahara"]
---
# Western Sahara

Disputed territory in North-West Africa, largely controlled by Morocco.
