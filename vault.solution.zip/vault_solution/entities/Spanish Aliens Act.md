---
type: law
aliases: ["Ley de Extranjería"]
---
# Spanish Aliens Act

Spain's law on the rights and freedoms of foreigners.
