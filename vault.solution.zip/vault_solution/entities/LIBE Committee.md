---
type: organisation
aliases: ["Committee on Civil Liberties, Justice and Home Affairs", "LIBE", "LIBE-Ausschusses"]
---
# LIBE Committee

The European Parliament's Committee on Civil Liberties, Justice and Home Affairs.
