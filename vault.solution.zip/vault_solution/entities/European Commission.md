---
type: organisation
aliases: ["the Commission", "Comisión Europea", "Bizottság", "la Commission", "The Commission", "Commissie", "la Comisión", "la Commission européenne", "Commission", "KE", "Commission européenne"]
---
# European Commission

The executive institution of the European Union.
