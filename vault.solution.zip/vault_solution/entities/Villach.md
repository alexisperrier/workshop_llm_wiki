---
type: place
aliases: []
---
# Villach

City in Austria.
