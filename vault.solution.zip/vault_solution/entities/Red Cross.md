---
type: organisation
aliases: ["Cruz Roja"]
---
# Red Cross

The humanitarian organisation; here its Spanish branch, the Cruz Roja.
