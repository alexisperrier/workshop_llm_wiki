---
type: place
aliases: []
---
# Pantelleria

Italian island in the Strait of Sicily.
