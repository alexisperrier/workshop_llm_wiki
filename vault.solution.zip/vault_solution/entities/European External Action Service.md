---
type: organisation
aliases: ["EEAS"]
---
# European External Action Service

The diplomatic service of the European Union.
