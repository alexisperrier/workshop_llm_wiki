---
type: law
aliases: ["the Pact", "el Pacto", "le pacte", "The Pact", "the pact", "pacto migratorio", "Pacto em matéria de Migração e Asilo", "Pacto sobre Migración y Asilo", "Pakt", "el pacto", "Пакт за миграцията", "Migration Pact", "pacte sur la migration et l'asile"]
---
# Pact on Migration and Asylum

The package of EU laws on migration and asylum adopted in 2024, which entered into application in June 2026.
