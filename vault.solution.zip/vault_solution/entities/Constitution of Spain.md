---
type: law
aliases: ["Constitución española"]
---
# Constitution of Spain

The Spanish Constitution of 1978.
