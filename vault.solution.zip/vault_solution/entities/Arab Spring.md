---
type: event
aliases: ["primavere arabe"]
---
# Arab Spring

The wave of uprisings in Arab countries from 2010–2011.
