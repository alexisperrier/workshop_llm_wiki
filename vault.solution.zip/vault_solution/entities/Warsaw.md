---
type: place
aliases: ["Varsovia"]
---
# Warsaw

Capital of Poland.
