---
type: place
aliases: ["Aschaffenbourg"]
---
# Aschaffenburg

City in Germany.
