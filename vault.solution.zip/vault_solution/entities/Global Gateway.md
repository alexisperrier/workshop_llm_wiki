---
type: organisation
aliases: ["Global-Gateway"]
---
# Global Gateway

The EU's strategy and funding programme for investment in partner countries.
