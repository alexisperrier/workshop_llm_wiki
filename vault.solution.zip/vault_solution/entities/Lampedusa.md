---
type: place
aliases: []
---
# Lampedusa

Italian island in the Mediterranean, south of Sicily, a frequent landing point for migrants.
