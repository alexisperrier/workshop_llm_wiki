---
type: place
aliases: []
---
# Western Balkan route

The migration route through the countries of the Western Balkans towards the EU.
