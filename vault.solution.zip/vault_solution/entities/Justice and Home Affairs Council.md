---
type: organisation
aliases: ["JHA Council"]
---
# Justice and Home Affairs Council

The configuration of the Council of the European Union where justice and interior ministers meet.
