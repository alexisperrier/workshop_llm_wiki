---
type: organisation
aliases: ["Consejo Europeo"]
---
# European Council

The EU institution that brings together the heads of state or government of the Member States.
