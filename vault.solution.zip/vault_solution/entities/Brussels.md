---
type: place
aliases: ["Bruxelles", "Bruksela"]
---
# Brussels

Capital of Belgium, seat of the main EU institutions.
