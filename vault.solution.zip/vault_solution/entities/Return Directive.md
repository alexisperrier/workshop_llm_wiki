---
type: law
aliases: ["directive retour"]
---
# Return Directive

The 2008 EU directive on the return of illegally staying third-country nationals, replaced by the Return Regulation.
