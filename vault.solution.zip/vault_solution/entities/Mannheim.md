---
type: place
aliases: []
---
# Mannheim

City in Germany.
