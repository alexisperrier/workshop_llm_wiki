---
type: place
aliases: []
---
# Madrid

Capital of Spain.
