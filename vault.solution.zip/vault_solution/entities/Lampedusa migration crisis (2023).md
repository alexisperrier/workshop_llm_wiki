---
type: event
aliases: ["crisis de Lampedusa", "crise migratoire de Lampedusa en 2023"]
---
# Lampedusa migration crisis (2023)

The large number of arrivals of migrants on the Italian island of Lampedusa in 2023.
