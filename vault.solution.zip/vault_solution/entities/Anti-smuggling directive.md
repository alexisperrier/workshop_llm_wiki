---
type: law
aliases: ["anti-smuggling directive"]
---
# Anti-smuggling directive

The Commission's proposal for a directive to prevent and counter migrant smuggling.
