---
type: organisation
aliases: ["EIB"]
---
# European Investment Bank

The lending institution of the European Union.
