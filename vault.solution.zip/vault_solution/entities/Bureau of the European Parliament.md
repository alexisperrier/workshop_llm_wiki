---
type: organisation
aliases: ["Bureau du Parlement européen"]
---
# Bureau of the European Parliament

The body of the European Parliament made up of the President and the Vice-Presidents, responsible among other things for sanctions against Members.
