---
type: organisation
aliases: ["UN", "ONU"]
---
# United Nations

The international organisation of states.
