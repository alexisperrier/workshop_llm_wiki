---
type: place
aliases: ["Θέουτα", "Сеута", "Ceucie", "Ceuty", "Ceutaan"]
---
# Ceuta

Spanish autonomous city on the North African coast, bordering Morocco.
