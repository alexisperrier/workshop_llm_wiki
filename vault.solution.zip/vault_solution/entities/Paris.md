---
type: place
aliases: ["París"]
---
# Paris

Capital of France.
