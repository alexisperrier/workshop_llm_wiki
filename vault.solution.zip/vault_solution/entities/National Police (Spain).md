---
type: organisation
aliases: ["Policía Nacional"]
---
# National Police (Spain)

Spain's national police force.
