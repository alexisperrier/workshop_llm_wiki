---
type: organisation
aliases: ["European Border and Coast Guard Agency"]
---
# Frontex

The European Border and Coast Guard Agency, the EU agency that supports Member States in managing the external borders.
