---
type: law
aliases: ["returns regulation", "Reglamento sobre el retorno", "terugkeerrichtlijn", "Reglamento de retorno", "règlement retour", "règlement sur le retour", "Reglamento sobre el Retorno", "Rückführungsverordnung", "return regulation", "Rozporządzenie powrotowe"]
---
# Return Regulation

EU regulation establishing a common system for the return of third-country nationals staying illegally in the Union; final vote in Parliament on 17 June 2026.
