---
type: place
aliases: []
---
# Solingen

City in Germany.
