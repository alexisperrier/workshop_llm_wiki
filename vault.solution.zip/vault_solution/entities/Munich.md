---
type: place
aliases: []
---
# Munich

City in Germany.
