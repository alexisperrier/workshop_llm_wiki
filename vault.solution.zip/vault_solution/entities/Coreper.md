---
type: organisation
aliases: []
---
# Coreper

The Committee of the Permanent Representatives of the Member States to the European Union.
