---
type: organisation
aliases: ["Embajada del Reino de Marruecos"]
---
# Embassy of Morocco

Morocco's diplomatic mission to the EU.
