---
type: organisation
aliases: ["l'Union africaine"]
---
# African Union

The continental union of African states.
