---
type: organisation
aliases: ["the Council", "Consejo", "Cyprus Presidency", "le Conseil"]
---
# Council of the European Union

The EU institution where national ministers meet; its presidency rotates among Member States every six months.
