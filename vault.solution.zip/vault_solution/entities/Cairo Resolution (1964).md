---
type: law
aliases: ["résolution du Caire de 1964"]
---
# Cairo Resolution (1964)

Resolution of the Organisation of African Unity (1964) accepting the borders inherited from colonisation.
