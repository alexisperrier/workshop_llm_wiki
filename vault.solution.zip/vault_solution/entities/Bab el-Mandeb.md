---
type: place
aliases: []
---
# Bab el-Mandeb

The strait between Yemen and the Horn of Africa linking the Red Sea and the Gulf of Aden.
