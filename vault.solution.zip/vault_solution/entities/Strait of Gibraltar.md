---
type: place
aliases: ["estrecho de Gibraltar"]
---
# Strait of Gibraltar

The strait between Spain and Morocco linking the Atlantic and the Mediterranean.
