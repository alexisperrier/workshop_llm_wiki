---
type: law
aliases: []
---
# Digital Services Act

The EU regulation on the obligations of online platforms, including against illegal content and disinformation.
