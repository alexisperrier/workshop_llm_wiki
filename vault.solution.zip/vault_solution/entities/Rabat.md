---
type: place
aliases: []
---
# Rabat

Capital of Morocco.
