---
type: organisation
aliases: ["Entry/Exit System", "entry/exit system"]
---
# Entry-Exit System

The EU's automated system registering the entries and exits of non-EU travellers at the external borders.
