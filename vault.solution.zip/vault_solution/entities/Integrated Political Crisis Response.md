---
type: organisation
aliases: ["IPCR", "integrated political crisis response round table"]
---
# Integrated Political Crisis Response

The EU Council's arrangement for coordinating the political response to major crises.
