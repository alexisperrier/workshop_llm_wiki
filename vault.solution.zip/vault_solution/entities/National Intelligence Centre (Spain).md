---
type: organisation
aliases: ["CNI", "Centro Nacional de Inteligencia", "Centro Nacional de Inteligencia español"]
---
# National Intelligence Centre (Spain)

Spain's national intelligence agency.
