---
type: law
aliases: ["pays d'origine sûrs"]
---
# Safe Countries of Origin Regulation

EU rules establishing a common list of safe countries of origin.
