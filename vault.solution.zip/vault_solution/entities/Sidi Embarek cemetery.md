---
type: place
aliases: ["cementerio musulmán de Sidi Embarek"]
---
# Sidi Embarek cemetery

Muslim cemetery in Ceuta.
