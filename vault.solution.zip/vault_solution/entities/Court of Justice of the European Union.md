---
type: organisation
aliases: ["CJEU", "TJUE"]
---
# Court of Justice of the European Union

The judicial institution of the European Union.
