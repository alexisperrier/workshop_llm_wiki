---
type: "person"
person_id: "257170"
first_name: "Sandro"
last_name: "Ruotolo"
gender: "MALE"
mep: true
group: "S&D"
party: "PD (ITA)"
country: "Italy"
---

Group: [[S&D]] · Party: [[PD (ITA)]] · Country: [[Italy]]

# Sandro Ruotolo
