---
type: "person"
person_id: "197606"
first_name: "Javier"
last_name: "Zarzalejos"
gender: "MALE"
mep: true
group: "PPE"
party: "PP (ESP)"
country: "Spain"
---

Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]

# Javier Zarzalejos
