---
type: "person"
person_id: "197829"
first_name: "Jorge"
last_name: "Buxadé Villalba"
gender: "MALE"
mep: true
group: "PfE"
party: "VOX (ESP)"
country: "Spain"
aliases: ["señor Buxadé"]
---

Group: [[PfE]] · Party: [[VOX (ESP)]] · Country: [[Spain]]

# Jorge Buxadé Villalba
