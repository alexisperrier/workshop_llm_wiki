---
type: "person"
person_id: "24942"
first_name: "Ana"
last_name: "Miranda Paz"
gender: "FEMALE"
mep: true
group: "Verts-ALE"
party: "BNG (ESP)"
country: "Spain"
---

Group: [[Verts-ALE]] · Party: [[BNG (ESP)]] · Country: [[Spain]]

# Ana Miranda Paz
