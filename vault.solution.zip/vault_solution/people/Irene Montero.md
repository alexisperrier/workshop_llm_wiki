---
type: person
role: "Member of the European Parliament (The Left, Spain)"
aliases: ["Madame Montero"]
---
# Irene Montero

Spanish politician (Podemos), Member of the European Parliament.
