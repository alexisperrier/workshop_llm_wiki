---
type: "person"
person_id: "257012"
first_name: "Estrella"
last_name: "Galán"
gender: "FEMALE"
mep: true
group: "The Left"
party: "SMR (ESP)"
country: "Spain"
---

Group: [[The Left]] · Party: [[SMR (ESP)]] · Country: [[Spain]]

# Estrella Galán
