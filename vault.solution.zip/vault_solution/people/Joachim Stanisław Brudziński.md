---
type: "person"
person_id: "197501"
first_name: "Joachim Stanisław"
last_name: "Brudziński"
gender: "MALE"
mep: true
group: "ECR"
party: "PiS (POL)"
country: "Poland"
---

Group: [[ECR]] · Party: [[PiS (POL)]] · Country: [[Poland]]

# Joachim Stanisław Brudziński
