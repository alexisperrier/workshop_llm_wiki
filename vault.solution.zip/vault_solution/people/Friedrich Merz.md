---
type: person
role: "Chancellor of Germany"
aliases: []
---
# Friedrich Merz

Chancellor of Germany (CDU).
