---
type: "person"
person_id: "86057"
first_name: "Bartłomiej"
last_name: "Sienkiewicz"
gender: "MALE"
mep: true
group: "PPE"
party: "KO (POL)"
country: "Poland"
---

Group: [[PPE]] · Party: [[KO (POL)]] · Country: [[Poland]]

# Bartłomiej Sienkiewicz
