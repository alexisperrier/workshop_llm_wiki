---
type: "person"
person_id: "124850"
first_name: "Emil"
last_name: "Radev"
gender: "MALE"
mep: true
group: "PPE"
party: "GERB (BGR)"
country: "Bulgaria"
aliases: ["Емил Радев"]
---

Group: [[PPE]] · Party: [[GERB (BGR)]] · Country: [[Bulgaria]]

# Emil Radev
