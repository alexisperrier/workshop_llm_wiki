---
type: "person"
person_id: "275105"
mep: false
roles: ["President-in-Office of the Council"]
---

# Thomas Byrne

Role: President-in-Office of the Council.
