---
type: "person"
person_id: "124877"
first_name: "Jadwiga"
last_name: "Wiśniewska"
gender: "FEMALE"
mep: true
group: "ECR"
party: "PiS (POL)"
country: "Poland"
---

Group: [[ECR]] · Party: [[PiS (POL)]] · Country: [[Poland]]

# Jadwiga Wiśniewska
