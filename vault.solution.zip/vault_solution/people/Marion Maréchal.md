---
type: "person"
person_id: "256922"
first_name: "Marion"
last_name: "Maréchal"
gender: "FEMALE"
mep: true
group: "ECR"
party: "IDL (FRA)"
country: "France"
---

Group: [[ECR]] · Party: [[IDL (FRA)]] · Country: [[France]]

# Marion Maréchal
