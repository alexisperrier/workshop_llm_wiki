---
type: "person"
person_id: "256987"
first_name: "Oihane"
last_name: "Agirregoitia Martínez"
gender: "FEMALE"
mep: true
group: "Renew"
party: "PNV (ESP)"
country: "Spain"
---

Group: [[Renew]] · Party: [[PNV (ESP)]] · Country: [[Spain]]

# Oihane Agirregoitia Martínez
