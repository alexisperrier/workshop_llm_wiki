---
type: "person"
person_id: "197462"
first_name: "Erik"
last_name: "Marquardt"
gender: "MALE"
mep: true
group: "Verts-ALE"
party: "GRÜNE. (DEU)"
country: "Germany"
aliases: ["Herr Marquardt"]
---

Group: [[Verts-ALE]] · Party: [[GRÜNE. (DEU)]] · Country: [[Germany]]

# Erik Marquardt
