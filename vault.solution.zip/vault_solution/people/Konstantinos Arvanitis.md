---
type: "person"
person_id: "197701"
first_name: "Konstantinos"
last_name: "Arvanitis"
gender: "MALE"
mep: true
group: "The Left"
party: "SYRIZA (GRC)"
country: "Greece"
aliases: ["Κωνσταντίνος Αρβανίτης"]
---

Group: [[The Left]] · Party: [[SYRIZA (GRC)]] · Country: [[Greece]]

# Konstantinos Arvanitis
