---
type: "person"
person_id: "256990"
first_name: "Anna"
last_name: "Strolenberg"
gender: "FEMALE"
mep: true
group: "Verts-ALE"
party: "Volt (NLD)"
country: "Netherlands"
---

Group: [[Verts-ALE]] · Party: [[Volt (NLD)]] · Country: [[Netherlands]]

# Anna Strolenberg
