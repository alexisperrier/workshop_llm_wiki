---
type: person
role: "Spanish minister"
aliases: ["Saiz"]
---
# Elma Saiz

Spanish Minister for Inclusion, Social Security and Migration.
