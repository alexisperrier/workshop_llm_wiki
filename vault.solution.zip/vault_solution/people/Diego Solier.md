---
type: "person"
person_id: "257021"
first_name: "Diego"
last_name: "Solier"
gender: "MALE"
mep: true
group: "ECR"
country: "Spain"
---

Group: [[ECR]] · Country: [[Spain]]

# Diego Solier
