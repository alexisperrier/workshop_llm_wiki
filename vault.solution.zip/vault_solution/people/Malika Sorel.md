---
type: "person"
person_id: "256871"
first_name: "Malika"
last_name: "Sorel"
gender: "FEMALE"
mep: true
group: "NI"
country: "France"
---

Group: [[NI]] · Country: [[France]]

# Malika Sorel
