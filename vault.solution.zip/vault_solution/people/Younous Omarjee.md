---
type: "person"
person_id: "30482"
first_name: "Younous"
last_name: "Omarjee"
gender: "MALE"
mep: true
group: "The Left"
party: "LFI (FRA)"
country: "France"
roles: ["chair of the sitting"]
---

Group: [[The Left]] · Party: [[LFI (FRA)]] · Country: [[France]]

# Younous Omarjee

Role: chair of the sitting.
