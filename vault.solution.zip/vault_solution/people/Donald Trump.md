---
type: person
role: "President of the United States"
aliases: ["Trump", "Τραμπ"]
---
# Donald Trump

President of the United States.
