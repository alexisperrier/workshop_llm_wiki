---
type: "person"
person_id: "257035"
first_name: "Alma"
last_name: "Ezcurra Almansa"
gender: "FEMALE"
mep: true
group: "PPE"
party: "PP (ESP)"
country: "Spain"
---

Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]

# Alma Ezcurra Almansa
