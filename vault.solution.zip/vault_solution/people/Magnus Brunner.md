---
type: "person"
person_id: "263974"
mep: false
roles: ["Member of the Commission"]
aliases: ["Herr Magnus Brunner", "Commissario Brunner", "señor comisario Brunner", "Lieber Magnus", "Monsieur le Commissaire Brunner", "cher Magnus Brunner"]
---

# Magnus Brunner

Role: Member of the Commission.
