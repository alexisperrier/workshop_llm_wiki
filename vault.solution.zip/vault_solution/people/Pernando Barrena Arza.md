---
type: "person"
person_id: "197684"
first_name: "Pernando"
last_name: "Barrena Arza"
gender: "MALE"
mep: true
group: "The Left"
party: "EH BILDU (ESP)"
country: "Spain"
---

Group: [[The Left]] · Party: [[EH BILDU (ESP)]] · Country: [[Spain]]

# Pernando Barrena Arza
