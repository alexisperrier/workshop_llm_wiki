---
type: person
role: "Spanish Minister of the Interior"
aliases: ["Grande-Marlaska"]
---
# Fernando Grande-Marlaska

Spanish Minister of the Interior.
