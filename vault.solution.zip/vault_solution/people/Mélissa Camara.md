---
type: "person"
person_id: "256915"
first_name: "Mélissa"
last_name: "Camara"
gender: "FEMALE"
mep: true
group: "Verts-ALE"
party: "Les Écologistes (FRA)"
country: "France"
---

Group: [[Verts-ALE]] · Party: [[Les Écologistes (FRA)]] · Country: [[France]]

# Mélissa Camara
