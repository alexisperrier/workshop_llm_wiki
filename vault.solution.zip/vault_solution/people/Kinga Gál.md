---
type: "person"
person_id: "28150"
first_name: "Kinga"
last_name: "Gál"
gender: "FEMALE"
mep: true
group: "PfE"
party: "Fidesz-KDNP (HUN)"
country: "Hungary"
---

Group: [[PfE]] · Party: [[Fidesz-KDNP (HUN)]] · Country: [[Hungary]]

# Kinga Gál
