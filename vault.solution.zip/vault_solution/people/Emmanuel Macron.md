---
type: person
role: "President of France"
aliases: []
---
# Emmanuel Macron

President of France.
