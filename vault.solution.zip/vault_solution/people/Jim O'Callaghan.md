---
type: person
role: "Irish Minister for Justice"
aliases: []
---
# Jim O'Callaghan

Irish Minister for Justice, Home Affairs and Migration.
