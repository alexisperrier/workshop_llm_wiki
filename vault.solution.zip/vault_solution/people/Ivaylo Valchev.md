---
type: "person"
person_id: "257258"
first_name: "Ivaylo"
last_name: "Valchev"
gender: "MALE"
mep: true
group: "ECR"
party: "ITN (BGR)"
country: "Bulgaria"
aliases: ["Ивайло Вълчев"]
---

Group: [[ECR]] · Party: [[ITN (BGR)]] · Country: [[Bulgaria]]

# Ivaylo Valchev
