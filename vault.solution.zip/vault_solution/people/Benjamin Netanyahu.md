---
type: person
role: "Prime Minister of Israel"
aliases: ["Netanyahu", "Νετανιάχου"]
---
# Benjamin Netanyahu

Prime Minister of Israel.
