---
type: "person"
person_id: "99945"
first_name: "Lena"
last_name: "Düpont"
gender: "FEMALE"
mep: true
group: "PPE"
party: "CDU (DEU)"
country: "Germany"
---

Group: [[PPE]] · Party: [[CDU (DEU)]] · Country: [[Germany]]

# Lena Düpont
