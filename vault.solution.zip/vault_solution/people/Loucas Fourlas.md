---
type: "person"
person_id: "197414"
first_name: "Loucas"
last_name: "Fourlas"
gender: "MALE"
mep: true
group: "PPE"
party: "DI.SY. (CYP)"
country: "Cyprus"
aliases: ["Λουκάς Φουρλάς"]
---

Group: [[PPE]] · Party: [[DI.SY. (CYP)]] · Country: [[Cyprus]]

# Loucas Fourlas
