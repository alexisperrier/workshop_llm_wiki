---
type: "person"
person_id: "257015"
first_name: "Jaume"
last_name: "Asens Llodrà"
gender: "MALE"
mep: true
group: "Verts-ALE"
party: "Catalunya en Comú (ESP)"
country: "Spain"
---

Group: [[Verts-ALE]] · Party: [[Catalunya en Comú (ESP)]] · Country: [[Spain]]

# Jaume Asens Llodrà
