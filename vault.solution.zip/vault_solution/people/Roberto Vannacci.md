---
type: "person"
person_id: "257125"
first_name: "Roberto"
last_name: "Vannacci"
gender: "MALE"
mep: true
group: "ESN"
party: "FN (ITA)"
country: "Italy"
---

Group: [[ESN]] · Party: [[FN (ITA)]] · Country: [[Italy]]

# Roberto Vannacci
