---
type: "person"
person_id: "124760"
first_name: "Nicolas"
last_name: "Bay"
gender: "MALE"
mep: true
group: "ECR"
party: "IDL (FRA)"
country: "France"
---

Group: [[ECR]] · Party: [[IDL (FRA)]] · Country: [[France]]

# Nicolas Bay
