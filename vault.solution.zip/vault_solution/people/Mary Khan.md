---
type: "person"
person_id: "256957"
first_name: "Mary"
last_name: "Khan"
gender: "FEMALE"
mep: true
group: "ESN"
party: "AfD (DEU)"
country: "Germany"
---

Group: [[ESN]] · Party: [[AfD (DEU)]] · Country: [[Germany]]

# Mary Khan
