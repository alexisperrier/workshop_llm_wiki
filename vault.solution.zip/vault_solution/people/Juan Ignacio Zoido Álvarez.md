---
type: "person"
person_id: "197621"
first_name: "Juan Ignacio"
last_name: "Zoido Álvarez"
gender: "MALE"
mep: true
group: "PPE"
party: "PP (ESP)"
country: "Spain"
---

Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]

# Juan Ignacio Zoido Álvarez
