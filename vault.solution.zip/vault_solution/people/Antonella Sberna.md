---
type: "person"
person_id: "257113"
first_name: "Antonella"
last_name: "Sberna"
gender: "FEMALE"
mep: true
group: "ECR"
party: "FdL (ITA)"
country: "Italy"
roles: ["chair of the sitting"]
---

Group: [[ECR]] · Party: [[FdL (ITA)]] · Country: [[Italy]]

# Antonella Sberna

Role: chair of the sitting.
