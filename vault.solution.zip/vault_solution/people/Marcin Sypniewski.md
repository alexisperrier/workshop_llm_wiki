---
type: "person"
person_id: "257070"
first_name: "Marcin"
last_name: "Sypniewski"
gender: "MALE"
mep: true
group: "ESN"
party: "Konfederacja (POL)"
country: "Poland"
---

Group: [[ESN]] · Party: [[Konfederacja (POL)]] · Country: [[Poland]]

# Marcin Sypniewski
