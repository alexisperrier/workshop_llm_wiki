---
type: "person"
person_id: "257147"
first_name: "Alessandro"
last_name: "Ciriani"
gender: "MALE"
mep: true
group: "ECR"
party: "FdL (ITA)"
country: "Italy"
---

Group: [[ECR]] · Party: [[FdL (ITA)]] · Country: [[Italy]]

# Alessandro Ciriani
