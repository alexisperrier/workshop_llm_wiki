---
type: person
role: "former European Commissioner for Home Affairs"
aliases: ["Mme Ylva Johansson"]
---
# Ylva Johansson

European Commissioner for Home Affairs from 2019 to 2024.
