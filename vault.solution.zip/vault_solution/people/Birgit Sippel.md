---
type: "person"
person_id: "96932"
first_name: "Birgit"
last_name: "Sippel"
gender: "FEMALE"
mep: true
group: "S&D"
party: "SPD (DEU)"
country: "Germany"
---

Group: [[S&D]] · Party: [[SPD (DEU)]] · Country: [[Germany]]

# Birgit Sippel
