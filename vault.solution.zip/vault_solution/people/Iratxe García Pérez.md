---
type: "person"
person_id: "28298"
first_name: "Iratxe"
last_name: "García Pérez"
gender: "FEMALE"
mep: true
group: "S&D"
party: "PSOE (ESP)"
country: "Spain"
aliases: ["señora Iratxe"]
---

Group: [[S&D]] · Party: [[PSOE (ESP)]] · Country: [[Spain]]

# Iratxe García Pérez
