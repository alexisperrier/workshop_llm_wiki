---
type: "person"
person_id: "257019"
first_name: "Alvise"
last_name: "Pérez"
gender: "MALE"
mep: true
group: "NI"
party: "SALF (ESP)"
country: "Spain"
aliases: ["Monsieur Pérez"]
---

Group: [[NI]] · Party: [[SALF (ESP)]] · Country: [[Spain]]

# Alvise Pérez
