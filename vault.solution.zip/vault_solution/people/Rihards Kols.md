---
type: "person"
person_id: "220871"
first_name: "Rihards"
last_name: "Kols"
gender: "MALE"
mep: true
group: "ECR"
party: "TB-LNNK (LVA)"
country: "Latvia"
---

Group: [[ECR]] · Party: [[TB-LNNK (LVA)]] · Country: [[Latvia]]

# Rihards Kols
