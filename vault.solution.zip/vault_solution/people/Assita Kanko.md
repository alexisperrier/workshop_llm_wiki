---
type: "person"
person_id: "197469"
first_name: "Assita"
last_name: "Kanko"
gender: "FEMALE"
mep: true
group: "ECR"
party: "N-VA (BEL)"
country: "Belgium"
---

Group: [[ECR]] · Party: [[N-VA (BEL)]] · Country: [[Belgium]]

# Assita Kanko
