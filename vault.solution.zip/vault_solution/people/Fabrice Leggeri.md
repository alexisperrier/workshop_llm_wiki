---
type: "person"
person_id: "256872"
first_name: "Fabrice"
last_name: "Leggeri"
gender: "MALE"
mep: true
group: "PfE"
party: "RN (FRA)"
country: "France"
---

Group: [[PfE]] · Party: [[RN (FRA)]] · Country: [[France]]

# Fabrice Leggeri
