---
type: "person"
person_id: "257053"
first_name: "Ana Catarina"
last_name: "Mendes"
gender: "FEMALE"
mep: true
group: "S&D"
party: "PS (PRT)"
country: "Portugal"
---

Group: [[S&D]] · Party: [[PS (PRT)]] · Country: [[Portugal]]

# Ana Catarina Mendes
