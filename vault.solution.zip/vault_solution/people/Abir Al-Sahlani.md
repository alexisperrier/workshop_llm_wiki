---
type: "person"
person_id: "197400"
first_name: "Abir"
last_name: "Al-Sahlani"
gender: "FEMALE"
mep: true
group: "Renew"
party: "C (SWE)"
country: "Sweden"
---

Group: [[Renew]] · Party: [[C (SWE)]] · Country: [[Sweden]]

# Abir Al-Sahlani
