---
type: "person"
person_id: "96812"
first_name: "Juan Fernando"
last_name: "López Aguilar"
gender: "MALE"
mep: true
group: "S&D"
party: "PSOE (ESP)"
country: "Spain"
aliases: ["señor Aguilar"]
---

Group: [[S&D]] · Party: [[PSOE (ESP)]] · Country: [[Spain]]

# Juan Fernando López Aguilar
