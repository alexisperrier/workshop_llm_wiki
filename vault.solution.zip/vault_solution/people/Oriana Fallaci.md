---
type: person
role: "Italian writer and journalist"
aliases: []
---
# Oriana Fallaci

Italian writer and journalist (1929–2006).
