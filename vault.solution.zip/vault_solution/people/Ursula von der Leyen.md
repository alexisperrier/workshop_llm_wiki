---
type: person
role: "President of the European Commission"
aliases: ["President von der Leyen"]
---
# Ursula von der Leyen

President of the European Commission.
