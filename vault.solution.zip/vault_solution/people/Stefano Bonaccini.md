---
type: person
role: "Member of the European Parliament (S&D, Italy)"
aliases: ["Bonaccini"]
---
# Stefano Bonaccini

Italian politician (PD), Member of the European Parliament.
