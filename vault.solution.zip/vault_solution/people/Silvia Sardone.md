---
type: "person"
person_id: "197578"
first_name: "Silvia"
last_name: "Sardone"
gender: "FEMALE"
mep: true
group: "PfE"
party: "L (ITA)"
country: "Italy"
---

Group: [[PfE]] · Party: [[L (ITA)]] · Country: [[Italy]]

# Silvia Sardone
