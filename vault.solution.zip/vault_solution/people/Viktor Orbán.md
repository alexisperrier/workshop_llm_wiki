---
type: person
role: "Prime Minister of Hungary"
aliases: ["Orbán"]
---
# Viktor Orbán

Prime Minister of Hungary (Fidesz).
