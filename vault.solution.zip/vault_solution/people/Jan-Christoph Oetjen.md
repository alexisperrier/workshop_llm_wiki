---
type: "person"
person_id: "197432"
first_name: "Jan-Christoph"
last_name: "Oetjen"
gender: "MALE"
mep: true
group: "Renew"
party: "FDP (DEU)"
country: "Germany"
---

Group: [[Renew]] · Party: [[FDP (DEU)]] · Country: [[Germany]]

# Jan-Christoph Oetjen
