---
type: "person"
person_id: "95074"
first_name: "Jeroen"
last_name: "Lenaers"
gender: "MALE"
mep: true
group: "PPE"
party: "CDA (NLD)"
country: "Netherlands"
aliases: ["Lenaers"]
---

Group: [[PPE]] · Party: [[CDA (NLD)]] · Country: [[Netherlands]]

# Jeroen Lenaers
