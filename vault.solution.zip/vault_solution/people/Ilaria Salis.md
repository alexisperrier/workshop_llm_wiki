---
type: "person"
person_id: "257127"
first_name: "Ilaria"
last_name: "Salis"
gender: "FEMALE"
mep: true
group: "The Left"
party: "SI (ITA)"
country: "Italy"
---

Group: [[The Left]] · Party: [[SI (ITA)]] · Country: [[Italy]]

# Ilaria Salis
