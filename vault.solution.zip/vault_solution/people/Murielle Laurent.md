---
type: "person"
person_id: "256899"
first_name: "Murielle"
last_name: "Laurent"
gender: "FEMALE"
mep: true
group: "S&D"
party: "PS (FRA)"
country: "France"
---

Group: [[S&D]] · Party: [[PS (FRA)]] · Country: [[France]]

# Murielle Laurent
