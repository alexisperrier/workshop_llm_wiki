---
type: "person"
person_id: "197534"
first_name: "François-Xavier"
last_name: "Bellamy"
gender: "MALE"
mep: true
group: "PPE"
party: "Les Républicains (FRA)"
country: "France"
aliases: ["señor Bellamy"]
---

Group: [[PPE]] · Party: [[Les Républicains (FRA)]] · Country: [[France]]

# François-Xavier Bellamy
