---
type: "person"
person_id: "257064"
first_name: "Anna"
last_name: "Bryłka"
gender: "FEMALE"
mep: true
group: "PfE"
party: "Konfederacja (POL)"
country: "Poland"
---

Group: [[PfE]] · Party: [[Konfederacja (POL)]] · Country: [[Poland]]

# Anna Bryłka
