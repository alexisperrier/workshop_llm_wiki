---
type: "person"
person_id: "190574"
first_name: "Tomasz"
last_name: "Froelich"
gender: "MALE"
mep: true
group: "ESN"
party: "AfD (DEU)"
country: "Germany"
---

Group: [[ESN]] · Party: [[AfD (DEU)]] · Country: [[Germany]]

# Tomasz Froelich
