---
type: "person"
person_id: "197781"
first_name: "Malik"
last_name: "Azmani"
gender: "MALE"
mep: true
group: "Renew"
party: "VVD (NLD)"
country: "Netherlands"
aliases: ["Mijnheer Azmani", "Mr Azmani"]
---

Group: [[Renew]] · Party: [[VVD (NLD)]] · Country: [[Netherlands]]

# Malik Azmani
