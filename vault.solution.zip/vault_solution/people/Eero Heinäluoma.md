---
type: "person"
person_id: "197800"
first_name: "Eero"
last_name: "Heinäluoma"
gender: "MALE"
mep: true
group: "S&D"
party: "SDP (FIN)"
country: "Finland"
---

Group: [[S&D]] · Party: [[SDP (FIN)]] · Country: [[Finland]]

# Eero Heinäluoma
