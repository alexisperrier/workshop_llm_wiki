---
type: "person"
person_id: "256806"
first_name: "Sebastian"
last_name: "Tynkkynen"
gender: "MALE"
mep: true
group: "ECR"
party: "Perus (FIN)"
country: "Finland"
---

Group: [[ECR]] · Party: [[Perus (FIN)]] · Country: [[Finland]]

# Sebastian Tynkkynen
