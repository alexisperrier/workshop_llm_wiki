---
type: person
role: "King of Morocco"
aliases: ["Re Mohammed VI"]
---
# Mohammed VI

King of Morocco.
