---
type: "person"
person_id: "257056"
first_name: "Mariusz"
last_name: "Kamiński"
gender: "MALE"
mep: true
group: "ECR"
party: "PiS (POL)"
country: "Poland"
---

Group: [[ECR]] · Party: [[PiS (POL)]] · Country: [[Poland]]

# Mariusz Kamiński
