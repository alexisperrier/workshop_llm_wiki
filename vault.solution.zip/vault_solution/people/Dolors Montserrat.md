---
type: "person"
person_id: "197711"
first_name: "Dolors"
last_name: "Montserrat"
gender: "FEMALE"
mep: true
group: "PPE"
party: "PP (ESP)"
country: "Spain"
---

Group: [[PPE]] · Party: [[PP (ESP)]] · Country: [[Spain]]

# Dolors Montserrat
