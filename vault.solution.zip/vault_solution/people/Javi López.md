---
type: "person"
person_id: "125042"
first_name: "Javi"
last_name: "López"
gender: "MALE"
mep: true
group: "S&D"
party: "PSC-PSOE (ESP)"
country: "Spain"
roles: ["chair of the sitting"]
---

Group: [[S&D]] · Party: [[PSC-PSOE (ESP)]] · Country: [[Spain]]

# Javi López

Role: chair of the sitting.
