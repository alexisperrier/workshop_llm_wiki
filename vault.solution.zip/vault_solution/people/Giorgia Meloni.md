---
type: person
role: "Prime Minister of Italy"
aliases: ["señora Meloni", "Meloni", "presidente Meloni"]
---
# Giorgia Meloni

Prime Minister of Italy (FdI).
