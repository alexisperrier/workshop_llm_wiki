---
type: "person"
person_id: "257022"
first_name: "Nora"
last_name: "Junco García"
gender: "FEMALE"
mep: true
group: "ECR"
country: "Spain"
---

Group: [[ECR]] · Country: [[Spain]]

# Nora Junco García
