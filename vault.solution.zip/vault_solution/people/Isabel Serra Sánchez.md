---
type: "person"
person_id: "257009"
first_name: "Isabel"
last_name: "Serra Sánchez"
gender: "FEMALE"
mep: true
group: "The Left"
party: "PODEMOS (ESP)"
country: "Spain"
---

Group: [[The Left]] · Party: [[PODEMOS (ESP)]] · Country: [[Spain]]

# Isabel Serra Sánchez
