---
type: person
role: "Spanish minister"
aliases: ["Torres"]
---
# Ángel Víctor Torres

Spanish Minister for Territorial Policy.
