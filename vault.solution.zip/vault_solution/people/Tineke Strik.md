---
type: "person"
person_id: "197772"
first_name: "Tineke"
last_name: "Strik"
gender: "FEMALE"
mep: true
group: "Verts-ALE"
party: "PRO (NLD)"
country: "Netherlands"
---

Group: [[Verts-ALE]] · Party: [[PRO (NLD)]] · Country: [[Netherlands]]

# Tineke Strik
