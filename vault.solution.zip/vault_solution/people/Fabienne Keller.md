---
type: "person"
person_id: "22858"
first_name: "Fabienne"
last_name: "Keller"
gender: "FEMALE"
mep: true
group: "Renew"
party: "Ren (FRA)"
country: "France"
---

Group: [[Renew]] · Party: [[Ren (FRA)]] · Country: [[France]]

# Fabienne Keller
