---
type: "person"
person_id: "256971"
first_name: "Lukas"
last_name: "Sieper"
gender: "MALE"
mep: true
group: "Renew"
party: "PdF (DEU)"
country: "Germany"
---

Group: [[Renew]] · Party: [[PdF (DEU)]] · Country: [[Germany]]

# Lukas Sieper
