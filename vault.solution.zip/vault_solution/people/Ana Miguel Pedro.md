---
type: "person"
person_id: "110673"
first_name: "Ana Miguel"
last_name: "Pedro"
gender: "FEMALE"
mep: true
group: "PPE"
party: "CDS-PP (PRT)"
country: "Portugal"
---

Group: [[PPE]] · Party: [[CDS-PP (PRT)]] · Country: [[Portugal]]

# Ana Miguel Pedro
