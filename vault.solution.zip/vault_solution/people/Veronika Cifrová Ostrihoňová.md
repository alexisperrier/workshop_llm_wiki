---
type: "person"
person_id: "257014"
first_name: "Veronika"
last_name: "Cifrová Ostrihoňová"
gender: "FEMALE"
mep: true
group: "Renew"
party: "PS (SVK)"
country: "Slovakia"
---

Group: [[Renew]] · Party: [[PS (SVK)]] · Country: [[Slovakia]]

# Veronika Cifrová Ostrihoňová
