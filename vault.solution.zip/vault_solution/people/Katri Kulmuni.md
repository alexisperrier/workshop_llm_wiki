---
type: "person"
person_id: "198084"
first_name: "Katri"
last_name: "Kulmuni"
gender: "FEMALE"
mep: true
group: "Renew"
party: "KESK (FIN)"
country: "Finland"
---

Group: [[Renew]] · Party: [[KESK (FIN)]] · Country: [[Finland]]

# Katri Kulmuni
