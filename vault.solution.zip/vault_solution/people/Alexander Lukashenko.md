---
type: person
role: "President of Belarus"
aliases: ["Lukashenko"]
---
# Alexander Lukashenko

President of Belarus.
