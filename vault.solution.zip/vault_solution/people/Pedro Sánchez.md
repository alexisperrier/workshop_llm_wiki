---
type: person
role: "Prime Minister of Spain"
aliases: ["Prime Minister Sánchez", "Sanchez", "Sánchez", "señor Sánchez", "Pedro Sanchez"]
---
# Pedro Sánchez

Prime Minister of Spain (PSOE).
