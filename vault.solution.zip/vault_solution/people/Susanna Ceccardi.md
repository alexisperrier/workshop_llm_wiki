---
type: "person"
person_id: "197786"
first_name: "Susanna"
last_name: "Ceccardi"
gender: "FEMALE"
mep: true
group: "PfE"
party: "L (ITA)"
country: "Italy"
---

Group: [[PfE]] · Party: [[L (ITA)]] · Country: [[Italy]]

# Susanna Ceccardi
