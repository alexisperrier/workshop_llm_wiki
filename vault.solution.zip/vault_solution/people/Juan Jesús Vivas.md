---
type: person
role: "Mayor-President of Ceuta"
aliases: ["Juan Vivas"]
---
# Juan Jesús Vivas

Mayor-President of the autonomous city of Ceuta (PP).
