---
type: "person"
person_id: "256860"
first_name: "András"
last_name: "László"
gender: "MALE"
mep: true
group: "PfE"
party: "Fidesz-KDNP (HUN)"
country: "Hungary"
---

Group: [[PfE]] · Party: [[Fidesz-KDNP (HUN)]] · Country: [[Hungary]]

# András László
