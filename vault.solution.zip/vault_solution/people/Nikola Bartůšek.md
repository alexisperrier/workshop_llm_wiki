---
type: "person"
person_id: "256852"
first_name: "Nikola"
last_name: "Bartůšek"
gender: "FEMALE"
mep: true
group: "ECR"
country: "Czechia"
---

Group: [[ECR]] · Country: [[Czechia]]

# Nikola Bartůšek
