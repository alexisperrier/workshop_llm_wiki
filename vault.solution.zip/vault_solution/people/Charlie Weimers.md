---
type: "person"
person_id: "123562"
first_name: "Charlie"
last_name: "Weimers"
gender: "MALE"
mep: true
group: "ECR"
party: "SD (SWE)"
country: "Sweden"
---

Group: [[ECR]] · Party: [[SD (SWE)]] · Country: [[Sweden]]

# Charlie Weimers
